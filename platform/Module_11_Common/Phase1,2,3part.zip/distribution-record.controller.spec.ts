import { Test, TestingModule } from '@nestjs/testing';
import { DistributionRecordController } from '../distribution-record.controller';
import { DistributionRecordService } from '../../services/distribution-record.service';
import { DistributionRecord, DistributionStatus } from '../../entities/distribution-record.entity';
import { NotFoundException, ForbiddenException } from '@nestjs/common';
import { CreateDistributionRecordDto, UpdateDistributionRecordDto } from '../../dto/distribution-record.dto';
import { CommunicationChannel } from '../../entities/recipient-contact.entity';

describe('DistributionRecordController', () => {
  let controller: DistributionRecordController;
  let service: DistributionRecordService;

  const testOrganizationId = 'test-org-id';
  const testUserId = 'test-user-id';
  const mockRequest = {
    user: {
      id: testUserId,
      organizationId: testOrganizationId,
    },
  };

  const testDistributionRecord: DistributionRecord = {
    id: 'test-id',
    invoiceId: 'test-invoice-id',
    recipientId: 'test-recipient-id',
    channel: CommunicationChannel.EMAIL,
    status: DistributionStatus.PENDING,
    sentAt: null,
    deliveredAt: null,
    openedAt: null,
    organizationId: testOrganizationId,
    createdAt: new Date(),
    recipient: {
      id: 'test-recipient-id',
      recipientName: 'Test Recipient',
      email: 'test@example.com',
    } as any,
  };

  const mockDistributionRecordService = {
    create: jest.fn(),
    findAll: jest.fn(),
    findByInvoice: jest.fn(),
    findOne: jest.fn(),
    update: jest.fn(),
    updateStatus: jest.fn(),
    remove: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DistributionRecordController],
      providers: [
        {
          provide: DistributionRecordService,
          useValue: mockDistributionRecordService,
        },
      ],
    }).compile();

    controller = module.get<DistributionRecordController>(DistributionRecordController);
    service = module.get<DistributionRecordService>(DistributionRecordService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('create', () => {
    it('should create a new distribution record', async () => {
      const createDto: CreateDistributionRecordDto = {
        invoiceId: 'test-invoice-id',
        recipientId: 'test-recipient-id',
        channel: CommunicationChannel.EMAIL,
        organizationId: testOrganizationId,
      };

      mockDistributionRecordService.create.mockResolvedValue(testDistributionRecord);

      const result = await controller.create(createDto, mockRequest);

      expect(mockDistributionRecordService.create).toHaveBeenCalledWith(createDto);
      expect(result).toEqual(testDistributionRecord);
    });

    it('should throw ForbiddenException when organization ID does not match', async () => {
      const createDto: CreateDistributionRecordDto = {
        invoiceId: 'test-invoice-id',
        recipientId: 'test-recipient-id',
        channel: CommunicationChannel.EMAIL,
        organizationId: 'different-org-id',
      };

      await expect(controller.create(createDto, mockRequest)).rejects.toThrow(
        ForbiddenException,
      );
      expect(mockDistributionRecordService.create).not.toHaveBeenCalled();
    });
  });

  describe('findAll', () => {
    it('should return an array of distribution records', async () => {
      mockDistributionRecordService.findAll.mockResolvedValue([testDistributionRecord]);

      const result = await controller.findAll(mockRequest);

      expect(mockDistributionRecordService.findAll).toHaveBeenCalledWith(testOrganizationId);
      expect(result).toEqual([testDistributionRecord]);
    });
  });

  describe('findByInvoice', () => {
    it('should return distribution records for a specific invoice', async () => {
      mockDistributionRecordService.findByInvoice.mockResolvedValue([testDistributionRecord]);

      const result = await controller.findByInvoice('test-invoice-id', mockRequest);

      expect(mockDistributionRecordService.findByInvoice).toHaveBeenCalledWith('test-invoice-id', testOrganizationId);
      expect(result).toEqual([testDistributionRecord]);
    });
  });

  describe('findOne', () => {
    it('should return a distribution record by ID', async () => {
      mockDistributionRecordService.findOne.mockResolvedValue(testDistributionRecord);

      const result = await controller.findOne('test-id', mockRequest);

      expect(mockDistributionRecordService.findOne).toHaveBeenCalledWith('test-id', testOrganizationId);
      expect(result).toEqual(testDistributionRecord);
    });

    it('should propagate NotFoundException when distribution record does not exist', async () => {
      mockDistributionRecordService.findOne.mockRejectedValue(new NotFoundException());

      await expect(controller.findOne('non-existent-id', mockRequest)).rejects.toThrow(
        NotFoundException,
      );
    });
  });

  describe('update', () => {
    it('should update and return the distribution record', async () => {
      const updateDto: UpdateDistributionRecordDto = {
        status: DistributionStatus.SENT,
        sentAt: new Date(),
      };

      const updatedRecord = { ...testDistributionRecord, ...updateDto };
      mockDistributionRecordService.update.mockResolvedValue(updatedRecord);

      const result = await controller.update('test-id', updateDto, mockRequest);

      expect(mockDistributionRecordService.update).toHaveBeenCalledWith(
        'test-id',
        updateDto,
        testOrganizationId,
      );
      expect(result).toEqual(updatedRecord);
    });
  });

  describe('updateStatus', () => {
    it('should update the status and return the distribution record', async () => {
      const status = DistributionStatus.SENT;
      const updatedRecord = { ...testDistributionRecord, status, sentAt: new Date() };
      
      mockDistributionRecordService.updateStatus.mockResolvedValue(updatedRecord);

      const result = await controller.updateStatus('test-id', status, mockRequest);

      expect(mockDistributionRecordService.updateStatus).toHaveBeenCalledWith(
        'test-id',
        status,
        testOrganizationId,
      );
      expect(result).toEqual(updatedRecord);
    });
  });

  describe('remove', () => {
    it('should remove the distribution record and return success message', async () => {
      mockDistributionRecordService.remove.mockResolvedValue(undefined);

      const result = await controller.remove('test-id', mockRequest);

      expect(mockDistributionRecordService.remove).toHaveBeenCalledWith('test-id', testOrganizationId);
      expect(result).toEqual({ message: 'Distribution record successfully deleted' });
    });
  });
});

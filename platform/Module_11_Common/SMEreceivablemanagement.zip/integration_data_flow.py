#!/usr/bin/env python3
from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import Users
from diagrams.onprem.database import PostgreSQL
from diagrams.onprem.queue import Kafka
from diagrams.programming.framework import React
from diagrams.programming.language import Python
from diagrams.generic.storage import Storage
from diagrams.generic.compute import Rack
from diagrams.generic.place import Datacenter
from diagrams.onprem.network import Nginx

# Create integration data flow diagram
with Diagram("AI Platform for SME Receivables Management - Integration Data Flow", show=False, filename="integration_data_flow", outformat="png"):
    
    # Core Platform
    with Cluster("AI Platform Core"):
        api_gateway = Nginx("API Gateway")
        
        with Cluster("Integration Services"):
            integration_service = Python("Integration Service")
            integration_agent = Python("Integration Agent")
        
        with Cluster("Data Storage"):
            main_db = PostgreSQL("Main Database")
            document_store = Storage("Document Store")
            message_broker = Kafka("Message Broker")
    
    # External Systems - Priority 1: Accounting Systems
    with Cluster("Accounting Systems (Priority 1)"):
        tally = Rack("Tally")
        quickbooks = Rack("QuickBooks")
        zoho = Rack("Zoho Books")
        custom_accounting = Rack("Custom Accounting")
    
    # External Systems - Priority 2: Banking Systems
    with Cluster("Banking Systems (Priority 2)"):
        bank_apis = Rack("Bank APIs")
        account_aggregator = Rack("Account Aggregator")
        nach = Rack("NACH")
        virtual_accounts = Rack("Virtual Accounts")
    
    # External Systems - Priority 3: Payment Gateways
    with Cluster("Payment Gateways (Priority 3)"):
        payment_gateways = Rack("Payment Gateways")
        upi = Rack("UPI")
    
    # Other External Systems
    with Cluster("Other External Systems"):
        govt_systems = Rack("Government Systems")
        erp_systems = Rack("ERP Systems")
        treds = Rack("TReDS Platforms")
    
    # Integration Flows - Accounting Systems (Priority 1)
    api_gateway >> Edge(label="API Requests") >> integration_service
    integration_service >> Edge(label="Orchestrate") >> integration_agent
    
    # Accounting Systems Integration (Priority 1)
    integration_agent >> Edge(label="Sync Invoices", style="bold", color="blue") >> tally
    integration_agent >> Edge(label="Sync Invoices", style="bold", color="blue") >> quickbooks
    integration_agent >> Edge(label="Sync Invoices", style="bold", color="blue") >> zoho
    integration_agent >> Edge(label="Sync Invoices", style="bold", color="blue") >> custom_accounting
    
    tally >> Edge(label="Invoice Data", style="bold", color="blue") >> integration_agent
    quickbooks >> Edge(label="Invoice Data", style="bold", color="blue") >> integration_agent
    zoho >> Edge(label="Invoice Data", style="bold", color="blue") >> integration_agent
    custom_accounting >> Edge(label="Invoice Data", style="bold", color="blue") >> integration_agent
    
    # Banking Systems Integration (Priority 2)
    integration_agent >> Edge(label="Payment Processing", style="dashed", color="green") >> bank_apis
    integration_agent >> Edge(label="Account Data", style="dashed", color="green") >> account_aggregator
    integration_agent >> Edge(label="Mandate Management", style="dashed", color="green") >> nach
    integration_agent >> Edge(label="Virtual Account Creation", style="dashed", color="green") >> virtual_accounts
    
    bank_apis >> Edge(label="Transaction Data", style="dashed", color="green") >> integration_agent
    account_aggregator >> Edge(label="Account Statements", style="dashed", color="green") >> integration_agent
    nach >> Edge(label="Mandate Status", style="dashed", color="green") >> integration_agent
    virtual_accounts >> Edge(label="Payment Notifications", style="dashed", color="green") >> integration_agent
    
    # Payment Gateways Integration (Priority 3)
    integration_agent >> Edge(label="Payment Initiation", style="dotted", color="red") >> payment_gateways
    integration_agent >> Edge(label="UPI Payments", style="dotted", color="red") >> upi
    
    payment_gateways >> Edge(label="Payment Status", style="dotted", color="red") >> integration_agent
    upi >> Edge(label="Payment Status", style="dotted", color="red") >> integration_agent
    
    # Other External Systems Integration
    integration_agent >> Edge(label="Compliance Data", style="dotted") >> govt_systems
    integration_agent >> Edge(label="ERP Data", style="dotted") >> erp_systems
    integration_agent >> Edge(label="Financing Requests", style="dotted") >> treds
    
    govt_systems >> Edge(label="Regulatory Data", style="dotted") >> integration_agent
    erp_systems >> Edge(label="Business Data", style="dotted") >> integration_agent
    treds >> Edge(label="Financing Status", style="dotted") >> integration_agent
    
    # Data Storage
    integration_agent >> Edge(label="Store Integration Data") >> main_db
    integration_agent >> Edge(label="Store Documents") >> document_store
    integration_agent >> Edge(label="Publish Events") >> message_broker
    
    # Legend Notes
    api_gateway >> Edge(label="Bold Blue: Priority 1", color="blue", style="bold") >> api_gateway
    api_gateway >> Edge(label="Dashed Green: Priority 2", color="green", style="dashed") >> api_gateway
    api_gateway >> Edge(label="Dotted Red: Priority 3", color="red", style="dotted") >> api_gateway

import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Grid, Paper, Typography, Box, Button, CircularProgress } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { fetchInvoices } from '../../store/slices/invoiceSlice';
import { fetchOrganizations } from '../../store/slices/organizationSlice';
import AddIcon from '@mui/icons-material/Add';
import ReceiptIcon from '@mui/icons-material/Receipt';
import BusinessIcon from '@mui/icons-material/Business';
import PeopleIcon from '@mui/icons-material/People';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';

const DashboardPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const { invoices, loading: invoicesLoading } = useSelector((state) => state.invoices);
  const { organizations, smes, buyers, loading: organizationsLoading } = useSelector((state) => state.organizations);
  const { users } = useSelector((state) => state.users);
  
  useEffect(() => {
    dispatch(fetchInvoices());
    dispatch(fetchOrganizations());
  }, [dispatch]);
  
  const loading = invoicesLoading || organizationsLoading;
  
  // Calculate statistics
  const totalInvoiceAmount = invoices.reduce((sum, invoice) => sum + parseFloat(invoice.amount), 0);
  const overdueInvoices = invoices.filter(invoice => 
    invoice.status !== 'paid' && new Date(invoice.due_date) < new Date()
  );
  const overdueAmount = overdueInvoices.reduce((sum, invoice) => sum + parseFloat(invoice.amount), 0);
  
  const DashboardCard = ({ title, value, icon, color, onClick }) => (
    <Paper
      elevation={2}
      sx={{
        p: 3,
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        cursor: onClick ? 'pointer' : 'default',
        '&:hover': onClick ? { boxShadow: 6 } : {}
      }}
      onClick={onClick}
    >
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6" component="h2">
          {title}
        </Typography>
        <Box sx={{ 
          backgroundColor: `${color}.light`, 
          borderRadius: '50%', 
          width: 40, 
          height: 40, 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center' 
        }}>
          {icon}
        </Box>
      </Box>
      <Typography variant="h4" component="p" sx={{ fontWeight: 'bold' }}>
        {value}
      </Typography>
    </Paper>
  );
  
  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Dashboard
        </Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => navigate('/invoices/new')}
        >
          New Invoice
        </Button>
      </Box>
      
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard 
                title="Total Invoices" 
                value={invoices.length} 
                icon={<ReceiptIcon color="primary" />}
                color="primary"
                onClick={() => navigate('/invoices')}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard 
                title="Total Amount" 
                value={`₹${totalInvoiceAmount.toLocaleString()}`} 
                icon={<AttachMoneyIcon color="success" />}
                color="success"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard 
                title="Buyers" 
                value={buyers.length} 
                icon={<BusinessIcon color="info" />}
                color="info"
                onClick={() => navigate('/organizations?type=buyer')}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard 
                title="SMEs" 
                value={smes.length} 
                icon={<PeopleIcon color="secondary" />}
                color="secondary"
                onClick={() => navigate('/organizations?type=sme')}
              />
            </Grid>
          </Grid>
          
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Paper elevation={2} sx={{ p: 3 }}>
                <Typography variant="h6" component="h2" gutterBottom>
                  Recent Invoices
                </Typography>
                {invoices.length === 0 ? (
                  <Typography variant="body1">No invoices found</Typography>
                ) : (
                  <Box>
                    {invoices.slice(0, 5).map((invoice) => (
                      <Box 
                        key={invoice.id} 
                        sx={{ 
                          display: 'flex', 
                          justifyContent: 'space-between', 
                          py: 1,
                          borderBottom: '1px solid',
                          borderColor: 'divider'
                        }}
                      >
                        <Box>
                          <Typography variant="body1">{invoice.invoice_number}</Typography>
                          <Typography variant="body2" color="text.secondary">
                            {invoice.Buyer?.name || 'Unknown Buyer'}
                          </Typography>
                        </Box>
                        <Box sx={{ textAlign: 'right' }}>
                          <Typography variant="body1">₹{parseFloat(invoice.amount).toLocaleString()}</Typography>
                          <Typography 
                            variant="body2" 
                            sx={{ 
                              color: invoice.status === 'paid' 
                                ? 'success.main' 
                                : new Date(invoice.due_date) < new Date() 
                                  ? 'error.main' 
                                  : 'warning.main'
                            }}
                          >
                            {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                          </Typography>
                        </Box>
                      </Box>
                    ))}
                    <Box sx={{ mt: 2, textAlign: 'right' }}>
                      <Button 
                        variant="text" 
                        onClick={() => navigate('/invoices')}
                      >
                        View All
                      </Button>
                    </Box>
                  </Box>
                )}
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Paper elevation={2} sx={{ p: 3 }}>
                <Typography variant="h6" component="h2" gutterBottom>
                  Overdue Invoices
                </Typography>
                {overdueInvoices.length === 0 ? (
                  <Typography variant="body1">No overdue invoices</Typography>
                ) : (
                  <Box>
                    {overdueInvoices.slice(0, 5).map((invoice) => (
                      <Box 
                        key={invoice.id} 
                        sx={{ 
                          display: 'flex', 
                          justifyContent: 'space-between', 
                          py: 1,
                          borderBottom: '1px solid',
                          borderColor: 'divider'
                        }}
                      >
                        <Box>
                          <Typography variant="body1">{invoice.invoice_number}</Typography>
                          <Typography variant="body2" color="text.secondary">
                            {invoice.Buyer?.name || 'Unknown Buyer'}
                          </Typography>
                        </Box>
                        <Box sx={{ textAlign: 'right' }}>
                          <Typography variant="body1">₹{parseFloat(invoice.amount).toLocaleString()}</Typography>
                          <Typography variant="body2" color="error.main">
                            Due: {new Date(invoice.due_date).toLocaleDateString()}
                          </Typography>
                        </Box>
                      </Box>
                    ))}
                    <Box sx={{ mt: 2, textAlign: 'right' }}>
                      <Button 
                        variant="text" 
                        onClick={() => navigate('/invoices?status=overdue')}
                        color="error"
                      >
                        View All
                      </Button>
                    </Box>
                  </Box>
                )}
              </Paper>
            </Grid>
          </Grid>
        </>
      )}
    </Box>
  );
};

export default DashboardPage;

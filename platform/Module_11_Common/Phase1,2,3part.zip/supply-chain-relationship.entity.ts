import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { Organization } from '../../../organizations/entities/organization.entity';
import { FinancingRequest } from './financing-request.entity';

export enum SupplyChainRelationshipType {
  BUYER = 'buyer',
  SUPPLIER = 'supplier',
  DISTRIBUTOR = 'distributor',
  MANUFACTURER = 'manufacturer',
}

export enum SupplyChainRelationshipStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  PENDING_VERIFICATION = 'pending_verification',
  REJECTED = 'rejected',
}

@Entity()
export class SupplyChainRelationship {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Organization)
  organization: Organization;

  @Column()
  organizationId: string;

  @Column()
  partnerOrganizationId: string;

  @Column()
  partnerOrganizationName: string;

  @Column({
    type: 'enum',
    enum: SupplyChainRelationshipType,
  })
  relationshipType: SupplyChainRelationshipType;

  @Column({
    type: 'enum',
    enum: SupplyChainRelationshipStatus,
    default: SupplyChainRelationshipStatus.PENDING_VERIFICATION,
  })
  status: SupplyChainRelationshipStatus;

  @Column({ nullable: true })
  verificationDate: Date;

  @Column({ nullable: true })
  verifiedBy: string;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  averageTransactionAmount: number;

  @Column({ nullable: true })
  averagePaymentTermDays: number;

  @Column({ nullable: true })
  relationshipStartDate: Date;

  @Column({ type: 'decimal', precision: 3, scale: 2, nullable: true })
  trustScore: number;

  @Column({ type: 'json', nullable: true })
  financingPreferences: Record<string, any>;

  @Column({ type: 'json', nullable: true })
  metadata: Record<string, any>;

  @OneToMany(() => FinancingRequest, request => request.supplyChainRelationship)
  financingRequests: FinancingRequest[];

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  updatedAt: Date;
}

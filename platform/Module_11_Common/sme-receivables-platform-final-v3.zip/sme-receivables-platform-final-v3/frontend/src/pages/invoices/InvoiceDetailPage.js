import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  Typography,
  Paper,
  Grid,
  Chip,
  Button,
  CircularProgress,
  Divider,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  MenuItem,
  Select,
  FormControl,
  InputLabel
} from '@mui/material';
import { fetchInvoiceById, updateInvoiceStatus } from '../../store/slices/invoiceSlice';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import DownloadIcon from '@mui/icons-material/Download';

const InvoiceDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const { currentInvoice, loading, error } = useSelector((state) => state.invoices);
  
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  
  useEffect(() => {
    if (id) {
      dispatch(fetchInvoiceById(id));
    }
  }, [dispatch, id]);
  
  useEffect(() => {
    if (currentInvoice) {
      setNewStatus(currentInvoice.status);
    }
  }, [currentInvoice]);
  
  const handleStatusChange = () => {
    if (newStatus && newStatus !== currentInvoice.status) {
      dispatch(updateInvoiceStatus({ id, status: newStatus }));
    }
    setStatusDialogOpen(false);
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'draft':
        return 'default';
      case 'issued':
        return 'primary';
      case 'paid':
        return 'success';
      case 'overdue':
        return 'error';
      case 'cancelled':
        return 'error';
      default:
        return 'default';
    }
  };
  
  if (loading && !currentInvoice) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
        <CircularProgress />
      </Box>
    );
  }
  
  if (error) {
    return (
      <Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
          <Button
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate('/invoices')}
            sx={{ mr: 2 }}
          >
            Back to Invoices
          </Button>
          <Typography variant="h4" component="h1">
            Invoice Details
          </Typography>
        </Box>
        
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
        
        <Button
          variant="contained"
          onClick={() => navigate('/invoices')}
        >
          Return to Invoices
        </Button>
      </Box>
    );
  }
  
  if (!currentInvoice) {
    return (
      <Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
          <Button
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate('/invoices')}
            sx={{ mr: 2 }}
          >
            Back to Invoices
          </Button>
          <Typography variant="h4" component="h1">
            Invoice Details
          </Typography>
        </Box>
        
        <Alert severity="warning" sx={{ mb: 3 }}>
          Invoice not found
        </Alert>
        
        <Button
          variant="contained"
          onClick={() => navigate('/invoices')}
        >
          Return to Invoices
        </Button>
      </Box>
    );
  }
  
  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/invoices')}
          sx={{ mr: 2 }}
        >
          Back
        </Button>
        <Typography variant="h4" component="h1">
          Invoice {currentInvoice.invoice_number}
        </Typography>
      </Box>
      
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Chip 
            label={currentInvoice.status.charAt(0).toUpperCase() + currentInvoice.status.slice(1)} 
            color={getStatusColor(currentInvoice.status)}
          />
          
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button
              variant="outlined"
              startIcon={<EditIcon />}
              onClick={() => setStatusDialogOpen(true)}
            >
              Change Status
            </Button>
            
            {currentInvoice.document_path && (
              <Button
                variant="outlined"
                startIcon={<DownloadIcon />}
              >
                Download Invoice
              </Button>
            )}
          </Box>
        </Box>
        
        <Divider sx={{ my: 2 }} />
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Invoice Details
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Invoice Number
                </Typography>
                <Typography variant="body1">
                  {currentInvoice.invoice_number}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Amount
                </Typography>
                <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                  {currentInvoice.currency === 'INR' ? '₹' : 
                   currentInvoice.currency === 'USD' ? '$' : 
                   currentInvoice.currency === 'EUR' ? '€' : 
                   currentInvoice.currency === 'GBP' ? '£' : ''}
                  {parseFloat(currentInvoice.amount).toLocaleString()}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Issue Date
                </Typography>
                <Typography variant="body1">
                  {new Date(currentInvoice.issue_date).toLocaleDateString()}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Due Date
                </Typography>
                <Typography variant="body1">
                  {new Date(currentInvoice.due_date).toLocaleDateString()}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Payment Terms
                </Typography>
                <Typography variant="body1">
                  {currentInvoice.payment_terms || 'N/A'}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Status
                </Typography>
                <Typography variant="body1">
                  {currentInvoice.status.charAt(0).toUpperCase() + currentInvoice.status.slice(1)}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Organizations
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Typography variant="body2" color="text.secondary">
                  SME
                </Typography>
                <Typography variant="body1">
                  {currentInvoice.Sme?.name || 'Unknown'}
                </Typography>
              </Grid>
              
              <Grid item xs={12}>
                <Typography variant="body2" color="text.secondary">
                  Buyer
                </Typography>
                <Typography variant="body1">
                  {currentInvoice.Buyer?.name || 'Unknown'}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          
          {currentInvoice.description && (
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Description
              </Typography>
              <Typography variant="body1">
                {currentInvoice.description}
              </Typography>
            </Grid>
          )}
        </Grid>
      </Paper>
      
      {/* Status Change Dialog */}
      <Dialog open={statusDialogOpen} onClose={() => setStatusDialogOpen(false)}>
        <DialogTitle>Change Invoice Status</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            Update the status of invoice {currentInvoice.invoice_number}.
          </DialogContentText>
          
          <FormControl fullWidth sx={{ mt: 1 }}>
            <InputLabel id="status-change-label">Status</InputLabel>
            <Select
              labelId="status-change-label"
              value={newStatus}
              onChange={(e) => setNewStatus(e.target.value)}
              label="Status"
            >
              <MenuItem value="draft">Draft</MenuItem>
              <MenuItem value="issued">Issued</MenuItem>
              <MenuItem value="paid">Paid</MenuItem>
              <MenuItem value="overdue">Overdue</MenuItem>
              <MenuItem value="cancelled">Cancelled</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setStatusDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleStatusChange} variant="contained">
            Update Status
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default InvoiceDetailPage;

import { Injectable, Logger } from '@nestjs/common';

/**
 * Service for monitoring and reporting RabbitMQ queue health metrics
 */
@Injectable()
export class QueueHealthService {
  private readonly logger = new Logger(QueueHealthService.name);
  
  // Queue health metrics
  private metrics = {
    status: 'initializing', // connected, disconnected, reconnecting
    statusMessage: '',
    lastStatusChange: new Date(),
    queues: {}, // Per-queue metrics
    totalMessagesSent: 0,
    totalMessagesProcessed: 0,
    totalErrors: 0,
    startTime: new Date(),
  };

  constructor() {
    // Initialize metrics for standard queues
    this.initializeQueueMetrics('email_distribution');
    this.initializeQueueMetrics('whatsapp_distribution');
    this.initializeQueueMetrics('sms_distribution');
    this.initializeQueueMetrics('general_distribution');
  }

  /**
   * Initialize metrics for a specific queue
   * @param queueName Name of the queue to initialize
   */
  private initializeQueueMetrics(queueName: string): void {
    this.metrics.queues[queueName] = {
      messagesSent: 0,
      messagesProcessed: 0,
      errors: 0,
      lastMessageSent: null,
      lastMessageProcessed: null,
      lastError: null,
      averageProcessingTime: 0,
      processingTimes: [], // Array to calculate moving average
    };
  }

  /**
   * Set the overall connection status
   * @param status Status string (connected, disconnected, reconnecting)
   * @param message Optional status message
   */
  setStatus(status: string, message: string = ''): void {
    this.metrics.status = status;
    this.metrics.statusMessage = message;
    this.metrics.lastStatusChange = new Date();
    this.logger.log(`Queue status changed to ${status}${message ? ': ' + message : ''}`);
  }

  /**
   * Increment the count of messages sent to a queue
   * @param queueName Name of the queue
   */
  incrementMessagesSent(queueName: string): void {
    if (!this.metrics.queues[queueName]) {
      this.initializeQueueMetrics(queueName);
    }
    
    this.metrics.queues[queueName].messagesSent++;
    this.metrics.queues[queueName].lastMessageSent = new Date();
    this.metrics.totalMessagesSent++;
  }

  /**
   * Increment the count of messages processed from a queue
   * @param queueName Name of the queue
   * @param processingTime Time taken to process the message in milliseconds
   */
  incrementMessagesProcessed(queueName: string, processingTime: number = 0): void {
    if (!this.metrics.queues[queueName]) {
      this.initializeQueueMetrics(queueName);
    }
    
    this.metrics.queues[queueName].messagesProcessed++;
    this.metrics.queues[queueName].lastMessageProcessed = new Date();
    this.metrics.totalMessagesProcessed++;
    
    // Update processing time metrics
    const queue = this.metrics.queues[queueName];
    queue.processingTimes.push(processingTime);
    
    // Keep only the last 100 processing times for the moving average
    if (queue.processingTimes.length > 100) {
      queue.processingTimes.shift();
    }
    
    // Calculate new average processing time
    queue.averageProcessingTime = queue.processingTimes.reduce((sum, time) => sum + time, 0) / queue.processingTimes.length;
  }

  /**
   * Increment the count of errors for a queue
   * @param queueName Name of the queue
   */
  incrementErrors(queueName: string): void {
    if (!this.metrics.queues[queueName]) {
      this.initializeQueueMetrics(queueName);
    }
    
    this.metrics.queues[queueName].errors++;
    this.metrics.queues[queueName].lastError = new Date();
    this.metrics.totalErrors++;
  }

  /**
   * Get all health metrics
   * @returns Object containing all queue health metrics
   */
  getHealthMetrics(): any {
    return {
      ...this.metrics,
      uptime: this.getUptime(),
    };
  }

  /**
   * Get metrics for a specific queue
   * @param queueName Name of the queue
   * @returns Object containing queue-specific metrics
   */
  getQueueMetrics(queueName: string): any {
    if (!this.metrics.queues[queueName]) {
      return null;
    }
    
    return this.metrics.queues[queueName];
  }

  /**
   * Calculate uptime in seconds
   * @returns Uptime in seconds
   */
  private getUptime(): number {
    return Math.floor((new Date().getTime() - this.metrics.startTime.getTime()) / 1000);
  }

  /**
   * Reset all metrics
   */
  resetMetrics(): void {
    this.metrics.totalMessagesSent = 0;
    this.metrics.totalMessagesProcessed = 0;
    this.metrics.totalErrors = 0;
    this.metrics.startTime = new Date();
    
    // Reset queue-specific metrics
    Object.keys(this.metrics.queues).forEach(queueName => {
      this.initializeQueueMetrics(queueName);
    });
    
    this.logger.log('Queue health metrics have been reset');
  }
}

export type ChannelType = 'email' | 'whatsapp' | 'sms' | 'portal' | 'api';
export type DistributionStatus = 'pending' | 'processing' | 'sent' | 'delivered' | 'failed' | 'cancelled';

export interface IDistributionChannel {
  id: string;
  tenant_id: string;
  name: string;
  channel_type: ChannelType;
  configuration: any;
  is_default: boolean;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface IDistributionJob {
  id: string;
  tenant_id: string;
  invoice_id: string;
  channels: ChannelType[];
  status: DistributionStatus;
  initiated_by: string;
  started_at?: Date;
  completed_at?: Date;
  created_at: Date;
}

export interface IDistributionLog {
  id: string;
  tenant_id: string;
  job_id: string;
  channel_id?: string;
  channel_type: ChannelType;
  recipient: string;
  status: DistributionStatus;
  metadata?: any;
  error_message?: string;
  sent_at?: Date;
  delivered_at?: Date;
  opened_at?: Date;
  created_at: Date;
}

export interface IDistributionTemplate {
  id: string;
  tenant_id: string;
  name: string;
  channel_type: ChannelType;
  template_content: string;
  variables: string[];
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
}

import { Injectable } from '@nestjs/common';
import { CommunicationChannel } from '../../distribution/entities/recipient-contact.entity';
import { QueueManagementService } from './queue-management.service';
import { DistributionPayload } from '../interfaces/channel-distributor.interface';
import { EmailDistributor } from '../providers/email-distributor.service';
import { WhatsAppDistributor } from '../providers/whatsapp-distributor.service';
import { SMSDistributor } from '../providers/sms-distributor.service';

/**
 * Distribution service that coordinates channel selection and queue management
 */
@Injectable()
export class DistributionService {
  constructor(
    private queueManagementService: QueueManagementService,
    private emailDistributor: EmailDistributor,
    private whatsAppDistributor: WhatsAppDistributor,
    private smsDistributor: SMSDistributor,
  ) {
    // Register all distributors with the queue management service
    this.queueManagementService.registerDistributor(this.emailDistributor);
    this.queueManagementService.registerDistributor(this.whatsAppDistributor);
    this.queueManagementService.registerDistributor(this.smsDistributor);
  }

  /**
   * Distribute an invoice through the specified channel
   */
  async distributeInvoice(
    invoiceId: string,
    recipientId: string,
    channel: CommunicationChannel,
    templateId?: string,
    customContent?: string,
    attachments?: string[],
    organizationId?: string,
    priority: number = 1,
  ): Promise<string> {
    const payload: DistributionPayload = {
      invoiceId,
      recipientId,
      channel,
      templateId,
      customContent,
      attachments,
      metadata: {
        organizationId,
      },
    };

    // Add the distribution job to the queue
    return this.queueManagementService.addToQueue(payload, priority);
  }

  /**
   * Get the status of a distribution job
   */
  getJobStatus(jobId: string): any {
    return this.queueManagementService.getJob(jobId);
  }

  /**
   * Cancel a distribution job
   */
  cancelJob(jobId: string): boolean {
    return this.queueManagementService.cancelJob(jobId);
  }

  /**
   * Get the current queue size
   */
  getQueueSize(): number {
    return this.queueManagementService.getQueueSize();
  }
}

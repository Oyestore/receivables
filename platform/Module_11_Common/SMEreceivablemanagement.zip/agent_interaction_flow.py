#!/usr/bin/env python3
from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import Users
from diagrams.onprem.database import PostgreSQL
from diagrams.onprem.queue import Kafka
from diagrams.programming.framework import React
from diagrams.programming.language import Python
from diagrams.generic.storage import Storage
from diagrams.generic.compute import Rack
from diagrams.generic.place import Datacenter

# Create agent interaction flow diagram
with Diagram("AI Platform for SME Receivables Management - Agent Interaction Flow", show=False, filename="agent_interaction_flow", outformat="png"):
    
    # Master Orchestration Agent
    orchestrator = Python("Master Orchestration Agent")
    
    # Specialized Agents
    with Cluster("Invoice Management"):
        invoice_agent = Python("Invoice Generation Agent")
        terms_agent = Python("Terms Recommendation Agent")
    
    with Cluster("Buyer Assessment"):
        rating_agent = Python("Rating Agent")
    
    with Cluster("Payment Tracking"):
        milestone_agent = Python("Milestone Tracking Agent")
        payment_agent = Python("Payment Agent")
    
    with Cluster("Communication"):
        comm_agent = Python("Communication Agent")
    
    with Cluster("Financial Services"):
        financing_agent = Python("Financing Agent")
    
    with Cluster("Legal Services"):
        legal_agent = Python("Legal Agent")
    
    with Cluster("Analytics & Integration"):
        analytics_agent = Python("Analytics Agent")
        integration_agent = Python("Integration Agent")
    
    # Data Stores
    with Cluster("Data Stores"):
        main_db = PostgreSQL("Main Database")
        document_store = Storage("Document Store")
        message_broker = Kafka("Message Broker")
    
    # External Systems
    with Cluster("External Systems"):
        accounting = Rack("Accounting Systems")
        banking = Rack("Banking Systems")
        payment_gateways = Rack("Payment Gateways")
        govt_systems = Rack("Government Systems")
    
    # Orchestration Flows
    orchestrator >> Edge(color="blue", style="bold") >> invoice_agent
    orchestrator >> Edge(color="blue", style="bold") >> rating_agent
    orchestrator >> Edge(color="blue", style="bold") >> terms_agent
    orchestrator >> Edge(color="blue", style="bold") >> milestone_agent
    orchestrator >> Edge(color="blue", style="bold") >> comm_agent
    orchestrator >> Edge(color="blue", style="bold") >> financing_agent
    orchestrator >> Edge(color="blue", style="bold") >> legal_agent
    orchestrator >> Edge(color="blue", style="bold") >> analytics_agent
    orchestrator >> Edge(color="blue", style="bold") >> integration_agent
    orchestrator >> Edge(color="blue", style="bold") >> payment_agent
    
    # Invoice Creation Flow
    invoice_agent >> Edge(label="Get terms") >> terms_agent
    invoice_agent >> Edge(label="Store invoice") >> document_store
    invoice_agent >> Edge(label="Notify") >> message_broker
    
    # Rating Flow
    rating_agent >> Edge(label="Get data") >> integration_agent
    rating_agent >> Edge(label="Store rating") >> main_db
    
    # Payment Flow
    payment_agent >> Edge(label="Update milestones") >> milestone_agent
    payment_agent >> Edge(label="Process payment") >> banking
    payment_agent >> Edge(label="Notify") >> message_broker
    
    # Communication Flow
    comm_agent << Edge(label="Payment status") << payment_agent
    comm_agent << Edge(label="Milestone updates") << milestone_agent
    comm_agent >> Edge(label="Send notifications") >> message_broker
    
    # Financing Flow
    financing_agent >> Edge(label="Check eligibility") >> rating_agent
    financing_agent >> Edge(label="Process financing") >> banking
    
    # Legal Flow
    legal_agent << Edge(label="Escalate") << payment_agent
    legal_agent << Edge(label="Payment history") << analytics_agent
    
    # Analytics Flow
    analytics_agent << Edge(label="Payment data") << payment_agent
    analytics_agent << Edge(label="Invoice data") << invoice_agent
    analytics_agent >> Edge(label="Store insights") >> main_db
    
    # Integration Flow
    integration_agent >> Edge(label="Sync data") >> accounting
    integration_agent >> Edge(label="Sync data") >> banking
    integration_agent >> Edge(label="Sync data") >> payment_gateways
    integration_agent >> Edge(label="Sync data") >> govt_systems
    
    # Database Interactions
    main_db << Edge(color="green") << invoice_agent
    main_db << Edge(color="green") << payment_agent
    main_db << Edge(color="green") << milestone_agent
    main_db << Edge(color="green") << rating_agent
    
    # Message Broker Interactions
    message_broker >> Edge(color="red", style="dashed") >> orchestrator

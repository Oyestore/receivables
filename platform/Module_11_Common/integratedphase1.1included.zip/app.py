# ocr_microservice/app.py

import os
import tempfile
import time
from flask import Flask, request, jsonify
import pytesseract
from PIL import Image, ImageEnhance, ImageFilter
import cv2 # OpenCV for more advanced pre-processing
import numpy as np
# For PDF processing, we might need to convert PDF to image first
# poppler-utils should be installed in the environment for this (e.g., pdftoppm)
import subprocess

app = Flask(__name__)

@app.route("/health", methods=["GET"])
def health_check():
    app.logger.info("Health check endpoint called.")
    return jsonify({"status": "healthy", "message": "OCR microservice is running."}), 200

# Ensure Tesseract is in PATH or set the command path
# Example: pytesseract.pytesseract.tesseract_cmd = r'/usr/bin/tesseract'

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "tiff", "tif", "pdf"}

def allowed_file(filename):
    return "." in filename and \
           filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def preprocess_image_pil(image_path):
    """Basic image pre-processing using Pillow."""
    img = Image.open(image_path).convert("L")  # Convert to grayscale
    
    # Enhance contrast
    enhancer = ImageEnhance.Contrast(img)
    img = enhancer.enhance(2)
    
    # Binarization (simple threshold)
    img = img.point(lambda x: 0 if x < 140 else 255, "1")
    
    # img.save(os.path.join(tempfile.gettempdir(), "processed_pil_" + os.path.basename(image_path))) # For debugging
    return img

def preprocess_image_cv2(image_path):
    """Advanced image pre-processing using OpenCV."""
    img = cv2.imread(image_path)
    
    # 1. Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # 2. Noise reduction (Gaussian Blur)
    # blurred = cv2.GaussianBlur(gray, (3, 3), 0)
    
    # 3. Binarization (Otsu's thresholding is good for bimodal images)
    _, binary_img = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # Deskewing (example using findContours and minAreaRect - can be complex)
    # For simplicity, basic deskewing might be skipped initially or use a simpler method.
    # coords = np.column_stack(np.where(binary_img > 0))
    # angle = cv2.minAreaRect(coords)[-1]
    # if angle < -45:
    #     angle = -(90 + angle)
    # else:
    #     angle = -angle
    # (h, w) = binary_img.shape[:2]
    # center = (w // 2, h // 2)
    # M = cv2.getRotationMatrix2D(center, angle, 1.0)
    # rotated = cv2.warpAffine(binary_img, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    
    # cv2.imwrite(os.path.join(tempfile.gettempdir(), "processed_cv2_" + os.path.basename(image_path)), binary_img) # For debugging
    return Image.fromarray(binary_img) # pytesseract works well with PIL Images

@app.route("/ocr-service/v1/extract-text", methods=["POST"])
def extract_text():
    start_time = time.time()
    if "image" not in request.files:
        return jsonify({"status": "error", "message": "No image file provided."}), 400

    file = request.files["image"]

    if file.filename == "":
        return jsonify({"status": "error", "message": "No selected file."}), 400

    if file and allowed_file(file.filename):
        filename = file.filename # Keep original filename for extension checking
        app.logger.info(f"Received file: {filename}") # ADDED LOG
        
        # Save to a temporary file
        temp_dir = tempfile.mkdtemp()
        app.logger.info(f"Created temp directory: {temp_dir}") # ADDED LOG
        temp_filepath = os.path.join(temp_dir, filename)
        file.save(temp_filepath)
        app.logger.info(f"Saved file to temp path: {temp_filepath}") # ADDED LOG
        
        processed_image_path = temp_filepath
        is_pdf = filename.lower().endswith(".pdf")

        try:
            if is_pdf:
                app.logger.info(f"Processing PDF file: {temp_filepath}") # ADDED LOG
                # Convert PDF to image (e.g., first page to PPM/PNG)
                # Requires poppler-utils (pdftoppm)
                ppm_path_prefix = os.path.join(temp_dir, "pdf_page")
                # Convert first page to png
                subprocess.run([
                    "pdftoppm", 
                    "-png",
                    "-f", "1", # First page
                    "-l", "1", # Last page (same as first)
                    "-r", "300", # DPI
                    temp_filepath, 
                    ppm_path_prefix
                ], check=True, timeout=30)
                app.logger.info(f"PDF to image conversion initiated for {temp_filepath}") # ADDED LOG
                # Tesseract expects a single file path, pdftoppm might create pdf_page-000001.ppm or pdf_page-1.png
                # Let's find the generated image file
                generated_images = [f for f in os.listdir(temp_dir) if f.startswith("pdf_page") and (f.endswith(".png") or f.endswith(".ppm"))]
                if not generated_images:
                    app.logger.error("PDF to image conversion failed to produce an image file.") # ADDED LOG
                    raise Exception("PDF to image conversion failed to produce an image file.")
                processed_image_path = os.path.join(temp_dir, generated_images[0])
                app.logger.info(f"PDF converted to image: {processed_image_path}") # ADDED LOG
            
            app.logger.info(f"Starting pre-processing for image: {processed_image_path}") # ADDED LOG
            # Pre-process the image (using OpenCV for better results)
            # img_for_ocr = preprocess_image_pil(processed_image_path)
            img_for_ocr = preprocess_image_cv2(processed_image_path)
            app.logger.info(f"Pre-processing completed for image: {processed_image_path}") # ADDED LOG

            # Perform OCR using Tesseract
            # Specify language, e.g., lang=\'eng\'
            # Add config options if needed, e.g., --psm 6 for assuming a single uniform block of text.
            custom_config = r"--oem 3 --psm 6"
            app.logger.info(f"Starting Tesseract OCR for image: {processed_image_path} with config: {custom_config}") # ADDED LOG
            text = pytesseract.image_to_string(img_for_ocr, lang="eng", config=custom_config)
            app.logger.info(f"Tesseract OCR completed. Extracted text length: {len(text)}") # ADDED LOG
            
            processing_time_ms = int((time.time() - start_time) * 1000)
            app.logger.info(f"Total processing time: {processing_time_ms}ms") # ADDED LOG           
            return jsonify({
                "status": "success", 
                "extracted_text": text,
                "processing_time_ms": processing_time_ms
            }), 200

        except pytesseract.TesseractNotFoundError:
            app.logger.error("Tesseract is not installed or not in your PATH.")
            return jsonify({"status": "error", "message": "OCR engine (Tesseract) not found on server."}), 500
        except subprocess.CalledProcessError as e:
            app.logger.error(f"PDF processing error: {e}")
            return jsonify({"status": "error", "message": f"PDF processing failed: {e.stderr if e.stderr else e}"}), 500
        except Exception as e:
            app.logger.error(f"Error during OCR processing: {e}")
            return jsonify({"status": "error", "message": f"An error occurred: {str(e)}"}), 500
        finally:
            # Clean up temporary files and directory
            try:
                for f_name in os.listdir(temp_dir):
                    os.remove(os.path.join(temp_dir, f_name))
                os.rmdir(temp_dir)
            except Exception as e_clean:
                app.logger.error(f"Error cleaning up temp files: {e_clean}")
    else:
        return jsonify({"status": "error", "message": "File type not allowed."}), 400

if __name__ == "__main__":
    # Make sure to install flask, pytesseract, Pillow, opencv-python
    # For PDF: sudo apt-get install poppler-utils tesseract-ocr
    app.run(host="0.0.0.0", port=5001, debug=True) # Port 5001 for OCR service


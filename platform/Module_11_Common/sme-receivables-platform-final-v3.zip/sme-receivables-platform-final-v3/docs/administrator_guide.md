# Administrator Guide - SME Receivables Management Platform

## Introduction

This Administrator Guide provides comprehensive information for system administrators to deploy, configure, maintain, and troubleshoot the SME Receivables Management Platform. This guide assumes familiarity with Docker, database management, and basic system administration concepts.

## System Architecture Overview

The SME Receivables Management Platform is built using a microservices architecture with the following components:

- **API Gateway**: NGINX serving as the entry point for all requests
- **Backend API**: Node.js application providing RESTful API services
- **Frontend**: React-based single-page application
- **Databases**: PostgreSQL for operational data, ClickHouse for analytics
- **Storage**: MinIO for document storage
- **Cache**: Redis for session management and caching
- **AI Agent Framework**: Orchestrates multiple specialized AI agents

## Deployment

### Prerequisites

- Docker and Docker Compose (version 1.29.0 or higher)
- Minimum 4GB RAM, 2 CPU cores
- 20GB free disk space
- Internet connectivity for pulling Docker images
- Domain name with DNS configured (for production)
- SSL certificate (for production)

### Deployment Options

#### Development Environment

1. Clone the repository
2. Create a `.env` file with development configuration
3. Run `docker-compose up -d`
4. Access the application at http://localhost:8080

#### Production Environment

1. Clone the repository
2. Create a `.env` file with production configuration
3. Set up SSL certificates
4. Run `docker-compose -f docker-compose.prod.yml up -d`
5. Configure a firewall to allow only ports 80 and 443
6. Set up monitoring and backup solutions

### Environment Variables

The following environment variables must be configured:

| Variable | Description | Example |
|----------|-------------|---------|
| DATABASE_URL | PostgreSQL connection string | postgres://postgres:password@postgres:5432/sme_receivables |
| POSTGRES_USER | PostgreSQL username | postgres |
| POSTGRES_PASSWORD | PostgreSQL password | secure_password |
| POSTGRES_DB | PostgreSQL database name | sme_receivables |
| JWT_SECRET | Secret for JWT token generation | random_secure_string |
| REDIS_URL | Redis connection string | redis://redis:6379 |
| MINIO_ROOT_USER | MinIO admin username | minioadmin |
| MINIO_ROOT_PASSWORD | MinIO admin password | secure_password |
| MINIO_ENDPOINT | MinIO service hostname | minio |
| MINIO_PORT | MinIO service port | 9000 |
| MINIO_USE_SSL | Whether to use SSL for MinIO | false |
| MINIO_BUCKET | MinIO bucket name | sme-receivables |
| PORT | Backend API port | 3000 |
| NODE_ENV | Environment (development/production) | production |

## System Configuration

### Multi-Tenancy Configuration

The platform supports multi-tenancy with the following isolation levels:

1. **Database-level isolation**: Each tenant gets a separate schema in PostgreSQL
2. **Application-level isolation**: Tenant-specific configurations and customizations

To configure a new tenant:

1. Access the Admin Portal at `/admin`
2. Navigate to "Tenants" > "Add New Tenant"
3. Provide tenant details and select isolation level
4. The system will automatically provision the necessary resources

### AI Agent Configuration

The platform uses multiple specialized AI agents that can be configured:

1. Access the Admin Portal at `/admin`
2. Navigate to "AI Configuration" > "Agent Settings"
3. For each agent, you can configure:
   - Model selection (Deepseek R1 is the default)
   - Confidence thresholds
   - Rate limiting
   - Custom prompts and templates

### Integration Configuration

Configure integrations with external systems:

1. Access the Admin Portal at `/admin`
2. Navigate to "Integrations"
3. Select the integration type (Accounting, Banking, Payment Gateway)
4. Provide the necessary API credentials and endpoints
5. Test the connection before saving

## User Management

### User Roles

The platform supports the following user roles:

- **System Administrator**: Full access to all features and settings
- **Tenant Administrator**: Full access within a specific tenant
- **Manager**: Access to all business functions but limited administrative capabilities
- **User**: Basic access to day-to-day operations
- **Viewer**: Read-only access to reports and dashboards

### Managing Users

1. Access the Admin Portal at `/admin`
2. Navigate to "Users" > "User Management"
3. Create, edit, or deactivate user accounts
4. Assign roles and permissions
5. Reset passwords if needed

### Authentication Configuration

The platform supports multiple authentication methods:

1. **Local Authentication**: Username/password stored in the database
2. **SAML/SSO**: Integration with identity providers
3. **OAuth**: Support for Google, Microsoft, and other OAuth providers

To configure authentication:

1. Access the Admin Portal at `/admin`
2. Navigate to "Security" > "Authentication"
3. Enable/disable authentication methods
4. Configure the specific settings for each method

## Monitoring and Maintenance

### Health Monitoring

The platform provides health endpoints for monitoring:

- `/api/health`: Overall API health
- `/api/health/db`: Database connectivity
- `/api/health/cache`: Redis connectivity
- `/api/health/storage`: MinIO connectivity

Integrate these endpoints with your monitoring solution (Prometheus, Nagios, etc.).

### Log Management

Logs are output to stdout/stderr and can be collected using standard Docker log drivers.

For production, configure a log aggregation solution:

1. Update the Docker Compose file to use a logging driver (fluentd, syslog, etc.)
2. Configure log rotation to prevent disk space issues
3. Set up alerts for error-level logs

### Backup and Recovery

#### Database Backup

1. Use the provided backup script: `./deployment/backup.sh`
2. Schedule regular backups using cron
3. Store backups in a secure, off-site location
4. Regularly test the restoration process

#### Document Storage Backup

MinIO data should be backed up regularly:

1. Use MinIO's built-in replication features
2. Configure the backup script to include MinIO data
3. Consider using cloud storage for off-site backups

### System Updates

To update the platform:

1. Pull the latest code from the repository
2. Review the changelog for breaking changes
3. Back up the current system
4. Run `docker-compose down`
5. Run `docker-compose build`
6. Run `docker-compose up -d`
7. Verify the system is functioning correctly

## Performance Tuning

### Database Optimization

1. Increase PostgreSQL shared_buffers for better caching
2. Configure work_mem based on query complexity
3. Regularly run VACUUM and ANALYZE
4. Monitor slow queries and add indexes as needed

### Application Scaling

For higher load scenarios:

1. Increase the number of API container replicas
2. Implement a load balancer in front of the API containers
3. Consider sharding the database for very large deployments
4. Use a CDN for static assets

## Security Management

### SSL Configuration

For production environments, configure SSL:

1. Obtain an SSL certificate (Let's Encrypt or commercial)
2. Place the certificate files in `./docker/nginx/ssl/`
3. Update the NGINX configuration to use SSL
4. Redirect HTTP to HTTPS
5. Configure appropriate SSL security headers

### Data Encryption

The platform encrypts sensitive data:

1. Database encryption at rest (using PostgreSQL encryption features)
2. Document encryption in MinIO
3. All communications over TLS

### Security Auditing

1. Enable audit logging in the Admin Portal
2. Regularly review access logs
3. Configure alerts for suspicious activities
4. Perform periodic security assessments

## Troubleshooting

### Common Issues

#### Container Fails to Start

1. Check Docker logs: `docker-compose logs <service-name>`
2. Verify environment variables are correctly set
3. Ensure ports are not already in use
4. Check disk space and resource availability

#### Database Connection Issues

1. Verify PostgreSQL container is running
2. Check database credentials in the `.env` file
3. Ensure the database has been properly initialized
4. Check network connectivity between containers

#### API Performance Issues

1. Monitor API response times using the `/api/metrics` endpoint
2. Check database query performance
3. Verify Redis cache is functioning correctly
4. Scale API containers if needed

#### Authentication Problems

1. Check JWT secret configuration
2. Verify user credentials in the database
3. Review authentication logs for specific errors
4. Test SSO configuration if enabled

### Support Resources

For additional support:

1. Check the official documentation
2. Review known issues in the GitHub repository
3. Contact the support team at support@example.com

## Appendix

### Command Reference

- Start the system: `docker-compose up -d`
- Stop the system: `docker-compose down`
- View logs: `docker-compose logs -f [service]`
- Backup database: `./deployment/backup.sh`
- Monitor system: `./deployment/monitor.sh`

### Configuration File Reference

- `docker-compose.yml`: Development environment configuration
- `docker-compose.prod.yml`: Production environment configuration
- `.env`: Environment variables
- `nginx.conf`: NGINX configuration

---

This administrator guide is regularly updated. For the latest version, please check the official documentation repository.

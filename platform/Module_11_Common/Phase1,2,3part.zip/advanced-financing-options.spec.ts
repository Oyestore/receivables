import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Repository } from 'typeorm';
import { NbfcIntegrationService } from '../services/nbfc-integration.service';
import { EligibilityAssessmentService } from '../services/eligibility-assessment.service';
import { WorkingCapitalService } from '../services/working-capital.service';
import { SupplyChainFinanceService } from '../services/supply-chain-finance.service';
import { FinancingIntegrationService } from '../services/financing-integration.service';
import { FinancingRequest } from '../entities/financing-request.entity';
import { FinancingTransaction } from '../entities/financing-transaction.entity';
import { NbfcPartner } from '../entities/nbfc-partner.entity';
import { SupplyChainRelationship } from '../entities/supply-chain-relationship.entity';
import { Invoice } from '../../../invoices/entities/invoice.entity';
import { Customer } from '../../../customers/entities/customer.entity';
import { Organization } from '../../../organizations/entities/organization.entity';

describe('Advanced Financing Options Module', () => {
  let nbfcIntegrationService: NbfcIntegrationService;
  let eligibilityAssessmentService: EligibilityAssessmentService;
  let workingCapitalService: WorkingCapitalService;
  let supplyChainFinanceService: SupplyChainFinanceService;
  let financingIntegrationService: FinancingIntegrationService;
  let financingRequestRepository: Repository<FinancingRequest>;
  let financingTransactionRepository: Repository<FinancingTransaction>;
  let nbfcPartnerRepository: Repository<NbfcPartner>;
  let supplyChainRelationshipRepository: Repository<SupplyChainRelationship>;
  let invoiceRepository: Repository<Invoice>;
  let customerRepository: Repository<Customer>;
  let organizationRepository: Repository<Organization>;
  let eventEmitter: EventEmitter2;

  const mockFinancingRequestRepository = {
    findOne: jest.fn(),
    find: jest.fn(),
    create: jest.fn(),
    save: jest.fn(),
    update: jest.fn(),
  };

  const mockFinancingTransactionRepository = {
    findOne: jest.fn(),
    find: jest.fn(),
    create: jest.fn(),
    save: jest.fn(),
  };

  const mockNbfcPartnerRepository = {
    findOne: jest.fn(),
    find: jest.fn(),
    create: jest.fn(),
    save: jest.fn(),
  };

  const mockSupplyChainRelationshipRepository = {
    findOne: jest.fn(),
    find: jest.fn(),
    create: jest.fn(),
    save: jest.fn(),
  };

  const mockInvoiceRepository = {
    findOne: jest.fn(),
    find: jest.fn(),
    update: jest.fn(),
  };

  const mockCustomerRepository = {
    findOne: jest.fn(),
    find: jest.fn(),
  };

  const mockOrganizationRepository = {
    findOne: jest.fn(),
    find: jest.fn(),
  };

  const mockEventEmitter = {
    emit: jest.fn(),
    on: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        NbfcIntegrationService,
        EligibilityAssessmentService,
        WorkingCapitalService,
        SupplyChainFinanceService,
        FinancingIntegrationService,
        {
          provide: getRepositoryToken(FinancingRequest),
          useValue: mockFinancingRequestRepository,
        },
        {
          provide: getRepositoryToken(FinancingTransaction),
          useValue: mockFinancingTransactionRepository,
        },
        {
          provide: getRepositoryToken(NbfcPartner),
          useValue: mockNbfcPartnerRepository,
        },
        {
          provide: getRepositoryToken(SupplyChainRelationship),
          useValue: mockSupplyChainRelationshipRepository,
        },
        {
          provide: getRepositoryToken(Invoice),
          useValue: mockInvoiceRepository,
        },
        {
          provide: getRepositoryToken(Customer),
          useValue: mockCustomerRepository,
        },
        {
          provide: getRepositoryToken(Organization),
          useValue: mockOrganizationRepository,
        },
        {
          provide: EventEmitter2,
          useValue: mockEventEmitter,
        },
      ],
    }).compile();

    nbfcIntegrationService = module.get<NbfcIntegrationService>(NbfcIntegrationService);
    eligibilityAssessmentService = module.get<EligibilityAssessmentService>(EligibilityAssessmentService);
    workingCapitalService = module.get<WorkingCapitalService>(WorkingCapitalService);
    supplyChainFinanceService = module.get<SupplyChainFinanceService>(SupplyChainFinanceService);
    financingIntegrationService = module.get<FinancingIntegrationService>(FinancingIntegrationService);
    financingRequestRepository = module.get<Repository<FinancingRequest>>(getRepositoryToken(FinancingRequest));
    financingTransactionRepository = module.get<Repository<FinancingTransaction>>(getRepositoryToken(FinancingTransaction));
    nbfcPartnerRepository = module.get<Repository<NbfcPartner>>(getRepositoryToken(NbfcPartner));
    supplyChainRelationshipRepository = module.get<Repository<SupplyChainRelationship>>(getRepositoryToken(SupplyChainRelationship));
    invoiceRepository = module.get<Repository<Invoice>>(getRepositoryToken(Invoice));
    customerRepository = module.get<Repository<Customer>>(getRepositoryToken(Customer));
    organizationRepository = module.get<Repository<Organization>>(getRepositoryToken(Organization));
    eventEmitter = module.get<EventEmitter2>(EventEmitter2);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('NBFC Integration Service', () => {
    const organizationId = 'org-123';
    const partnerId = 'nbfc-456';
    
    const mockNbfcPartner = {
      id: partnerId,
      organizationId,
      name: 'Test NBFC Partner',
      apiKey: 'test-api-key',
      apiEndpoint: 'https://api.testnbfc.com',
      status: 'active',
      interestRateRange: { min: 8.5, max: 14.0 },
      processingFeePercentage: 1.0,
      maxFinancingPercentage: 80,
      minFinancingAmount: 10000,
      maxFinancingAmount: 1000000,
      averageProcessingTime: 24,
      supportedFinancingTypes: ['invoice_financing', 'working_capital'],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const mockFinancingRequest = {
      id: 'req-789',
      organizationId,
      partnerId,
      invoiceIds: ['inv-123'],
      customerId: 'cust-456',
      requestType: 'invoice_financing',
      requestAmount: 50000,
      requestDate: new Date(),
      status: 'pending',
      statusHistory: [],
      interestRate: 10.5,
      processingFee: 500,
      tenure: 30,
      repaymentSchedule: [],
      documents: [],
      metadata: {},
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    it('should register NBFC partner', async () => {
      // Mock repository methods
      mockNbfcPartnerRepository.create.mockReturnValue({ ...mockNbfcPartner, id: undefined });
      mockNbfcPartnerRepository.save.mockResolvedValue(mockNbfcPartner);

      const partnerData = {
        name: 'Test NBFC Partner',
        apiKey: 'test-api-key',
        apiEndpoint: 'https://api.testnbfc.com',
        interestRateRange: { min: 8.5, max: 14.0 },
        processingFeePercentage: 1.0,
        maxFinancingPercentage: 80,
        minFinancingAmount: 10000,
        maxFinancingAmount: 1000000,
        supportedFinancingTypes: ['invoice_financing', 'working_capital'],
      };

      const result = await nbfcIntegrationService.registerNbfcPartner(organizationId, partnerData);

      expect(result).toEqual(mockNbfcPartner);
      expect(mockNbfcPartnerRepository.create).toHaveBeenCalled();
      expect(mockNbfcPartnerRepository.save).toHaveBeenCalled();
      expect(mockEventEmitter.emit).toHaveBeenCalledWith('financing.partner.registered', mockNbfcPartner);
    });

    it('should submit financing request to NBFC', async () => {
      // Mock repository methods
      mockNbfcPartnerRepository.findOne.mockResolvedValue(mockNbfcPartner);
      mockFinancingRequestRepository.create.mockReturnValue({ ...mockFinancingRequest, id: undefined });
      mockFinancingRequestRepository.save.mockResolvedValue(mockFinancingRequest);
      
      // Mock invoice repository
      mockInvoiceRepository.findOne.mockResolvedValue({
        id: 'inv-123',
        customerId: 'cust-456',
        totalAmount: 62500, // 80% of this is 50000
        status: 'issued',
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      });
      
      // Mock NBFC API call
      jest.spyOn(nbfcIntegrationService as any, 'callNbfcApi').mockResolvedValue({
        requestId: 'ext-req-123',
        status: 'received',
        estimatedProcessingTime: 24,
      });

      const requestData = {
        partnerId,
        invoiceIds: ['inv-123'],
        requestType: 'invoice_financing',
      };

      const result = await nbfcIntegrationService.submitFinancingRequest(organizationId, requestData);

      expect(result).toEqual(mockFinancingRequest);
      expect(mockNbfcPartnerRepository.findOne).toHaveBeenCalledWith({
        where: { id: partnerId, organizationId },
      });
      expect(mockInvoiceRepository.findOne).toHaveBeenCalledWith({
        where: { id: 'inv-123' },
      });
      expect(mockFinancingRequestRepository.create).toHaveBeenCalled();
      expect(mockFinancingRequestRepository.save).toHaveBeenCalled();
      expect(mockEventEmitter.emit).toHaveBeenCalledWith('financing.request.submitted', mockFinancingRequest);
    });

    it('should check financing request status', async () => {
      // Mock repository methods
      mockFinancingRequestRepository.findOne.mockResolvedValue(mockFinancingRequest);
      mockNbfcPartnerRepository.findOne.mockResolvedValue(mockNbfcPartner);
      
      // Mock NBFC API call
      jest.spyOn(nbfcIntegrationService as any, 'callNbfcApi').mockResolvedValue({
        requestId: 'ext-req-123',
        status: 'approved',
        approvedAmount: 50000,
        interestRate: 10.5,
        processingFee: 500,
        tenure: 30,
        repaymentSchedule: [
          { date: '2025-06-28', amount: 51750 },
        ],
      });
      
      // Mock update methods
      mockFinancingRequestRepository.save.mockResolvedValue({
        ...mockFinancingRequest,
        status: 'approved',
        statusHistory: [
          { status: 'pending', date: mockFinancingRequest.requestDate },
          { status: 'approved', date: new Date() },
        ],
      });

      const result = await nbfcIntegrationService.checkFinancingRequestStatus(organizationId, 'req-789');

      expect(result.status).toEqual('approved');
      expect(mockFinancingRequestRepository.findOne).toHaveBeenCalledWith({
        where: { id: 'req-789', organizationId },
        relations: ['partner'],
      });
      expect(mockFinancingRequestRepository.save).toHaveBeenCalled();
      expect(mockEventEmitter.emit).toHaveBeenCalledWith('financing.request.statusChanged', expect.any(Object));
    });
  });

  describe('Eligibility Assessment Service', () => {
    const organizationId = 'org-123';
    const customerId = 'cust-456';
    const invoiceId = 'inv-789';
    
    it('should assess invoice financing eligibility', async () => {
      // Mock invoice repository
      mockInvoiceRepository.findOne.mockResolvedValue({
        id: invoiceId,
        customerId,
        totalAmount: 100000,
        status: 'issued',
        dueDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000), // 45 days from now
        createdAt: new Date(),
      });
      
      // Mock customer repository
      mockCustomerRepository.findOne.mockResolvedValue({
        id: customerId,
        name: 'Test Customer',
        creditScore: 750,
        paymentHistory: {
          totalInvoices: 10,
          paidOnTime: 8,
          averagePaymentDelay: 5,
        },
      });
      
      // Mock organization repository
      mockOrganizationRepository.findOne.mockResolvedValue({
        id: organizationId,
        name: 'Test Organization',
        businessType: 'manufacturing',
        yearEstablished: 2010,
        annualRevenue: 5000000,
      });
      
      // Mock NBFC partners
      mockNbfcPartnerRepository.find.mockResolvedValue([
        {
          id: 'nbfc-1',
          name: 'NBFC Partner 1',
          interestRateRange: { min: 9.0, max: 12.0 },
          processingFeePercentage: 1.0,
          maxFinancingPercentage: 80,
          minFinancingAmount: 10000,
          maxFinancingAmount: 500000,
          supportedFinancingTypes: ['invoice_financing'],
        },
        {
          id: 'nbfc-2',
          name: 'NBFC Partner 2',
          interestRateRange: { min: 10.0, max: 14.0 },
          processingFeePercentage: 0.5,
          maxFinancingPercentage: 90,
          minFinancingAmount: 50000,
          maxFinancingAmount: 1000000,
          supportedFinancingTypes: ['invoice_financing', 'working_capital'],
        },
      ]);

      const result = await eligibilityAssessmentService.assessInvoiceFinancingEligibility(
        organizationId,
        invoiceId,
      );

      expect(result.eligible).toBe(true);
      expect(result.eligibilityScore).toBeGreaterThan(0);
      expect(result.maxFinancingPercentage).toBeGreaterThan(0);
      expect(result.maxFinancingAmount).toBeGreaterThan(0);
      expect(result.estimatedInterestRate).toBeGreaterThan(0);
      expect(result.recommendedPartners).toHaveLength(2);
      expect(result.factors).toBeDefined();
      expect(mockInvoiceRepository.findOne).toHaveBeenCalledWith({
        where: { id: invoiceId, organizationId },
      });
      expect(mockCustomerRepository.findOne).toHaveBeenCalled();
      expect(mockOrganizationRepository.findOne).toHaveBeenCalled();
      expect(mockNbfcPartnerRepository.find).toHaveBeenCalled();
    });

    it('should assess working capital financing eligibility', async () => {
      // Mock organization repository
      mockOrganizationRepository.findOne.mockResolvedValue({
        id: organizationId,
        name: 'Test Organization',
        businessType: 'manufacturing',
        yearEstablished: 2010,
        annualRevenue: 5000000,
        financialData: {
          currentAssets: 2000000,
          currentLiabilities: 1000000,
          totalRevenueLast12Months: 5000000,
          averageMonthlyRevenue: 416666,
          cashBalance: 500000,
        },
      });
      
      // Mock invoice repository for recent invoices
      mockInvoiceRepository.find.mockResolvedValue([
        { id: 'inv-1', totalAmount: 100000, status: 'paid', createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        { id: 'inv-2', totalAmount: 150000, status: 'paid', createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000) },
        { id: 'inv-3', totalAmount: 200000, status: 'issued', createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000) },
      ]);
      
      // Mock NBFC partners
      mockNbfcPartnerRepository.find.mockResolvedValue([
        {
          id: 'nbfc-2',
          name: 'NBFC Partner 2',
          interestRateRange: { min: 10.0, max: 14.0 },
          processingFeePercentage: 0.5,
          maxFinancingPercentage: 90,
          minFinancingAmount: 50000,
          maxFinancingAmount: 1000000,
          supportedFinancingTypes: ['invoice_financing', 'working_capital'],
        },
        {
          id: 'nbfc-3',
          name: 'NBFC Partner 3',
          interestRateRange: { min: 11.0, max: 16.0 },
          processingFeePercentage: 0.75,
          maxFinancingPercentage: 70,
          minFinancingAmount: 100000,
          maxFinancingAmount: 2000000,
          supportedFinancingTypes: ['working_capital'],
        },
      ]);

      const result = await eligibilityAssessmentService.assessWorkingCapitalEligibility(
        organizationId,
        { requestedAmount: 500000, tenure: 180 },
      );

      expect(result.eligible).toBe(true);
      expect(result.eligibilityScore).toBeGreaterThan(0);
      
(Content truncated due to size limit. Use line ranges to read in chunks)
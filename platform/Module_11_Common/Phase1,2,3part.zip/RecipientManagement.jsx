import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Snackbar,
  Alert
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { CommunicationChannel } from '../../distribution/entities/recipient-contact.entity';

function RecipientManagement({ organizationId }) {
  const [recipients, setRecipients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [currentRecipient, setCurrentRecipient] = useState(null);
  const [formData, setFormData] = useState({
    recipientName: '',
    email: '',
    phone: '',
    whatsappNumber: '',
    preferredChannel: 'EMAIL',
    organizationId: organizationId
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  useEffect(() => {
    fetchRecipients();
  }, [organizationId]);

  const fetchRecipients = async () => {
    setLoading(true);
    try {
      // In a real implementation, this would be an API call
      // For now, we'll use mock data
      const mockRecipients = [
        {
          id: 'rec-1',
          recipientName: 'John Doe',
          email: 'john.doe@example.com',
          phone: '+1234567890',
          whatsappNumber: '+1234567890',
          preferredChannel: 'EMAIL',
          organizationId: organizationId
        },
        {
          id: 'rec-2',
          recipientName: 'Jane Smith',
          email: 'jane.smith@example.com',
          phone: '+0987654321',
          whatsappNumber: '+0987654321',
          preferredChannel: 'WHATSAPP',
          organizationId: organizationId
        }
      ];
      
      setRecipients(mockRecipients);
      setError(null);
    } catch (err) {
      setError('Failed to fetch recipients: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (recipient = null) => {
    if (recipient) {
      setCurrentRecipient(recipient);
      setFormData({
        recipientName: recipient.recipientName,
        email: recipient.email,
        phone: recipient.phone || '',
        whatsappNumber: recipient.whatsappNumber || '',
        preferredChannel: recipient.preferredChannel,
        organizationId: organizationId
      });
    } else {
      setCurrentRecipient(null);
      setFormData({
        recipientName: '',
        email: '',
        phone: '',
        whatsappNumber: '',
        preferredChannel: 'EMAIL',
        organizationId: organizationId
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async () => {
    try {
      if (currentRecipient) {
        // Update existing recipient
        // In a real implementation, this would be an API call
        const updatedRecipients = recipients.map(r => 
          r.id === currentRecipient.id ? { ...r, ...formData } : r
        );
        setRecipients(updatedRecipients);
        setSnackbar({
          open: true,
          message: 'Recipient updated successfully',
          severity: 'success'
        });
      } else {
        // Create new recipient
        // In a real implementation, this would be an API call
        const newRecipient = {
          id: `rec-${Date.now()}`,
          ...formData
        };
        setRecipients([...recipients, newRecipient]);
        setSnackbar({
          open: true,
          message: 'Recipient created successfully',
          severity: 'success'
        });
      }
      handleCloseDialog();
    } catch (err) {
      setSnackbar({
        open: true,
        message: 'Error: ' + err.message,
        severity: 'error'
      });
    }
  };

  const handleDelete = async (id) => {
    try {
      // In a real implementation, this would be an API call
      const updatedRecipients = recipients.filter(r => r.id !== id);
      setRecipients(updatedRecipients);
      setSnackbar({
        open: true,
        message: 'Recipient deleted successfully',
        severity: 'success'
      });
    } catch (err) {
      setSnackbar({
        open: true,
        message: 'Error: ' + err.message,
        severity: 'error'
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Recipient Management</Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          Add Recipient
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Phone</TableCell>
              <TableCell>WhatsApp</TableCell>
              <TableCell>Preferred Channel</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {recipients.map((recipient) => (
              <TableRow key={recipient.id}>
                <TableCell>{recipient.recipientName}</TableCell>
                <TableCell>{recipient.email}</TableCell>
                <TableCell>{recipient.phone || 'N/A'}</TableCell>
                <TableCell>{recipient.whatsappNumber || 'N/A'}</TableCell>
                <TableCell>{recipient.preferredChannel}</TableCell>
                <TableCell>
                  <IconButton onClick={() => handleOpenDialog(recipient)}>
                    <EditIcon />
                  </IconButton>
                  <IconButton onClick={() => handleDelete(recipient.id)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
            {recipients.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} align="center">
                  No recipients found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>
          {currentRecipient ? 'Edit Recipient' : 'Add Recipient'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2, minWidth: '400px' }}>
            <TextField
              name="recipientName"
              label="Recipient Name"
              value={formData.recipientName}
              onChange={handleInputChange}
              fullWidth
              required
            />
            <TextField
              name="email"
              label="Email"
              type="email"
              value={formData.email}
              onChange={handleInputChange}
              fullWidth
              required
            />
            <TextField
              name="phone"
              label="Phone Number"
              value={formData.phone}
              onChange={handleInputChange}
              fullWidth
            />
            <TextField
              name="whatsappNumber"
              label="WhatsApp Number"
              value={formData.whatsappNumber}
              onChange={handleInputChange}
              fullWidth
            />
            <FormControl fullWidth>
              <InputLabel>Preferred Channel</InputLabel>
              <Select
                name="preferredChannel"
                value={formData.preferredChannel}
                onChange={handleInputChange}
              >
                <MenuItem value="EMAIL">Email</MenuItem>
                <MenuItem value="WHATSAPP">WhatsApp</MenuItem>
                <MenuItem value="SMS">SMS</MenuItem>
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained">
            {currentRecipient ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default RecipientManagement;

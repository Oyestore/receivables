import unittest
import requests
import json
import time

class TestSMEReceivablesAPI(unittest.TestCase):
    """Test suite for SME Receivables Management Platform API"""
    
    BASE_URL = "http://localhost:8080/api"
    token = None
    
    @classmethod
    def setUpClass(cls):
        """Set up test class - wait for API to be available"""
        max_retries = 10
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                response = requests.get(f"{cls.BASE_URL}/health")
                if response.status_code == 200:
                    print("API is available, proceeding with tests")
                    return
            except requests.exceptions.ConnectionError:
                pass
            
            print(f"API not available yet, retrying in 5 seconds (attempt {retry_count + 1}/{max_retries})")
            time.sleep(5)
            retry_count += 1
        
        raise Exception("API is not available after maximum retries")
    
    def test_01_health_endpoint(self):
        """Test the health endpoint"""
        response = requests.get(f"{self.BASE_URL}/health")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "ok")
        self.assertIn("timestamp", data)
    
    def test_02_login_with_valid_credentials(self):
        """Test login with valid credentials"""
        payload = {
            "email": "admin@demo.com",
            "password": "admin123"
        }
        response = requests.post(f"{self.BASE_URL}/auth/login", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("token", data)
        self.assertIn("user", data)
        self.assertEqual(data["user"]["email"], "admin@demo.com")
        
        # Save token for subsequent tests
        TestSMEReceivablesAPI.token = data["token"]
    
    def test_03_login_with_invalid_credentials(self):
        """Test login with invalid credentials"""
        payload = {
            "email": "admin@demo.com",
            "password": "wrongpassword"
        }
        response = requests.post(f"{self.BASE_URL}/auth/login", json=payload)
        self.assertEqual(response.status_code, 401)
    
    def test_04_get_users_authenticated(self):
        """Test getting users with authentication"""
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(f"{self.BASE_URL}/users", headers=headers)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIsInstance(data, list)
        # At least the admin user should be present
        self.assertGreaterEqual(len(data), 1)
    
    def test_05_get_users_unauthenticated(self):
        """Test getting users without authentication"""
        response = requests.get(f"{self.BASE_URL}/users")
        self.assertEqual(response.status_code, 401)
    
    def test_06_get_organizations(self):
        """Test getting organizations"""
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(f"{self.BASE_URL}/organizations", headers=headers)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIsInstance(data, list)
        # At least the demo organizations should be present
        self.assertGreaterEqual(len(data), 2)
    
    def test_07_get_invoices(self):
        """Test getting invoices"""
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(f"{self.BASE_URL}/invoices", headers=headers)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIsInstance(data, list)
        # At least the demo invoice should be present
        self.assertGreaterEqual(len(data), 1)
    
    def test_08_create_organization(self):
        """Test creating a new organization"""
        headers = {"Authorization": f"Bearer {self.token}"}
        payload = {
            "name": "Test Organization",
            "type": "buyer",
            "tax_id": "TEST123456",
            "address": "123 Test Street",
            "city": "Test City",
            "state": "Test State",
            "postal_code": "123456",
            "country": "India",
            "phone": "1234567890",
            "email": "test@example.com",
            "website": "https://example.com"
        }
        response = requests.post(f"{self.BASE_URL}/organizations", json=payload, headers=headers)
        self.assertEqual(response.status_code, 201)
        data = response.json()
        self.assertEqual(data["name"], "Test Organization")
        self.assertEqual(data["type"], "buyer")
        self.assertEqual(data["tax_id"], "TEST123456")
    
    def test_09_create_invoice(self):
        """Test creating a new invoice"""
        # First get organizations to use their IDs
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(f"{self.BASE_URL}/organizations", headers=headers)
        orgs = response.json()
        
        sme_id = next((org["id"] for org in orgs if org["type"] == "sme"), None)
        buyer_id = next((org["id"] for org in orgs if org["type"] == "buyer"), None)
        
        self.assertIsNotNone(sme_id, "No SME organization found")
        self.assertIsNotNone(buyer_id, "No buyer organization found")
        
        payload = {
            "invoice_number": f"TEST-{int(time.time())}",
            "sme_id": sme_id,
            "buyer_id": buyer_id,
            "amount": 5000,
            "currency": "INR",
            "issue_date": "2025-04-23",
            "due_date": "2025-05-23",
            "payment_terms": "Net 30",
            "description": "Test invoice created by automated tests"
        }
        
        response = requests.post(f"{self.BASE_URL}/invoices", json=payload, headers=headers)
        self.assertEqual(response.status_code, 201)
        data = response.json()
        self.assertEqual(data["invoice_number"], payload["invoice_number"])
        self.assertEqual(float(data["amount"]), payload["amount"])
        self.assertEqual(data["currency"], payload["currency"])

if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/bin/bash

# Deployment script for SME Receivables Management Platform
echo "Starting deployment for SME Receivables Management Platform..."

# Create deployment directory
mkdir -p /home/ubuntu/sme-receivables-platform/deployment
cd /home/ubuntu/sme-receivables-platform

# Create deployment configuration
echo "Creating deployment configuration..."
cat > deployment/deployment_guide.md << EOL
# Deployment Guide for SME Receivables Management Platform

## Prerequisites
- Docker and Docker Compose installed
- At least 4GB RAM and 2 CPU cores
- 20GB free disk space
- Internet connectivity for pulling Docker images

## Deployment Steps

### 1. Clone the Repository
\`\`\`bash
git clone <repository-url>
cd sme-receivables-platform
\`\`\`

### 2. Configure Environment Variables
Create a .env file in the root directory with the following variables:
\`\`\`
# Database Configuration
DATABASE_URL=postgres://postgres:<your-password>@postgres:5432/sme_receivables
POSTGRES_USER=postgres
POSTGRES_PASSWORD=<your-password>
POSTGRES_DB=sme_receivables

# JWT Configuration
JWT_SECRET=<your-jwt-secret>

# Redis Configuration
REDIS_URL=redis://redis:6379

# MinIO Configuration
MINIO_ROOT_USER=<your-minio-user>
MINIO_ROOT_PASSWORD=<your-minio-password>
MINIO_ENDPOINT=minio
MINIO_PORT=9000
MINIO_USE_SSL=false
MINIO_BUCKET=sme-receivables

# API Configuration
PORT=3000
NODE_ENV=production
\`\`\`

### 3. Build and Start the Containers
\`\`\`bash
docker-compose build
docker-compose up -d
\`\`\`

### 4. Verify Deployment
\`\`\`bash
docker-compose ps
\`\`\`

All containers should be in the "Up" state.

### 5. Access the Application
- Web Interface: http://<your-server-ip>:8080
- API: http://<your-server-ip>:8080/api

### 6. Default Login Credentials
- Email: admin@demo.com
- Password: admin123

**Important:** Change the default password immediately after first login.

## Maintenance

### Updating the Application
\`\`\`bash
git pull
docker-compose down
docker-compose build
docker-compose up -d
\`\`\`

### Backup Database
\`\`\`bash
docker-compose exec postgres pg_dump -U postgres sme_receivables > backup.sql
\`\`\`

### Restore Database
\`\`\`bash
cat backup.sql | docker-compose exec -T postgres psql -U postgres sme_receivables
\`\`\`

### Viewing Logs
\`\`\`bash
docker-compose logs -f
\`\`\`

## Troubleshooting

### Container Fails to Start
Check the logs:
\`\`\`bash
docker-compose logs <service-name>
\`\`\`

### Database Connection Issues
Verify the database is running:
\`\`\`bash
docker-compose ps postgres
\`\`\`

### API Not Responding
Check API logs:
\`\`\`bash
docker-compose logs api
\`\`\`

## Security Considerations
- Change all default passwords
- Use HTTPS in production
- Regularly update dependencies
- Implement proper network security
- Set up regular backups
EOL

# Create production docker-compose file
echo "Creating production docker-compose file..."
cat > deployment/docker-compose.prod.yml << EOL
version: '3.8'

services:
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./docker/nginx/nginx.conf:/etc/nginx/conf.d/default.conf
      - ./docker/nginx/ssl:/etc/nginx/ssl
    depends_on:
      - api
      - frontend
    restart: always
    networks:
      - sme-network

  api:
    build:
      context: ./backend
      dockerfile: Dockerfile
    environment:
      - DATABASE_URL=\${DATABASE_URL}
      - JWT_SECRET=\${JWT_SECRET}
      - REDIS_URL=\${REDIS_URL}
      - MINIO_ENDPOINT=\${MINIO_ENDPOINT}
      - MINIO_PORT=\${MINIO_PORT}
      - MINIO_USE_SSL=\${MINIO_USE_SSL}
      - MINIO_ROOT_USER=\${MINIO_ROOT_USER}
      - MINIO_ROOT_PASSWORD=\${MINIO_ROOT_PASSWORD}
      - MINIO_BUCKET=\${MINIO_BUCKET}
      - NODE_ENV=production
      - PORT=\${PORT}
    depends_on:
      - postgres
      - redis
      - minio
    restart: always
    networks:
      - sme-network

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    restart: always
    networks:
      - sme-network

  postgres:
    image: postgres:14-alpine
    environment:
      - POSTGRES_USER=\${POSTGRES_USER}
      - POSTGRES_PASSWORD=\${POSTGRES_PASSWORD}
      - POSTGRES_DB=\${POSTGRES_DB}
    volumes:
      - postgres-data:/var/lib/postgresql/data
      - ./docker/postgres/init.sql:/docker-entrypoint-initdb.d/init.sql
    restart: always
    networks:
      - sme-network

  redis:
    image: redis:alpine
    volumes:
      - redis-data:/data
    restart: always
    networks:
      - sme-network

  minio:
    image: minio/minio
    environment:
      - MINIO_ROOT_USER=\${MINIO_ROOT_USER}
      - MINIO_ROOT_PASSWORD=\${MINIO_ROOT_PASSWORD}
    volumes:
      - minio-data:/data
    command: server /data --console-address ":9001"
    restart: always
    networks:
      - sme-network

networks:
  sme-network:
    driver: bridge

volumes:
  postgres-data:
  redis-data:
  minio-data:
EOL

# Create SSL configuration for production
echo "Creating SSL configuration for production..."
mkdir -p deployment/ssl
cat > deployment/ssl_setup.sh << EOL
#!/bin/bash

# Script to set up SSL for production deployment
# This is a placeholder - in production, you would use Let's Encrypt or a commercial SSL certificate

# Create directory for SSL certificates
mkdir -p ./docker/nginx/ssl

# Generate self-signed certificate (for testing only)
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout ./docker/nginx/ssl/nginx.key \
  -out ./docker/nginx/ssl/nginx.crt \
  -subj "/C=IN/ST=State/L=City/O=Organization/CN=example.com"

# Update nginx configuration to use SSL
cat > ./docker/nginx/nginx.conf << EOF
server {
    listen 80;
    server_name localhost;
    
    # Redirect all HTTP requests to HTTPS
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl;
    server_name localhost;
    
    ssl_certificate /etc/nginx/ssl/nginx.crt;
    ssl_certificate_key /etc/nginx/ssl/nginx.key;
    
    # SSL configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;
    ssl_session_timeout 10m;
    ssl_session_cache shared:SSL:10m;
    ssl_session_tickets off;
    
    # API routes
    location /api/ {
        proxy_pass http://api:3000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
    
    # Frontend routes
    location / {
        proxy_pass http://frontend:80/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

echo "SSL configuration completed. In production, replace the self-signed certificate with a valid one."
EOL

chmod +x deployment/ssl_setup.sh

# Create backup script
echo "Creating backup script..."
cat > deployment/backup.sh << EOL
#!/bin/bash

# Backup script for SME Receivables Management Platform
BACKUP_DIR="./backups"
TIMESTAMP=\$(date +"%Y%m%d_%H%M%S")

# Create backup directory if it doesn't exist
mkdir -p \$BACKUP_DIR

# Backup database
echo "Backing up PostgreSQL database..."
docker-compose exec -T postgres pg_dump -U postgres sme_receivables > "\$BACKUP_DIR/db_backup_\$TIMESTAMP.sql"

# Backup MinIO data
echo "Backing up MinIO data..."
mkdir -p "\$BACKUP_DIR/minio_backup_\$TIMESTAMP"
docker-compose exec -T minio sh -c "mc cp -r /data \$BACKUP_DIR/minio_backup_\$TIMESTAMP"

# Compress backups
echo "Compressing backups..."
tar -czf "\$BACKUP_DIR/full_backup_\$TIMESTAMP.tar.gz" "\$BACKUP_DIR/db_backup_\$TIMESTAMP.sql" "\$BACKUP_DIR/minio_backup_\$TIMESTAMP"

# Clean up temporary files
rm -rf "\$BACKUP_DIR/db_backup_\$TIMESTAMP.sql" "\$BACKUP_DIR/minio_backup_\$TIMESTAMP"

echo "Backup completed: \$BACKUP_DIR/full_backup_\$TIMESTAMP.tar.gz"
EOL

chmod +x deployment/backup.sh

# Create monitoring script
echo "Creating monitoring script..."
cat > deployment/monitor.sh << EOL
#!/bin/bash

# Monitoring script for SME Receivables Management Platform
echo "Monitoring SME Receivables Management Platform..."

# Check container status
echo "Container Status:"
docker-compose ps

# Check container resource usage
echo -e "\nContainer Resource Usage:"
docker stats --no-stream

# Check disk space
echo -e "\nDisk Space Usage:"
df -h

# Check memory usage
echo -e "\nMemory Usage:"
free -h

# Check API health
echo -e "\nAPI Health Check:"
curl -s http://localhost:8080/api/health | jq .

echo -e "\nMonitoring completed."
EOL

chmod +x deployment/monitor.sh

echo "Deployment configuration completed. See deployment directory for details."
exit 0

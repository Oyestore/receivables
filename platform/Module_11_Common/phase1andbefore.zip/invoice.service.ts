import { Injectable, NotFoundException, BadRequestException, InternalServerErrorException } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository, DeepPartial } from "typeorm";
import { Invoice } from "../entities/invoice.entity";
import { InvoiceLineItem } from "../entities/invoice-line-item.entity";
import { CreateInvoiceDto, UpdateInvoiceDto, CreateInvoiceLineItemDto, UpdateInvoiceLineItemDto } from "../dto/invoice.dto";

@Injectable()
export class InvoiceService {
  constructor(
    @InjectRepository(Invoice)
    private readonly invoiceRepository: Repository<Invoice>,
    @InjectRepository(InvoiceLineItem)
    private readonly lineItemRepository: Repository<InvoiceLineItem>,
  ) {}

  private calculateTotals(invoice: DeepPartial<Invoice>): DeepPartial<Invoice> {
    let sub_total = 0;
    let total_tax_amount = 0;
    let total_discount_amount = 0;

    if (invoice.line_items) {
      for (const item of invoice.line_items) {
        item.item_sub_total = (item.quantity || 0) * (item.unit_price || 0);
        item.tax_amount = item.tax_amount || 0;
        item.discount_amount = item.discount_amount || 0;
        item.line_total = item.item_sub_total + item.tax_amount - item.discount_amount;

        sub_total += item.item_sub_total;
        total_tax_amount += item.tax_amount;
        total_discount_amount += item.discount_amount;
      }
    }

    invoice.sub_total = sub_total;
    invoice.total_tax_amount = total_tax_amount;
    invoice.total_discount_amount = total_discount_amount;
    invoice.grand_total = sub_total + total_tax_amount - total_discount_amount;
    invoice.balance_due = invoice.grand_total - (invoice.amount_paid || 0);
    return invoice;
  }

  async create(createInvoiceDto: CreateInvoiceDto): Promise<Invoice> {
    try {
      const invoiceData = this.invoiceRepository.create(createInvoiceDto as DeepPartial<Invoice>); // Cast to DeepPartial
      
      // Calculate totals before saving
      const calculatedInvoice = this.calculateTotals(invoiceData);

      // TypeORM handles saving related entities if cascade is true
      const savedInvoice = await this.invoiceRepository.save(calculatedInvoice);
      return savedInvoice;
    } catch (error) {
      // Log the error for debugging
      console.error("Error creating invoice:", error);
      if (error.code === "23503") { // Foreign key violation
        throw new BadRequestException("Invalid client_id or other foreign key constraint failed.");
      }
      throw new InternalServerErrorException("Could not create invoice. " + error.message);
    }
  }

  async findAll(tenant_id: string): Promise<Invoice[]> {
    return this.invoiceRepository.find({ where: { tenant_id }, relations: ["line_items"] });
  }

  async findOne(id: string, tenant_id: string): Promise<Invoice> {
    const invoice = await this.invoiceRepository.findOne({ where: { id, tenant_id }, relations: ["line_items"] });
    if (!invoice) {
      throw new NotFoundException(`Invoice with ID "${id}" not found for this tenant.`);
    }
    return invoice;
  }

  async update(id: string, updateInvoiceDto: UpdateInvoiceDto, tenant_id: string): Promise<Invoice> {
    const existingInvoice = await this.findOne(id, tenant_id); // Ensures invoice exists and belongs to tenant

    // Prepare data for update, including line items
    const updateData: DeepPartial<Invoice> = { ...updateInvoiceDto };

    if (updateInvoiceDto.line_items) {
      const updatedLineItems: InvoiceLineItem[] = [];
      for (const lineItemDto of updateInvoiceDto.line_items) {
        if (lineItemDto.id) {
          // Existing line item, merge changes
          const existingLineItem = existingInvoice.line_items.find(li => li.id === lineItemDto.id);
          if (existingLineItem) {
            this.lineItemRepository.merge(existingLineItem, lineItemDto as DeepPartial<InvoiceLineItem>);
            updatedLineItems.push(existingLineItem);
          } else {
            // If ID provided but not found, it might be an error or a new item intended for update
            // For simplicity, we treat it as a new item if not found, or throw error
            // throw new BadRequestException(`Line item with ID "${lineItemDto.id}" not found on invoice "${id}".`);
            const newLineItem = this.lineItemRepository.create({
              ...lineItemDto as DeepPartial<InvoiceLineItem>,
              invoice_id: id, // ensure association
              tenant_id: tenant_id,
            });
            updatedLineItems.push(newLineItem);
          }
        } else {
          // New line item
          const newLineItem = this.lineItemRepository.create({
            ...lineItemDto as DeepPartial<InvoiceLineItem>,
            invoice_id: id, // ensure association
            tenant_id: tenant_id,
          });
          updatedLineItems.push(newLineItem);
        }
      }
      updateData.line_items = updatedLineItems;
    }
    
    // Merge the top-level invoice fields
    this.invoiceRepository.merge(existingInvoice, updateData as DeepPartial<Invoice>); 
    
    // Recalculate totals with potentially modified/new line items
    const calculatedInvoice = this.calculateTotals(existingInvoice);

    try {
      return await this.invoiceRepository.save(calculatedInvoice);
    } catch (error) {
      console.error("Error updating invoice:", error);
      throw new InternalServerErrorException("Could not update invoice. " + error.message);
    }
  }

  async remove(id: string, tenant_id: string): Promise<void> {
    const invoice = await this.findOne(id, tenant_id); // Ensures invoice exists and belongs to tenant
    await this.invoiceRepository.remove(invoice);
  }
}


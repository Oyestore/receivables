-- SQL Schema for Phase 1.1: Core Invoice Data
-- Based on the detailed design in /home/ubuntu/phase_1_1_detailed_design.md

-- Table: invoices
CREATE TABLE IF NOT EXISTS invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL, -- Assuming a tenants.id table exists or will exist
    client_id UUID,          -- Assuming a clients.id table exists or will exist
    invoice_number VARCHAR(255) NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE,
    status VARCHAR(50) NOT NULL DEFAULT 'draft',
    currency VARCHAR(3) NOT NULL DEFAULT 'INR',
    sub_total DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    total_tax_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    total_discount_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    grand_total DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    amount_paid DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    balance_due DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    notes TEXT,
    terms_and_conditions TEXT,
    template_id UUID,        -- Assuming an invoice_templates.id table exists or will exist (Phase 1.2)
    ai_extraction_source VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
    -- Add FOREIGN KEY constraints once related tables (tenants, clients, invoice_templates) are defined
);

-- Table: invoice_line_items
CREATE TABLE IF NOT EXISTS invoice_line_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL, -- Denormalized for easier querying, ensure consistency with invoices.tenant_id
    description TEXT NOT NULL,
    quantity DECIMAL(10, 2) NOT NULL DEFAULT 1.00,
    unit_price DECIMAL(12, 2) NOT NULL,
    item_sub_total DECIMAL(12, 2) NOT NULL, -- Calculated: quantity * unit_price
    tax_rate_id UUID,        -- Assuming a tax_rates.id table exists or will exist (Phase 1.3)
    tax_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    discount_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    line_total DECIMAL(12, 2) NOT NULL, -- Calculated: item_sub_total + tax_amount - discount_amount
    product_id UUID,         -- Assuming a product_catalog.id table exists or will exist (Enhancement)
    order_index INTEGER NOT NULL DEFAULT 0
    -- Add FOREIGN KEY constraints once related tables (tax_rates, product_catalog) are defined
);

-- Trigger to update invoices.updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_invoices_updated_at
    BEFORE UPDATE
    ON
        invoices
    FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_invoices_tenant_id ON invoices(tenant_id);
CREATE INDEX IF NOT EXISTS idx_invoices_client_id ON invoices(client_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoice_line_items_invoice_id ON invoice_line_items(invoice_id);

-- Comments to remind about future foreign key constraints if tables are created separately:
-- ALTER TABLE invoices ADD CONSTRAINT fk_invoices_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id);
-- ALTER TABLE invoices ADD CONSTRAINT fk_invoices_client FOREIGN KEY (client_id) REFERENCES clients(id);
-- ALTER TABLE invoices ADD CONSTRAINT fk_invoices_template FOREIGN KEY (template_id) REFERENCES invoice_templates(id);
-- ALTER TABLE invoice_line_items ADD CONSTRAINT fk_line_items_tax_rate FOREIGN KEY (tax_rate_id) REFERENCES tax_rates(id);
-- ALTER TABLE invoice_line_items ADD CONSTRAINT fk_line_items_product FOREIGN KEY (product_id) REFERENCES product_catalog(id);



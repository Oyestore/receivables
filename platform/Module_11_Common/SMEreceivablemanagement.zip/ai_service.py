#!/usr/bin/env python3

import os
import sys
import json
import argparse
from pathlib import Path

# Add the parent directory to the path so we can import the deepseek_model module
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai.deepseek_model import DeepseekModel

class AIService:
    """
    Service class to integrate Deepseek R1 model with the SME Receivables Platform.
    This class provides methods to use the AI model for various financial tasks.
    """
    
    def __init__(self, config_path=None):
        """
        Initialize the AI service with configuration.
        
        Args:
            config_path: Path to the configuration file. If None, will use environment variables.
        """
        self.config = self._load_config(config_path)
        self.model = None
        
        # Initialize the model if local deployment is configured
        if self.config.get('AI_MODEL_DEPLOYMENT') == 'local':
            self._init_local_model()
    
    def _load_config(self, config_path):
        """
        Load configuration from file or environment variables.
        
        Args:
            config_path: Path to the configuration file.
            
        Returns:
            Dictionary with configuration values.
        """
        config = {}
        
        # Load from environment variables
        config['AI_MODEL'] = os.environ.get('AI_MODEL', 'deepseek-r1')
        config['AI_MODEL_DEPLOYMENT'] = os.environ.get('AI_MODEL_DEPLOYMENT', 'api')
        config['AI_MODEL_API_KEY'] = os.environ.get('AI_MODEL_API_KEY', '')
        config['AI_MODEL_API_URL'] = os.environ.get('AI_MODEL_API_URL', '')
        config['AI_MODEL_LOCAL_PATH'] = os.environ.get('AI_MODEL_LOCAL_PATH', './models')
        
        # Override with config file if provided
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r') as f:
                file_config = json.load(f)
                config.update(file_config)
        
        return config
    
    def _init_local_model(self):
        """
        Initialize the local Deepseek R1 model.
        """
        model_path = self.config.get('AI_MODEL_LOCAL_PATH')
        if not model_path:
            raise ValueError("AI_MODEL_LOCAL_PATH not configured for local deployment")
        
        self.model = DeepseekModel(model_path=model_path)
    
    def _call_api(self, endpoint, data):
        """
        Call the Deepseek R1 API.
        
        Args:
            endpoint: API endpoint to call.
            data: Data to send to the API.
            
        Returns:
            API response.
        """
        import requests
        
        api_url = self.config.get('AI_MODEL_API_URL')
        api_key = self.config.get('AI_MODEL_API_KEY')
        
        if not api_url or not api_key:
            raise ValueError("AI_MODEL_API_URL and AI_MODEL_API_KEY must be configured for API deployment")
        
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        response = requests.post(
            f"{api_url}/{endpoint}",
            headers=headers,
            json=data
        )
        
        response.raise_for_status()
        return response.json()
    
    def analyze_invoice(self, invoice_data):
        """
        Analyze an invoice and extract key information.
        
        Args:
            invoice_data: Dictionary with invoice text or OCR data.
            
        Returns:
            Dictionary with extracted information.
        """
        if self.config.get('AI_MODEL_DEPLOYMENT') == 'local':
            if not self.model:
                self._init_local_model()
            return self.model.analyze_invoice(invoice_data.get('text', ''))
        else:
            return self._call_api('analyze_invoice', invoice_data)
    
    def assess_buyer_risk(self, buyer_data):
        """
        Assess the risk of a buyer based on historical data.
        
        Args:
            buyer_data: Dictionary with buyer information and payment history.
            
        Returns:
            Risk assessment report.
        """
        if self.config.get('AI_MODEL_DEPLOYMENT') == 'local':
            if not self.model:
                self._init_local_model()
            return self.model.assess_buyer_risk(buyer_data)
        else:
            return self._call_api('assess_buyer_risk', buyer_data)
    
    def optimize_payment_terms(self, invoice_data, buyer_data):
        """
        Optimize payment terms for an invoice based on buyer data.
        
        Args:
            invoice_data: Dictionary with invoice information.
            buyer_data: Dictionary with buyer information and payment history.
            
        Returns:
            Recommended payment terms.
        """
        if self.config.get('AI_MODEL_DEPLOYMENT') == 'local':
            if not self.model:
                self._init_local_model()
            return self.model.optimize_payment_terms(invoice_data, buyer_data)
        else:
            return self._call_api('optimize_payment_terms', {
                'invoice': invoice_data,
                'buyer': buyer_data
            })
    
    def draft_communication(self, communication_type, invoice_data, buyer_data):
        """
        Draft a communication to a buyer.
        
        Args:
            communication_type: Type of communication (reminder, thank you, etc.)
            invoice_data: Dictionary with invoice information.
            buyer_data: Dictionary with buyer information.
            
        Returns:
            Draft communication text.
        """
        if self.config.get('AI_MODEL_DEPLOYMENT') == 'local':
            if not self.model:
                self._init_local_model()
            return self.model.draft_communication(communication_type, invoice_data, buyer_data)
        else:
            return self._call_api('draft_communication', {
                'type': communication_type,
                'invoice': invoice_data,
                'buyer': buyer_data
            })
    
    def forecast_cash_flow(self, invoices_data, historical_data):
        """
        Forecast cash flow based on outstanding invoices and historical payment patterns.
        
        Args:
            invoices_data: List of dictionaries with invoice information.
            historical_data: Dictionary with historical payment patterns.
            
        Returns:
            Cash flow forecast.
        """
        if self.config.get('AI_MODEL_DEPLOYMENT') == 'local':
            if not self.model:
                self._init_local_model()
            # This would be implemented in the DeepseekModel class
            raise NotImplementedError("Local forecast_cash_flow not implemented")
        else:
            return self._call_api('forecast_cash_flow', {
                'invoices': invoices_data,
                'historical': historical_data
            })

def main():
    parser = argparse.ArgumentParser(description="SME Receivables Platform AI Service")
    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument("--function", type=str, required=True, 
                        choices=["analyze_invoice", "assess_risk", "optimize_terms", 
                                "draft_communication", "forecast_cash_flow"],
                        help="Function to run")
    parser.add_argument("--input", type=str, required=True, help="Input JSON file path")
    parser.add_argument("--output", type=str, help="Output file path")
    
    args = parser.parse_args()
    
    ai_service = AIService(config_path=args.config)
    
    with open(args.input, 'r') as f:
        input_data = json.load(f)
    
    if args.function == "analyze_invoice":
        result = ai_service.analyze_invoice(input_data)
    elif args.function == "assess_risk":
        result = ai_service.assess_buyer_risk(input_data)
    elif args.function == "optimize_terms":
        result = ai_service.optimize_payment_terms(
            input_data.get('invoice', {}),
            input_data.get('buyer', {})
        )
    elif args.function == "draft_communication":
        result = ai_service.draft_communication(
            input_data.get('type', 'reminder'),
            input_data.get('invoice', {}),
            input_data.get('buyer', {})
        )
    elif args.function == "forecast_cash_flow":
        result = ai_service.forecast_cash_flow(
            input_data.get('invoices', []),
            input_data.get('historical', {})
        )
    
    if args.output:
        with open(args.output, 'w') as f:
            if isinstance(result, dict) or isinstance(result, list):
                json.dump(result, f, indent=2)
            else:
                f.write(str(result))
    else:
        if isinstance(result, dict) or isinstance(result, list):
            print(json.dumps(result, indent=2))
        else:
            print(result)

if __name__ == "__main__":
    main()

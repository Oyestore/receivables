import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { FollowUpSequence } from '../entities/follow-up-sequence.entity';
import { FollowUpStep } from '../entities/follow-up-step.entity';
import { FollowUpRuleService } from './follow-up-rule.service';

export class CreateFollowUpSequenceDto {
  name: string;
  description?: string;
  organizationId: string;
}

export class UpdateFollowUpSequenceDto {
  name?: string;
  description?: string;
}

export class CreateFollowUpStepDto {
  sequenceId: string;
  stepNumber: number;
  ruleId: string;
  organizationId: string;
}

export class UpdateFollowUpStepDto {
  stepNumber?: number;
  ruleId?: string;
}

@Injectable()
export class FollowUpSequenceService {
  constructor(
    @InjectRepository(FollowUpSequence)
    private followUpSequenceRepository: Repository<FollowUpSequence>,
    @InjectRepository(FollowUpStep)
    private followUpStepRepository: Repository<FollowUpStep>,
    private followUpRuleService: FollowUpRuleService,
  ) {}

  /**
   * Create a new follow-up sequence
   */
  async createSequence(createFollowUpSequenceDto: CreateFollowUpSequenceDto): Promise<FollowUpSequence> {
    const newSequence = this.followUpSequenceRepository.create(createFollowUpSequenceDto);
    return this.followUpSequenceRepository.save(newSequence);
  }

  /**
   * Get all follow-up sequences for an organization
   */
  async findAllSequences(organizationId: string): Promise<FollowUpSequence[]> {
    return this.followUpSequenceRepository.find({
      where: { organizationId },
      relations: ['steps', 'steps.rule'],
      order: { name: 'ASC' },
    });
  }

  /**
   * Get a specific follow-up sequence
   */
  async findOneSequence(id: string, organizationId: string): Promise<FollowUpSequence> {
    const sequence = await this.followUpSequenceRepository.findOne({
      where: { id, organizationId },
      relations: ['steps', 'steps.rule'],
    });

    if (!sequence) {
      throw new Error(`Follow-up sequence with ID ${id} not found`);
    }

    return sequence;
  }

  /**
   * Update a follow-up sequence
   */
  async updateSequence(
    id: string,
    updateFollowUpSequenceDto: UpdateFollowUpSequenceDto,
    organizationId: string,
  ): Promise<FollowUpSequence> {
    const sequence = await this.findOneSequence(id, organizationId);
    
    // Update the sequence with the new data
    Object.assign(sequence, updateFollowUpSequenceDto);
    
    return this.followUpSequenceRepository.save(sequence);
  }

  /**
   * Delete a follow-up sequence
   */
  async removeSequence(id: string, organizationId: string): Promise<void> {
    const sequence = await this.findOneSequence(id, organizationId);
    
    // First, remove all steps in the sequence
    if (sequence.steps && sequence.steps.length > 0) {
      await this.followUpStepRepository.remove(sequence.steps);
    }
    
    // Then remove the sequence itself
    await this.followUpSequenceRepository.remove(sequence);
  }

  /**
   * Add a step to a follow-up sequence
   */
  async addStep(createFollowUpStepDto: CreateFollowUpStepDto): Promise<FollowUpStep> {
    // Verify that the sequence exists
    await this.findOneSequence(createFollowUpStepDto.sequenceId, createFollowUpStepDto.organizationId);
    
    // Verify that the rule exists
    await this.followUpRuleService.findOne(createFollowUpStepDto.ruleId, createFollowUpStepDto.organizationId);
    
    // Create and save the new step
    const newStep = this.followUpStepRepository.create(createFollowUpStepDto);
    return this.followUpStepRepository.save(newStep);
  }

  /**
   * Get a specific follow-up step
   */
  async findOneStep(id: string, organizationId: string): Promise<FollowUpStep> {
    const step = await this.followUpStepRepository.findOne({
      where: { id, organizationId },
      relations: ['sequence', 'rule'],
    });

    if (!step) {
      throw new Error(`Follow-up step with ID ${id} not found`);
    }

    return step;
  }

  /**
   * Update a follow-up step
   */
  async updateStep(
    id: string,
    updateFollowUpStepDto: UpdateFollowUpStepDto,
    organizationId: string,
  ): Promise<FollowUpStep> {
    const step = await this.findOneStep(id, organizationId);
    
    // If updating the rule, verify that it exists
    if (updateFollowUpStepDto.ruleId) {
      await this.followUpRuleService.findOne(updateFollowUpStepDto.ruleId, organizationId);
    }
    
    // Update the step with the new data
    Object.assign(step, updateFollowUpStepDto);
    
    return this.followUpStepRepository.save(step);
  }

  /**
   * Remove a follow-up step
   */
  async removeStep(id: string, organizationId: string): Promise<void> {
    const step = await this.findOneStep(id, organizationId);
    await this.followUpStepRepository.remove(step);
  }

  /**
   * Reorder steps in a sequence
   */
  async reorderSteps(sequenceId: string, stepIds: string[], organizationId: string): Promise<FollowUpStep[]> {
    // Verify that the sequence exists
    const sequence = await this.findOneSequence(sequenceId, organizationId);
    
    // Verify that all steps exist and belong to the sequence
    const steps = await this.followUpStepRepository.findByIds(stepIds, {
      where: { sequenceId, organizationId },
    });
    
    if (steps.length !== stepIds.length) {
      throw new Error('One or more steps not found or do not belong to the sequence');
    }
    
    // Update step numbers based on the new order
    const updatedSteps: FollowUpStep[] = [];
    
    for (let i = 0; i < stepIds.length; i++) {
      const stepId = stepIds[i];
      const step = steps.find(s => s.id === stepId);
      
      if (step) {
        step.stepNumber = i + 1;
        updatedSteps.push(await this.followUpStepRepository.save(step));
      }
    }
    
    return updatedSteps;
  }
}

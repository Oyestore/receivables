import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import AdvancedAnalyticsDashboard from '../components/AdvancedAnalyticsDashboard';
import { UserContext } from '../contexts/UserContext';

// Mock the recharts library
jest.mock('recharts', () => {
  const OriginalModule = jest.requireActual('recharts');
  return {
    ...OriginalModule,
    ResponsiveContainer: ({ children }) => <div data-testid="responsive-container">{children}</div>,
    LineChart: ({ children }) => <div data-testid="line-chart">{children}</div>,
    BarChart: ({ children }) => <div data-testid="bar-chart">{children}</div>,
    PieChart: ({ children }) => <div data-testid="pie-chart">{children}</div>,
    AreaChart: ({ children }) => <div data-testid="area-chart">{children}</div>,
    ComposedChart: ({ children }) => <div data-testid="composed-chart">{children}</div>,
    RadarChart: ({ children }) => <div data-testid="radar-chart">{children}</div>,
    Treemap: ({ children }) => <div data-testid="treemap">{children}</div>,
    Line: () => <div data-testid="line" />,
    Bar: () => <div data-testid="bar" />,
    Pie: () => <div data-testid="pie" />,
    Area: () => <div data-testid="area" />,
    Scatter: () => <div data-testid="scatter" />,
    Radar: () => <div data-testid="radar" />,
    XAxis: () => <div data-testid="x-axis" />,
    YAxis: () => <div data-testid="y-axis" />,
    CartesianGrid: () => <div data-testid="cartesian-grid" />,
    Tooltip: () => <div data-testid="tooltip" />,
    Legend: () => <div data-testid="legend" />,
    Cell: () => <div data-testid="cell" />,
    PolarGrid: () => <div data-testid="polar-grid" />,
    PolarAngleAxis: () => <div data-testid="polar-angle-axis" />,
    PolarRadiusAxis: () => <div data-testid="polar-radius-axis" />,
  };
});

// Mock WebSocket
class MockWebSocket {
  constructor(url) {
    this.url = url;
    this.onopen = jest.fn();
    this.onmessage = jest.fn();
    this.onerror = jest.fn();
    this.onclose = jest.fn();
    this.close = jest.fn();
    
    // Simulate connection
    setTimeout(() => {
      if (this.onopen) this.onopen();
    }, 100);
  }
  
  // Method to simulate receiving a message
  simulateMessage(data) {
    if (this.onmessage) {
      this.onmessage({ data: JSON.stringify(data) });
    }
  }
}

global.WebSocket = MockWebSocket;

// Mock user context
const mockUserContext = {
  admin: { user: { id: '1', name: 'Admin User', role: 'admin' } },
  financeManager: { user: { id: '2', name: 'Finance Manager', role: 'financeManager' } },
  arSpecialist: { user: { id: '3', name: 'AR Specialist', role: 'arSpecialist' } },
  executive: { user: { id: '4', name: 'Executive', role: 'executive' } },
};

describe('AdvancedAnalyticsDashboard', () => {
  // Test loading state
  test('displays loading state initially', () => {
    render(
      <UserContext.Provider value={mockUserContext.admin}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    expect(screen.getByText('Loading Analytics Dashboard...')).toBeInTheDocument();
  });
  
  // Test dashboard rendering for admin role
  test('renders all dashboard tabs for admin role', async () => {
    render(
      <UserContext.Provider value={mockUserContext.admin}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Check for all tabs
    expect(screen.getByText('Overview')).toBeInTheDocument();
    expect(screen.getByText('Distribution')).toBeInTheDocument();
    expect(screen.getByText('Follow-up')).toBeInTheDocument();
    expect(screen.getByText('Templates')).toBeInTheDocument();
    expect(screen.getByText('System Health')).toBeInTheDocument();
    expect(screen.getByText('Cash Flow')).toBeInTheDocument();
    expect(screen.getByText('Customer Behavior')).toBeInTheDocument();
    expect(screen.getByText('Performance')).toBeInTheDocument();
    
    // Check for export buttons
    expect(screen.getByText('Export PDF')).toBeInTheDocument();
    expect(screen.getByText('Export CSV')).toBeInTheDocument();
  });
  
  // Test dashboard rendering for finance manager role
  test('renders limited dashboard tabs for finance manager role', async () => {
    render(
      <UserContext.Provider value={mockUserContext.financeManager}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Check for allowed tabs
    expect(screen.getByText('Overview')).toBeInTheDocument();
    expect(screen.getByText('Distribution')).toBeInTheDocument();
    expect(screen.getByText('Follow-up')).toBeInTheDocument();
    expect(screen.getByText('Cash Flow')).toBeInTheDocument();
    
    // Check for tabs that should not be visible
    expect(screen.queryByText('Templates')).not.toBeInTheDocument();
    expect(screen.queryByText('System Health')).not.toBeInTheDocument();
    expect(screen.queryByText('Customer Behavior')).not.toBeInTheDocument();
    expect(screen.queryByText('Performance')).not.toBeInTheDocument();
    
    // Check for export buttons
    expect(screen.getByText('Export PDF')).toBeInTheDocument();
    expect(screen.getByText('Export CSV')).toBeInTheDocument();
  });
  
  // Test dashboard rendering for AR specialist role
  test('renders limited dashboard tabs for AR specialist role', async () => {
    render(
      <UserContext.Provider value={mockUserContext.arSpecialist}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Check for allowed tabs
    expect(screen.getByText('Overview')).toBeInTheDocument();
    expect(screen.getByText('Distribution')).toBeInTheDocument();
    expect(screen.getByText('Follow-up')).toBeInTheDocument();
    expect(screen.getByText('Customer Behavior')).toBeInTheDocument();
    
    // Check for tabs that should not be visible
    expect(screen.queryByText('Templates')).not.toBeInTheDocument();
    expect(screen.queryByText('System Health')).not.toBeInTheDocument();
    expect(screen.queryByText('Cash Flow')).not.toBeInTheDocument();
    expect(screen.queryByText('Performance')).not.toBeInTheDocument();
    
    // Check for export buttons
    expect(screen.getByText('Export PDF')).toBeInTheDocument();
    expect(screen.getByText('Export CSV')).toBeInTheDocument();
  });
  
  // Test dashboard rendering for executive role
  test('renders minimal dashboard tabs for executive role', async () => {
    render(
      <UserContext.Provider value={mockUserContext.executive}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Check for allowed tabs
    expect(screen.getByText('Overview')).toBeInTheDocument();
    expect(screen.getByText('Performance')).toBeInTheDocument();
    
    // Check for tabs that should not be visible
    expect(screen.queryByText('Distribution')).not.toBeInTheDocument();
    expect(screen.queryByText('Follow-up')).not.toBeInTheDocument();
    expect(screen.queryByText('Templates')).not.toBeInTheDocument();
    expect(screen.queryByText('System Health')).not.toBeInTheDocument();
    expect(screen.queryByText('Cash Flow')).not.toBeInTheDocument();
    expect(screen.queryByText('Customer Behavior')).not.toBeInTheDocument();
    
    // Check for export buttons
    expect(screen.getByText('Export PDF')).toBeInTheDocument();
    expect(screen.getByText('Export CSV')).toBeInTheDocument();
  });
  
  // Test tab switching
  test('switches between tabs correctly', async () => {
    render(
      <UserContext.Provider value={mockUserContext.admin}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Initially on Overview tab
    expect(screen.getByText('Key Performance Indicators')).toBeInTheDocument();
    
    // Switch to Distribution tab
    fireEvent.click(screen.getByText('Distribution'));
    expect(screen.getByText('Distribution Volume by Channel')).toBeInTheDocument();
    
    // Switch to Follow-up tab
    fireEvent.click(screen.getByText('Follow-up'));
    expect(screen.getByText('Follow-up Response Rates')).toBeInTheDocument();
    
    // Switch back to Overview tab
    fireEvent.click(screen.getByText('Overview'));
    expect(screen.getByText('Key Performance Indicators')).toBeInTheDocument();
  });
  
  // Test time range filter
  test('changes time range correctly', async () => {
    render(
      <UserContext.Provider value={mockUserContext.admin}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Change time range
    fireEvent.mouseDown(screen.getByLabelText('Time Range'));
    fireEvent.click(screen.getByText('This Month'));
    
    // Should trigger data refresh
    expect(screen.getByText('Refreshing...')).toBeInTheDocument();
    
    // Wait for refresh to complete
    await waitFor(() => {
      expect(screen.queryByText('Refreshing...')).not.toBeInTheDocument();
    });
  });
  
  // Test manual refresh
  test('manual refresh works correctly', async () => {
    render(
      <UserContext.Provider value={mockUserContext.admin}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Click refresh button
    fireEvent.click(screen.getByText('Refresh'));
    
    // Should show refreshing state
    expect(screen.getByText('Refreshing...')).toBeInTheDocument();
    
    // Wait for refresh to complete
    await waitFor(() => {
      expect(screen.queryByText('Refreshing...')).not.toBeInTheDocument();
    });
    
    // Should show success message
    expect(screen.getByText('Dashboard data refreshed successfully')).toBeInTheDocument();
  });
  
  // Test WebSocket real-time updates
  test('receives real-time updates via WebSocket', async () => {
    render(
      <UserContext.Provider value={mockUserContext.admin}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Get WebSocket instance
    const ws = global.WebSocket.mock.instances[0];
    
    // Simulate receiving a message
    ws.simulateMessage({
      type: 'analytics_update',
      payload: {
        distributionMetrics: {
          volumeByChannel: {
            email: { total: 1500 } // Updated value
          }
        }
      }
    });
    
    // Should show update message
    await waitFor(() => {
      expect(screen.getByText('Dashboard data updated in real-time')).toBeInTheDocument();
    });
  });
  
  // Test export functionality
  test('export functionality works correctly', async () => {
    render(
      <UserContext.Provider value={mockUserContext.admin}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Click export PDF button
    fireEvent.click(screen.getByText('Export PDF'));
    
    // Should show generating message
    expect(screen.getByText('Generating pdf report...')).toBeInTheDocument();
    
    // Wait for generation to complete
    await waitFor(() => {
      expect(screen.getByText('PDF report generated successfully')).toBeInTheDocument();
    });
  });
  
  // Test error handling
  test('handles errors correctly', async () => {
    // Mock fetch to throw an error
    const originalFetch = global.fetch;
    global.fetch = jest.fn().mockRejectedValue(new Error('API error'));
    
    render(
      <UserContext.Provider value={mockUserContext.admin}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Should show error message
    await waitFor(() => {
      expect(screen.getByText('Failed to load dashboard data. Please try again.')).toBeInTheDocument();
    });
    
    // Restore original fetch
    global.fetch = originalFetch;
  });
  
  // Test mobile responsiveness
  test('adapts to mobile viewport', async () => {
    // Mock window.matchMedia for mobile viewport
    window.matchMedia = jest.fn().mockImplementation(query => ({
      matches: query.includes('max-width: 600px'),
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
      dispatchEvent: jest.fn(),
    }));
    
    render(
      <UserContext.Provider value={mockUserContext.admin}>
        <AdvancedAnalyticsDashboard />
      </UserContext.Provider>
    );
    
    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading Analytics Dashboard...')).not.toBeInTheDocument();
    });
    
    // Should show mobile menu button
    expect(screen.getByLabelText('open drawer')).toBeInTheDocument();
    
    // Click menu button to open drawer
    fireEvent.click(screen.getByLabelText('open drawer'));
    
    // Drawer should be visible with navigation options
    expect(screen.getByText('Analytics Dashboard')).toBeInTheDocument();
    
    // Restore window.matchMedia
    window.matchMedia.mockRestore();
  });
});

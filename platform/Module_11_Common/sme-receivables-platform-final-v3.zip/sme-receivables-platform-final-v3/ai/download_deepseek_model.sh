#!/bin/bash

# Script to download Deepseek R1 model weights
# This script is part of the SME Receivables Management Platform

echo "Starting download of Deepseek R1 model weights..."
echo "This may take some time depending on your internet connection."

# Create model directory if it doesn't exist
mkdir -p ./models/deepseek-r1

# Download model weights
echo "Downloading model weights..."
wget -c https://huggingface.co/deepseek-ai/deepseek-coder-1.3b-instruct/resolve/main/pytorch_model.bin -O ./models/deepseek-r1/pytorch_model.bin
wget -c https://huggingface.co/deepseek-ai/deepseek-coder-1.3b-instruct/resolve/main/config.json -O ./models/deepseek-r1/config.json
wget -c https://huggingface.co/deepseek-ai/deepseek-coder-1.3b-instruct/resolve/main/tokenizer.json -O ./models/deepseek-r1/tokenizer.json
wget -c https://huggingface.co/deepseek-ai/deepseek-coder-1.3b-instruct/resolve/main/tokenizer_config.json -O ./models/deepseek-r1/tokenizer_config.json

echo "Download complete!"
echo "Model weights are stored in ./models/deepseek-r1/"

# Verify download
echo "Verifying downloaded files..."
if [ -f "./models/deepseek-r1/pytorch_model.bin" ] && [ -f "./models/deepseek-r1/config.json" ] && [ -f "./models/deepseek-r1/tokenizer.json" ] && [ -f "./models/deepseek-r1/tokenizer_config.json" ]; then
    echo "Verification successful. All files downloaded correctly."
else
    echo "Verification failed. Some files may be missing or corrupted."
    echo "Please run this script again."
fi

echo "For larger models, please visit https://huggingface.co/deepseek-ai/deepseek-coder-33b-instruct"
echo "and download the model weights manually."

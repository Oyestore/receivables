#!/bin/bash

# Run all tests for SME Receivables Management Platform
echo "Running comprehensive tests for SME Receivables Management Platform..."

# Create test directory if it doesn't exist
mkdir -p /home/ubuntu/sme-receivables-platform/tests/results
cd /home/ubuntu/sme-receivables-platform

# Install required Python packages for testing
echo "Installing required Python packages for testing..."
pip3 install requests selenium pytest pytest-html

# Run system tests first
echo "Running system tests..."
./run_tests.sh

# Check if system tests passed
if [ $? -ne 0 ]; then
    echo "System tests failed. Aborting further tests."
    exit 1
fi

# Start the system for API and frontend tests
echo "Starting the system for API and frontend tests..."
docker-compose up -d

# Wait for services to be ready
echo "Waiting for services to be ready..."
sleep 15

# Run API tests
echo "Running API tests..."
python3 -m pytest tests/test_api.py -v --html=tests/results/api_test_report.html

# Run frontend tests
echo "Running frontend tests..."
python3 -m pytest tests/test_frontend.py -v --html=tests/results/frontend_test_report.html

# Stop the system
echo "Stopping the system..."
docker-compose down

# Create combined test report
echo "Creating combined test report..."
cat > tests/results/test_report.md << EOL
# Comprehensive Test Report for SME Receivables Management Platform

## Test Date: $(date)

## System Tests
- See test_summary.md for details

## API Tests
- See api_test_report.html for details

## Frontend Tests
- See frontend_test_report.html for details

## Summary
The SME Receivables Management Platform has been tested for:
- System configuration and startup
- API functionality and data operations
- Frontend user interface and interactions

## Recommendations
1. Perform load testing before production deployment
2. Implement continuous integration for automated testing
3. Conduct security penetration testing
4. Perform user acceptance testing with real users
EOL

echo "All tests completed. See tests/results directory for test reports."
exit 0

#!/usr/bin/env python3

import os
import json
import argparse
from pathlib import Path

class SmartInvoiceDistributor:
    """
    Service class to handle distribution of smart invoices with embedded agents
    through various channels including email and WhatsApp.
    """
    
    def __init__(self, config_path=None):
        """
        Initialize the smart invoice distributor with configuration.
        
        Args:
            config_path: Path to the configuration file. If None, will use environment variables.
        """
        self.config = self._load_config(config_path)
    
    def _load_config(self, config_path):
        """
        Load configuration from file or environment variables.
        
        Args:
            config_path: Path to the configuration file.
            
        Returns:
            Dictionary with configuration values.
        """
        config = {}
        
        # Load from environment variables
        config['EMAIL_ENABLED'] = os.environ.get('EMAIL_ENABLED', 'true').lower() == 'true'
        config['WHATSAPP_ENABLED'] = os.environ.get('WHATSAPP_ENABLED', 'true').lower() == 'true'
        config['SMS_ENABLED'] = os.environ.get('SMS_ENABLED', 'false').lower() == 'true'
        config['EMAIL_SERVICE'] = os.environ.get('EMAIL_SERVICE', 'smtp')
        config['EMAIL_HOST'] = os.environ.get('EMAIL_HOST', 'smtp.example.com')
        config['EMAIL_PORT'] = int(os.environ.get('EMAIL_PORT', '587'))
        config['EMAIL_USER'] = os.environ.get('EMAIL_USER', '')
        config['EMAIL_PASSWORD'] = os.environ.get('EMAIL_PASSWORD', '')
        config['WHATSAPP_API_KEY'] = os.environ.get('WHATSAPP_API_KEY', '')
        config['WHATSAPP_PHONE_ID'] = os.environ.get('WHATSAPP_PHONE_ID', '')
        config['SMS_API_KEY'] = os.environ.get('SMS_API_KEY', '')
        config['BASE_URL'] = os.environ.get('BASE_URL', 'https://example.com')
        config['TOKEN_SECRET'] = os.environ.get('TOKEN_SECRET', 'your_secret_key')
        config['TOKEN_EXPIRY'] = int(os.environ.get('TOKEN_EXPIRY', '7')) # days
        
        # Override with config file if provided
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r') as f:
                file_config = json.load(f)
                config.update(file_config)
        
        return config
    
    def _generate_secure_token(self, invoice_id, recipient_id):
        """
        Generate a secure token for invoice access.
        
        Args:
            invoice_id: ID of the invoice
            recipient_id: ID of the recipient
            
        Returns:
            Secure token string
        """
        import jwt
        import time
        
        payload = {
            'invoice_id': invoice_id,
            'recipient_id': recipient_id,
            'exp': int(time.time()) + (self.config['TOKEN_EXPIRY'] * 86400)
        }
        
        return jwt.encode(payload, self.config['TOKEN_SECRET'], algorithm='HS256')
    
    def _generate_invoice_url(self, invoice_id, recipient_id):
        """
        Generate a secure URL for accessing the invoice.
        
        Args:
            invoice_id: ID of the invoice
            recipient_id: ID of the recipient
            
        Returns:
            Secure URL string
        """
        token = self._generate_secure_token(invoice_id, recipient_id)
        return f"{self.config['BASE_URL']}/invoice/view/{token}"
    
    def _generate_agent_url(self, invoice_id, recipient_id, agent_type):
        """
        Generate a secure URL for accessing a specific agent.
        
        Args:
            invoice_id: ID of the invoice
            recipient_id: ID of the recipient
            agent_type: Type of agent to access
            
        Returns:
            Secure URL string
        """
        token = self._generate_secure_token(invoice_id, recipient_id)
        return f"{self.config['BASE_URL']}/invoice/agent/{agent_type}/{token}"
    
    def _get_invoice_summary(self, invoice_data):
        """
        Generate a summary of the invoice for messaging channels.
        
        Args:
            invoice_data: Dictionary with invoice information
            
        Returns:
            Summary string
        """
        return f"Invoice #{invoice_data['invoice_number']} from {invoice_data['company_name']}\n" \
               f"Amount: {invoice_data['currency']} {invoice_data['total_amount']}\n" \
               f"Due Date: {invoice_data['due_date']}"
    
    def send_via_email(self, invoice_data, recipient_data):
        """
        Send a smart invoice via email.
        
        Args:
            invoice_data: Dictionary with invoice information
            recipient_data: Dictionary with recipient information
            
        Returns:
            Success status and message
        """
        if not self.config['EMAIL_ENABLED']:
            return False, "Email distribution is disabled"
        
        try:
            import smtplib
            from email.mime.multipart import MIMEMultipart
            from email.mime.text import MIMEText
            
            # Generate secure URL
            invoice_url = self._generate_invoice_url(invoice_data['id'], recipient_data['id'])
            
            # Generate agent URLs
            payment_agent_url = self._generate_agent_url(invoice_data['id'], recipient_data['id'], 'payment')
            query_agent_url = self._generate_agent_url(invoice_data['id'], recipient_data['id'], 'query')
            discount_agent_url = self._generate_agent_url(invoice_data['id'], recipient_data['id'], 'discount')
            
            # Create email
            msg = MIMEMultipart('alternative')
            msg['Subject'] = f"Invoice #{invoice_data['invoice_number']} from {invoice_data['company_name']}"
            msg['From'] = invoice_data['sender_email']
            msg['To'] = recipient_data['email']
            
            # Plain text version
            text = f"Invoice #{invoice_data['invoice_number']} from {invoice_data['company_name']}\n\n" \
                   f"Amount: {invoice_data['currency']} {invoice_data['total_amount']}\n" \
                   f"Due Date: {invoice_data['due_date']}\n\n" \
                   f"View your invoice: {invoice_url}\n"
            
            # HTML version with embedded agents
            html = f"""
            <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; line-height: 1.6; }}
                    .invoice-container {{ max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }}
                    .invoice-header {{ background-color: #f5f5f5; padding: 10px; border-radius: 5px; margin-bottom: 20px; }}
                    .invoice-details {{ margin-bottom: 20px; }}
                    .invoice-amount {{ font-size: 24px; font-weight: bold; margin: 20px 0; }}
                    .agent-button {{ display: inline-block; margin: 5px; padding: 10px 15px; background-color: #0066cc; color: white; 
                                    text-decoration: none; border-radius: 5px; font-weight: bold; }}
                    .agent-button:hover {{ background-color: #0052a3; }}
                    .view-button {{ display: block; margin: 20px auto; padding: 15px 25px; background-color: #28a745; color: white; 
                                  text-decoration: none; border-radius: 5px; font-weight: bold; text-align: center; width: 200px; }}
                    .view-button:hover {{ background-color: #218838; }}
                </style>
            </head>
            <body>
                <div class="invoice-container">
                    <div class="invoice-header">
                        <h2>Invoice #{invoice_data['invoice_number']}</h2>
                        <p>From: {invoice_data['company_name']}</p>
                    </div>
                    
                    <div class="invoice-details">
                        <p><strong>Issue Date:</strong> {invoice_data['issue_date']}</p>
                        <p><strong>Due Date:</strong> {invoice_data['due_date']}</p>
                    </div>
                    
                    <div class="invoice-amount">
                        {invoice_data['currency']} {invoice_data['total_amount']}
                    </div>
                    
                    <p>Hello {recipient_data['name']},</p>
                    <p>Please find your invoice attached. You can use our smart agents to help you manage this invoice:</p>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="{payment_agent_url}" class="agent-button">Payment Schedule</a>
                        <a href="{query_agent_url}" class="agent-button">Ask Questions</a>
                        <a href="{discount_agent_url}" class="agent-button">Early Payment Discount</a>
                    </div>
                    
                    <a href="{invoice_url}" class="view-button">View Full Invoice</a>
                    
                    <p style="font-size: 12px; color: #666; margin-top: 30px;">
                        This is a secure link that will expire in {self.config['TOKEN_EXPIRY']} days. 
                        No login is required to view this invoice.
                    </p>
                </div>
            </body>
            </html>
            """
            
            # Attach parts
            msg.attach(MIMEText(text, 'plain'))
            msg.attach(MIMEText(html, 'html'))
            
            # Send email
            if self.config['EMAIL_SERVICE'] == 'smtp':
                server = smtplib.SMTP(self.config['EMAIL_HOST'], self.config['EMAIL_PORT'])
                server.starttls()
                server.login(self.config['EMAIL_USER'], self.config['EMAIL_PASSWORD'])
                server.send_message(msg)
                server.quit()
            else:
                # Implement other email services (SES, Sendgrid, etc.)
                pass
            
            return True, "Invoice sent successfully via email"
            
        except Exception as e:
            return False, f"Failed to send email: {str(e)}"
    
    def send_via_whatsapp(self, invoice_data, recipient_data):
        """
        Send a smart invoice via WhatsApp.
        
        Args:
            invoice_data: Dictionary with invoice information
            recipient_data: Dictionary with recipient information
            
        Returns:
            Success status and message
        """
        if not self.config['WHATSAPP_ENABLED']:
            return False, "WhatsApp distribution is disabled"
        
        try:
            import requests
            
            # Generate secure URL
            invoice_url = self._generate_invoice_url(invoice_data['id'], recipient_data['id'])
            
            # Create WhatsApp message
            summary = self._get_invoice_summary(invoice_data)
            message = f"{summary}\n\nView and manage your invoice here: {invoice_url}"
            
            # WhatsApp Business API endpoint
            api_url = "https://graph.facebook.com/v17.0/" + self.config['WHATSAPP_PHONE_ID'] + "/messages"
            
            # Prepare headers
            headers = {
                "Authorization": f"Bearer {self.config['WHATSAPP_API_KEY']}",
                "Content-Type": "application/json"
            }
            
            # Prepare payload with interactive buttons
            payload = {
                "messaging_product": "whatsapp",
                "recipient_type": "individual",
                "to": recipient_data['phone'],
                "type": "interactive",
                "interactive": {
                    "type": "button",
                    "body": {
                        "text": message
                    },
                    "action": {
                        "buttons": [
                            {
                                "type": "url",
                                "url": invoice_url,
                                "text": "View Invoice"
                            }
                        ]
                    }
                }
            }
            
            # Send request
            response = requests.post(api_url, headers=headers, json=payload)
            response.raise_for_status()
            
            return True, "Invoice sent successfully via WhatsApp"
            
        except Exception as e:
            return False, f"Failed to send WhatsApp message: {str(e)}"
    
    def send_via_sms(self, invoice_data, recipient_data):
        """
        Send a smart invoice via SMS.
        
        Args:
            invoice_data: Dictionary with invoice information
            recipient_data: Dictionary with recipient information
            
        Returns:
            Success status and message
        """
        if not self.config['SMS_ENABLED']:
            return False, "SMS distribution is disabled"
        
        try:
            import requests
            
            # Generate secure URL
            invoice_url = self._generate_invoice_url(invoice_data['id'], recipient_data['id'])
            
            # Create SMS message
            summary = self._get_invoice_summary(invoice_data)
            message = f"{summary}\n\nView and manage your invoice here: {invoice_url}"
            
            # Implement SMS API call here
            # This is a placeholder for actual SMS API integration
            
            return True, "Invoice sent successfully via SMS"
            
        except Exception as e:
            return False, f"Failed to send SMS: {str(e)}"
    
    def distribute_invoice(self, invoice_data, recipient_data, channels=None):
        """
        Distribute a smart invoice through specified channels.
        
        Args:
            invoice_data: Dictionary with invoice information
            recipient_data: Dictionary with recipient information
            channels: List of channels to use (email, whatsapp, sms)
            
        Returns:
            Dictionary with results for each channel
        """
        if channels is None:
            channels = ['email']
        
        results = {}
        
        if 'email' in channels and recipient_data.get('email'):
            results['email'] = self.send_via_email(invoice_data, recipient_data)
        
        if 'whatsapp' in channels and recipient_data.get('phone'):
            results['whatsapp'] = self.send_via_whatsapp(invoice_data, recipient_data)
        
        if 'sms' in channels and recipient_data.get('phone'):
            results['sms'] = self.send_via_sms(invoice_data, recipient_data)
        
        return results

def main():
    parser = argparse.ArgumentParser(description="Smart Invoice Distributor")
    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument("--invoice", type=str, required=True, help="Path to invoice JSON file")
    parser.add_argument("--recipient", type=str, required=True, help="Path to recipient JSON file")
    parser.add_argument("--channels", type=str, default="email", help="Comma-separated list of channels (email,whatsapp,sms)")
    
    args = parser.parse_args()
    
    distributor = SmartInvoiceDistributor(config_path=args.config)
    
    with open(args.invoice, 'r') as f:
        invoice_data = json.load(f)
    
    with open(args.recipient, 'r') as f:
        recipient_data = json.load(f)
    
    channels = args.channels.split(',')
    
    results = distributor.distribute_invoice(invoice_data, recipient_data, channels)
    
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    main()

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { Sequelize } = require('sequelize');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Database connection
const sequelize = new Sequelize(process.env.DATABASE_URL, {
  dialect: 'postgres',
  logging: false
});

// Test database connection
async function testDbConnection() {
  try {
    await sequelize.authenticate();
    console.log('Database connection has been established successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}

testDbConnection();

// Define models
const Tenant = sequelize.define('Tenant', {
  id: {
    type: Sequelize.UUID,
    defaultValue: Sequelize.UUIDV4,
    primaryKey: true
  },
  name: {
    type: Sequelize.STRING,
    allowNull: false
  },
  domain: {
    type: Sequelize.STRING,
    unique: true
  },
  status: {
    type: Sequelize.STRING,
    defaultValue: 'active'
  }
}, {
  tableName: 'tenants',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

const User = sequelize.define('User', {
  id: {
    type: Sequelize.UUID,
    defaultValue: Sequelize.UUIDV4,
    primaryKey: true
  },
  tenant_id: {
    type: Sequelize.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id'
    }
  },
  email: {
    type: Sequelize.STRING,
    allowNull: false
  },
  password_hash: {
    type: Sequelize.STRING,
    allowNull: false
  },
  first_name: {
    type: Sequelize.STRING
  },
  last_name: {
    type: Sequelize.STRING
  },
  role: {
    type: Sequelize.STRING,
    allowNull: false
  },
  status: {
    type: Sequelize.STRING,
    defaultValue: 'active'
  }
}, {
  tableName: 'users',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

const Organization = sequelize.define('Organization', {
  id: {
    type: Sequelize.UUID,
    defaultValue: Sequelize.UUIDV4,
    primaryKey: true
  },
  tenant_id: {
    type: Sequelize.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id'
    }
  },
  name: {
    type: Sequelize.STRING,
    allowNull: false
  },
  type: {
    type: Sequelize.STRING,
    allowNull: false
  },
  tax_id: {
    type: Sequelize.STRING
  },
  address: {
    type: Sequelize.TEXT
  },
  city: {
    type: Sequelize.STRING
  },
  state: {
    type: Sequelize.STRING
  },
  postal_code: {
    type: Sequelize.STRING
  },
  country: {
    type: Sequelize.STRING
  },
  phone: {
    type: Sequelize.STRING
  },
  email: {
    type: Sequelize.STRING
  },
  website: {
    type: Sequelize.STRING
  },
  status: {
    type: Sequelize.STRING,
    defaultValue: 'active'
  }
}, {
  tableName: 'organizations',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

const Invoice = sequelize.define('Invoice', {
  id: {
    type: Sequelize.UUID,
    defaultValue: Sequelize.UUIDV4,
    primaryKey: true
  },
  tenant_id: {
    type: Sequelize.UUID,
    allowNull: false,
    references: {
      model: 'tenants',
      key: 'id'
    }
  },
  invoice_number: {
    type: Sequelize.STRING,
    allowNull: false
  },
  sme_id: {
    type: Sequelize.UUID,
    allowNull: false,
    references: {
      model: 'organizations',
      key: 'id'
    }
  },
  buyer_id: {
    type: Sequelize.UUID,
    allowNull: false,
    references: {
      model: 'organizations',
      key: 'id'
    }
  },
  amount: {
    type: Sequelize.DECIMAL(15, 2),
    allowNull: false
  },
  currency: {
    type: Sequelize.STRING(3),
    allowNull: false
  },
  issue_date: {
    type: Sequelize.DATEONLY,
    allowNull: false
  },
  due_date: {
    type: Sequelize.DATEONLY,
    allowNull: false
  },
  payment_terms: {
    type: Sequelize.STRING
  },
  status: {
    type: Sequelize.STRING,
    defaultValue: 'draft'
  },
  description: {
    type: Sequelize.TEXT
  },
  document_path: {
    type: Sequelize.STRING
  }
}, {
  tableName: 'invoices',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

// Define relationships
Tenant.hasMany(User, { foreignKey: 'tenant_id' });
User.belongsTo(Tenant, { foreignKey: 'tenant_id' });

Tenant.hasMany(Organization, { foreignKey: 'tenant_id' });
Organization.belongsTo(Tenant, { foreignKey: 'tenant_id' });

Tenant.hasMany(Invoice, { foreignKey: 'tenant_id' });
Invoice.belongsTo(Tenant, { foreignKey: 'tenant_id' });

Organization.hasMany(Invoice, { foreignKey: 'sme_id', as: 'SmeInvoices' });
Invoice.belongsTo(Organization, { foreignKey: 'sme_id', as: 'Sme' });

Organization.hasMany(Invoice, { foreignKey: 'buyer_id', as: 'BuyerInvoices' });
Invoice.belongsTo(Organization, { foreignKey: 'buyer_id', as: 'Buyer' });

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: 'Authentication token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Tenant middleware
const tenantMiddleware = (req, res, next) => {
  const tenantId = req.user.tenant_id;
  
  if (!tenantId) {
    return res.status(400).json({ message: 'Tenant ID is required' });
  }
  
  req.tenantId = tenantId;
  next();
};

// Routes
// Auth routes
app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }
    
    const user = await User.findOne({ where: { email } });
    
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    const isPasswordValid = await bcrypt.compare(password, user.password_hash);
    
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    const tenant = await Tenant.findByPk(user.tenant_id);
    
    if (!tenant || tenant.status !== 'active') {
      return res.status(403).json({ message: 'Tenant account is inactive or not found' });
    }
    
    const token = jwt.sign(
      { 
        id: user.id, 
        email: user.email, 
        role: user.role, 
        tenant_id: user.tenant_id,
        first_name: user.first_name,
        last_name: user.last_name
      }, 
      process.env.JWT_SECRET, 
      { expiresIn: '24h' }
    );
    
    res.json({ 
      token,
      user: {
        id: user.id,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        role: user.role,
        tenant_id: user.tenant_id,
        tenant_name: tenant.name
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// User routes
app.get('/users', authenticateToken, tenantMiddleware, async (req, res) => {
  try {
    const users = await User.findAll({
      where: { tenant_id: req.tenantId },
      attributes: { exclude: ['password_hash'] }
    });
    
    res.json(users);
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.post('/users', authenticateToken, tenantMiddleware, async (req, res) => {
  try {
    const { email, password, first_name, last_name, role } = req.body;
    
    if (!email || !password || !role) {
      return res.status(400).json({ message: 'Email, password, and role are required' });
    }
    
    const existingUser = await User.findOne({
      where: { 
        email,
        tenant_id: req.tenantId
      }
    });
    
    if (existingUser) {
      return res.status(409).json({ message: 'User with this email already exists' });
    }
    
    const passwordHash = await bcrypt.hash(password, 10);
    
    const newUser = await User.create({
      id: uuidv4(),
      tenant_id: req.tenantId,
      email,
      password_hash: passwordHash,
      first_name,
      last_name,
      role,
      status: 'active'
    });
    
    const userData = newUser.toJSON();
    delete userData.password_hash;
    
    res.status(201).json(userData);
  } catch (error) {
    console.error('Create user error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Organization routes
app.get('/organizations', authenticateToken, tenantMiddleware, async (req, res) => {
  try {
    const { type } = req.query;
    
    const whereClause = { tenant_id: req.tenantId };
    
    if (type) {
      whereClause.type = type;
    }
    
    const organizations = await Organization.findAll({
      where: whereClause
    });
    
    res.json(organizations);
  } catch (error) {
    console.error('Get organizations error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.post('/organizations', authenticateToken, tenantMiddleware, async (req, res) => {
  try {
    const { 
      name, type, tax_id, address, city, 
      state, postal_code, country, phone, email, website 
    } = req.body;
    
    if (!name || !type) {
      return res.status(400).json({ message: 'Name and type are required' });
    }
    
    const newOrganization = await Organization.create({
      id: uuidv4(),
      tenant_id: req.tenantId,
      name,
      type,
      tax_id,
      address,
      city,
      state,
      postal_code,
      country,
      phone,
      email,
      website,
      status: 'active'
    });
    
    res.status(201).json(newOrganization);
  } catch (error) {
    console.error('Create organization error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Invoice routes
app.get('/invoices', authenticateToken, tenantMiddleware, async (req, res) => {
  try {
    const { status, sme_id, buyer_id } = req.query;
    
    const whereClause = { tenant_id: req.tenantId };
    
    if (status) {
      whereClause.status = status;
    }
    
    if (sme_id) {
      whereClause.sme_id = sme_id;
    }
    
    if (buyer_id) {
      whereClause.buyer_id = buyer_id;
    }
    
    const invoices = await Invoice.findAll({
      where: whereClause,
      include: [
        { model: Organization, as: 'Sme', attributes: ['id', 'name'] },
        { model: Organization, as: 'Buyer', attributes: ['id', 'name'] }
      ]
    });
    
    res.json(invoices);
  } catch (error) {
    console.error('Get invoices error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.post('/invoices', authenticateToken, tenantMiddleware, async (req, res) => {
  try {
    const { 
      invoice_number, sme_id, buyer_id, amount, currency,
      issue_date, due_date, payment_terms, description
    } = req.body;
    
    if (!invoice_number || !sme_id || !buyer_id || !amount || !currency || !issue_date || !due_date) {
      return res.status(400).json({ 
        message: 'Invoice number, SME ID, buyer ID, amount, currency, issue date, and due date are required' 
      });
    }
    
    const existingInvoice = await Invoice.findOne({
      where: { 
        invoice_number,
        tenant_id: req.tenantId
      }
    });
    
    if (existingInvoice) {
      return res.status(409).json({ message: 'Invoice with this number already exists' });
    }
    
    const newInvoice = await Invoice.create({
      id: uuidv4(),
      tenant_id: req.tenantId,
      invoice_number,
      sme_id,
      buyer_id,
      amount,
      currency,
      issue_date,
      due_date,
      payment_terms,
      status: 'draft',
      description
    });
    
    const invoice = await Invoice.findByPk(newInvoice.id, {
      include: [
        { model: Organization, as: 'Sme', attributes: ['id', 'name'] },
        { model: Organization, as: 'Buyer', attributes: ['id', 'name'] }
      ]
    });
    
    res.status(201).json(invoice);
  } catch (error) {
    console.error('Create invoice error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.put('/invoices/:id/status', authenticateToken, tenantMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    if (!status) {
      return res.status(400).json({ message: 'Status is required' });
    }
    
    const invoice = await Invoice.findOne({
      where: { 
        id,
        tenant_id: req.tenantId
      }
    });
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    await invoice.update({ status });
    
    const updatedInvoice = await Invoice.findByPk(id, {
      include: [
        { model: Organization, as: 'Sme', attributes: ['id', 'name'] },
        { model: Organization, as: 'Buyer', attributes: ['id', 'name'] }
      ]
    });
    
    res.json(updatedInvoice);
  } catch (error) {
    console.error('Update invoice status error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Health check route
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date() });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

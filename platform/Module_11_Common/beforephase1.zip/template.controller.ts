import { Controller, Get, Post, Body, Patch, Param, Delete, UsePipes, ValidationPipe, ParseUUIDPipe, Query, Put, HttpCode, HttpStatus } from "@nestjs/common";
import { TemplateService } from "../services/template.service";
import { CreateInvoiceTemplateDto } from "../dto/create-invoice-template.dto";
import { UpdateInvoiceTemplateDto } from "../dto/update-invoice-template.dto";

@Controller("organizations/:organizationId/templates") // Scoped to an organization
@UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
export class TemplateController {
  constructor(private readonly templateService: TemplateService) {}

  @Post()
  create(
    @Param("organizationId", ParseUUIDPipe) organizationId: string,
    @Body() createInvoiceTemplateDto: CreateInvoiceTemplateDto,
  ) {
    // Ensure the DTO's organization_id matches the path param for security/consistency
    if (createInvoiceTemplateDto.organization_id !== organizationId) {
        throw new Error("Organization ID in body does not match path parameter."); // Or a BadRequestException
    }
    return this.templateService.create(createInvoiceTemplateDto);
  }

  @Get()
  findAll(@Param("organizationId", ParseUUIDPipe) organizationId: string) {
    return this.templateService.findAll(organizationId);
  }

  @Get(":id")
  findOne(
    @Param("id", ParseUUIDPipe) id: string,
    @Param("organizationId", ParseUUIDPipe) organizationId: string,
  ) {
    return this.templateService.findOne(id, organizationId);
  }

  @Put(":id") // Using PUT for full update, PATCH for partial
  update(
    @Param("id", ParseUUIDPipe) id: string,
    @Param("organizationId", ParseUUIDPipe) organizationId: string,
    @Body() updateInvoiceTemplateDto: UpdateInvoiceTemplateDto,
  ) {
    return this.templateService.update(id, updateInvoiceTemplateDto, organizationId);
  }

  @Delete(":id")
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(
    @Param("id", ParseUUIDPipe) id: string,
    @Param("organizationId", ParseUUIDPipe) organizationId: string,
  ) {
    return this.templateService.remove(id, organizationId);
  }

  @Post(":id/set-default")
  setDefault(
    @Param("id", ParseUUIDPipe) id: string,
    @Param("organizationId", ParseUUIDPipe) organizationId: string,
  ) {
    return this.templateService.setAsDefault(id, organizationId);
  }

  @Get("defaults/current") // To get the currently set default template for an org
  findDefault(@Param("organizationId", ParseUUIDPipe) organizationId: string) {
    return this.templateService.findDefault(organizationId);
  }

  // Example for a preview endpoint - might need more specific DTO for sample data
  @Post(":id/preview")
  async generatePreview(
    @Param("id", ParseUUIDPipe) id: string,
    @Param("organizationId", ParseUUIDPipe) organizationId: string,
    @Body() sampleInvoiceData: any, // Define a DTO for this if structure is known
  ) {
    // In a real app, you might return a PDF stream or a URL
    // For now, it returns a string as per the service placeholder
    const previewContent = await this.templateService.generatePreview(id, organizationId, sampleInvoiceData);
    return { preview: previewContent }; 
  }
}


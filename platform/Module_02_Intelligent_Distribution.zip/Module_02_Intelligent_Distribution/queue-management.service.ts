import { Injectable } from '@nestjs/common';
import { DistributionPayload, DistributionResult, IChannelDistributor } from '../interfaces/channel-distributor.interface';
import { CommunicationChannel } from '../../distribution/entities/recipient-contact.entity';
import { DistributionRecordService } from '../../distribution/services/distribution-record.service';
import { DistributionStatus } from '../../distribution/entities/distribution-record.entity';

/**
 * Interface for queue job
 */
export interface QueueJob {
  id: string;
  payload: DistributionPayload;
  priority: number;
  attempts: number;
  maxAttempts: number;
  nextAttemptAt?: Date;
  createdAt: Date;
}

/**
 * Queue management service for handling distribution jobs
 */
@Injectable()
export class QueueManagementService {
  private queue: Map<string, QueueJob> = new Map();
  private distributors: Map<CommunicationChannel, IChannelDistributor> = new Map();
  private isProcessing: boolean = false;
  
  constructor(
    private distributionRecordService: DistributionRecordService,
  ) {}

  /**
   * Register a channel distributor
   */
  registerDistributor(distributor: IChannelDistributor): void {
    this.distributors.set(distributor.getChannelType(), distributor);
  }

  /**
   * Add a job to the queue
   */
  async addToQueue(payload: DistributionPayload, priority: number = 1): Promise<string> {
    const jobId = `job_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
    
    const job: QueueJob = {
      id: jobId,
      payload,
      priority,
      attempts: 0,
      maxAttempts: 3, // Default max attempts
      createdAt: new Date(),
    };
    
    this.queue.set(jobId, job);
    
    // Start processing the queue if not already processing
    if (!this.isProcessing) {
      this.processQueue();
    }
    
    return jobId;
  }

  /**
   * Process the queue
   */
  private async processQueue(): Promise<void> {
    if (this.isProcessing || this.queue.size === 0) {
      return;
    }
    
    this.isProcessing = true;
    
    try {
      // Get the next job with highest priority and earliest next attempt time
      const job = this.getNextJob();
      
      if (job) {
        await this.processJob(job);
      }
    } finally {
      this.isProcessing = false;
      
      // If there are more jobs in the queue, continue processing
      if (this.queue.size > 0) {
        setTimeout(() => this.processQueue(), 100);
      }
    }
  }

  /**
   * Get the next job to process
   */
  private getNextJob(): QueueJob | null {
    const now = new Date();
    let nextJob: QueueJob | null = null;
    
    for (const job of this.queue.values()) {
      // Skip jobs that are scheduled for future retry
      if (job.nextAttemptAt && job.nextAttemptAt > now) {
        continue;
      }
      
      // Find the job with highest priority
      if (!nextJob || job.priority > nextJob.priority) {
        nextJob = job;
      }
    }
    
    return nextJob;
  }

  /**
   * Process a job
   */
  private async processJob(job: QueueJob): Promise<void> {
    const { payload } = job;
    
    // Get the appropriate distributor for the channel
    const distributor = this.distributors.get(payload.channel);
    
    if (!distributor) {
      console.error(`No distributor found for channel ${payload.channel}`);
      this.handleFailedJob(job, `No distributor found for channel ${payload.channel}`);
      return;
    }
    
    // Check if the distributor is available
    const isAvailable = await distributor.isAvailable();
    if (!isAvailable) {
      console.error(`Distributor for channel ${payload.channel} is not available`);
      this.handleFailedJob(job, `Distributor for channel ${payload.channel} is not available`);
      return;
    }
    
    try {
      // Increment attempt counter
      job.attempts++;
      
      // Update distribution record status to PENDING
      await this.distributionRecordService.updateStatus(
        payload.invoiceId,
        DistributionStatus.PENDING,
        payload.metadata?.organizationId as string,
      );
      
      // Distribute the message
      const result = await distributor.distribute(payload);
      
      if (result.success) {
        // Update distribution record status to SENT
        await this.distributionRecordService.updateStatus(
          payload.invoiceId,
          DistributionStatus.SENT,
          payload.metadata?.organizationId as string,
        );
        
        // Remove the job from the queue
        this.queue.delete(job.id);
      } else {
        this.handleFailedJob(job, result.error || 'Unknown error');
      }
    } catch (error) {
      this.handleFailedJob(job, error.message || 'Unknown error');
    }
  }

  /**
   * Handle a failed job
   */
  private handleFailedJob(job: QueueJob, errorMessage: string): void {
    console.error(`Job ${job.id} failed: ${errorMessage}`);
    
    // If max attempts reached, remove the job from the queue
    if (job.attempts >= job.maxAttempts) {
      console.error(`Max attempts reached for job ${job.id}, removing from queue`);
      this.queue.delete(job.id);
      
      // Update distribution record status to FAILED
      this.distributionRecordService.updateStatus(
        job.payload.invoiceId,
        DistributionStatus.FAILED,
        job.payload.metadata?.organizationId as string,
      ).catch(err => {
        console.error(`Failed to update distribution record status: ${err.message}`);
      });
      
      return;
    }
    
    // Schedule retry with exponential backoff
    const retryDelayMs = Math.pow(2, job.attempts) * 1000; // 2^attempts seconds
    job.nextAttemptAt = new Date(Date.now() + retryDelayMs);
    
    console.log(`Scheduled retry for job ${job.id} at ${job.nextAttemptAt}`);
  }

  /**
   * Get the current queue size
   */
  getQueueSize(): number {
    return this.queue.size;
  }

  /**
   * Get a job by ID
   */
  getJob(jobId: string): QueueJob | undefined {
    return this.queue.get(jobId);
  }

  /**
   * Cancel a job
   */
  cancelJob(jobId: string): boolean {
    return this.queue.delete(jobId);
  }
}

import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  Typography,
  Paper,
  Grid,
  Chip,
  Button,
  CircularProgress,
  Divider,
  Alert,
  Tab,
  Tabs
} from '@mui/material';
import { fetchOrganizationById } from '../../store/slices/organizationSlice';
import { fetchInvoices } from '../../store/slices/invoiceSlice';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import BusinessIcon from '@mui/icons-material/Business';
import ReceiptIcon from '@mui/icons-material/Receipt';

// Import components for tabs
// import InvoicesTable from '../../components/invoices/InvoicesTable'; // Removed - Caused build error

const OrganizationDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const { currentOrganization, loading, error } = useSelector((state) => state.organizations);
  const { invoices, loading: invoicesLoading } = useSelector((state) => state.invoices);
  
  const [tabValue, setTabValue] = useState(0);
  
  useEffect(() => {
    if (id) {
      dispatch(fetchOrganizationById(id));
      dispatch(fetchInvoices({ 
        [currentOrganization?.type === 'sme' ? 'sme_id' : 'buyer_id']: id 
      }));
    }
  }, [dispatch, id, currentOrganization?.type]);
  
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  if (loading && !currentOrganization) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
        <CircularProgress />
      </Box>
    );
  }
  
  if (error) {
    return (
      <Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
          <Button
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate('/organizations')}
            sx={{ mr: 2 }}
          >
            Back to Organizations
          </Button>
          <Typography variant="h4" component="h1">
            Organization Details
          </Typography>
        </Box>
        
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
        
        <Button
          variant="contained"
          onClick={() => navigate('/organizations')}
        >
          Return to Organizations
        </Button>
      </Box>
    );
  }
  
  if (!currentOrganization) {
    return (
      <Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
          <Button
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate('/organizations')}
            sx={{ mr: 2 }}
          >
            Back to Organizations
          </Button>
          <Typography variant="h4" component="h1">
            Organization Details
          </Typography>
        </Box>
        
        <Alert severity="warning" sx={{ mb: 3 }}>
          Organization not found
        </Alert>
        
        <Button
          variant="contained"
          onClick={() => navigate('/organizations')}
        >
          Return to Organizations
        </Button>
      </Box>
    );
  }
  
  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/organizations')}
          sx={{ mr: 2 }}
        >
          Back
        </Button>
        <Typography variant="h4" component="h1">
          {currentOrganization.name}
        </Typography>
      </Box>
      
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Chip 
            label={currentOrganization.type === 'sme' ? 'SME' : 'Buyer'} 
            color={currentOrganization.type === 'sme' ? 'secondary' : 'primary'}
          />
          
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button
              variant="outlined"
              startIcon={<EditIcon />}
              onClick={() => {/* Edit functionality would go here */}}
            >
              Edit
            </Button>
          </Box>
        </Box>
        
        <Divider sx={{ my: 2 }} />
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Organization Details
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Name
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.name}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Type
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.type === 'sme' ? 'SME' : 'Buyer'}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Tax ID
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.tax_id || 'N/A'}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Status
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.status.charAt(0).toUpperCase() + currentOrganization.status.slice(1)}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Contact Information
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Typography variant="body2" color="text.secondary">
                  Address
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.address || 'N/A'}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  City
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.city || 'N/A'}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  State/Province
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.state || 'N/A'}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Postal Code
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.postal_code || 'N/A'}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Country
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.country || 'N/A'}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Phone
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.phone || 'N/A'}
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Email
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.email || 'N/A'}
                </Typography>
              </Grid>
              
              <Grid item xs={12}>
                <Typography variant="body2" color="text.secondary">
                  Website
                </Typography>
                <Typography variant="body1">
                  {currentOrganization.website || 'N/A'}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Paper>
      
      <Paper sx={{ p: 3 }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
          <Tabs value={tabValue} onChange={handleTabChange} aria-label="organization tabs">
            <Tab icon={<ReceiptIcon />} label="Invoices" id="tab-0" />
            <Tab icon={<BusinessIcon />} label="Details" id="tab-1" />
          </Tabs>
        </Box>
        
        {tabValue === 0 && (
          <Box>
            <Typography variant="h6" gutterBottom>
              {currentOrganization.type === 'sme' ? 'Invoices Issued' : 'Invoices Received'}
            </Typography>
            
            {invoicesLoading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
                <CircularProgress />
              </Box>
            ) : invoices.length === 0 ? (
              <Alert severity="info">
                No invoices found for this organization.
              </Alert>
            ) : (
              <Box sx={{ mt: 2 }}>
                {/* This would be a reusable component for displaying invoices */}
                <Typography variant="body1">
                  {invoices.length} invoices found
                </Typography>
              </Box>
            )}
          </Box>
        )}
        
        {tabValue === 1 && (
          <Box>
            <Typography variant="h6" gutterBottom>
              Additional Details
            </Typography>
            
            <Alert severity="info">
              Additional organization details would be displayed here.
            </Alert>
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default OrganizationDetailPage;

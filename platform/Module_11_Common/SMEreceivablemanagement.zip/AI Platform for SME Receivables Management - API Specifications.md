# AI Platform for SME Receivables Management - API Specifications

## 1. API Design Principles

### 1.1 General Principles
- All APIs shall follow RESTful design principles
- APIs shall use JSON as the primary data exchange format
- All endpoints shall be versioned (e.g., /api/v1/resource)
- Authentication shall be required for all non-public endpoints
- Rate limiting shall be implemented to prevent abuse
- CORS policies shall be properly configured for web clients
- Comprehensive documentation shall be provided via OpenAPI/Swagger

### 1.2 Response Format
- All responses shall follow a consistent structure
- Success responses shall include status code, data, and metadata
- Error responses shall include status code, error message, and error details
- Pagination metadata shall be included for list endpoints
- Timestamps shall use ISO 8601 format (YYYY-MM-DDTHH:MM:SSZ)
- Field naming shall use camelCase convention
- Null values shall be omitted from responses unless explicitly required

### 1.3 HTTP Methods
- GET: Retrieve resources without side effects
- POST: Create new resources or trigger actions
- PUT: Replace resources completely
- PATCH: Update resources partially
- DELETE: Remove resources
- OPTIONS: Retrieve supported methods and CORS information

### 1.4 Status Codes
- 200 OK: Successful request with response body
- 201 Created: Successful resource creation
- 204 No Content: Successful request without response body
- 400 Bad Request: Invalid request parameters
- 401 Unauthorized: Missing or invalid authentication
- 403 Forbidden: Authentication valid but insufficient permissions
- 404 Not Found: Resource not found
- 409 Conflict: Request conflicts with current state
- 422 Unprocessable Entity: Validation errors
- 429 Too Many Requests: Rate limit exceeded
- 500 Internal Server Error: Unexpected server error

## 2. Authentication and Authorization

### 2.1 Authentication Endpoints

#### 2.1.1 Login
- **Endpoint**: POST /api/v1/auth/login
- **Description**: Authenticate user and receive access token
- **Request Body**:
  ```json
  {
    "email": "string",
    "password": "string",
    "rememberMe": "boolean"
  }
  ```
- **Response**:
  ```json
  {
    "accessToken": "string",
    "refreshToken": "string",
    "expiresIn": "number",
    "tokenType": "Bearer",
    "user": {
      "id": "string",
      "email": "string",
      "name": "string",
      "role": "string"
    }
  }
  ```

#### 2.1.2 Refresh Token
- **Endpoint**: POST /api/v1/auth/refresh
- **Description**: Obtain new access token using refresh token
- **Request Body**:
  ```json
  {
    "refreshToken": "string"
  }
  ```
- **Response**: Same as login response

#### 2.1.3 Logout
- **Endpoint**: POST /api/v1/auth/logout
- **Description**: Invalidate current tokens
- **Request Body**:
  ```json
  {
    "refreshToken": "string"
  }
  ```
- **Response**: 204 No Content

### 2.2 User Management Endpoints

#### 2.2.1 Get Current User
- **Endpoint**: GET /api/v1/users/me
- **Description**: Retrieve current user information
- **Response**:
  ```json
  {
    "id": "string",
    "email": "string",
    "name": "string",
    "role": "string",
    "permissions": ["string"],
    "company": {
      "id": "string",
      "name": "string"
    },
    "preferences": {
      "language": "string",
      "timezone": "string",
      "notifications": {
        "email": "boolean",
        "sms": "boolean",
        "inApp": "boolean"
      }
    }
  }
  ```

#### 2.2.2 Update User
- **Endpoint**: PATCH /api/v1/users/me
- **Description**: Update current user information
- **Request Body**:
  ```json
  {
    "name": "string",
    "email": "string",
    "preferences": {
      "language": "string",
      "timezone": "string",
      "notifications": {
        "email": "boolean",
        "sms": "boolean",
        "inApp": "boolean"
      }
    }
  }
  ```
- **Response**: Updated user object

#### 2.2.3 Change Password
- **Endpoint**: POST /api/v1/users/me/password
- **Description**: Change user password
- **Request Body**:
  ```json
  {
    "currentPassword": "string",
    "newPassword": "string"
  }
  ```
- **Response**: 204 No Content

## 3. Invoice Management APIs

### 3.1 Invoice Endpoints

#### 3.1.1 List Invoices
- **Endpoint**: GET /api/v1/invoices
- **Description**: Retrieve paginated list of invoices
- **Query Parameters**:
  - page: number (default: 1)
  - limit: number (default: 20)
  - status: string (pending, paid, overdue, cancelled)
  - buyerId: string
  - fromDate: string (ISO date)
  - toDate: string (ISO date)
  - minAmount: number
  - maxAmount: number
  - sortBy: string (createdAt, dueDate, amount)
  - sortOrder: string (asc, desc)
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "invoiceNumber": "string",
        "buyer": {
          "id": "string",
          "name": "string",
          "rating": "number"
        },
        "amount": "number",
        "currency": "string",
        "issueDate": "string",
        "dueDate": "string",
        "status": "string",
        "paymentStatus": "string",
        "overdueDays": "number"
      }
    ],
    "pagination": {
      "page": "number",
      "limit": "number",
      "totalItems": "number",
      "totalPages": "number"
    }
  }
  ```

#### 3.1.2 Get Invoice
- **Endpoint**: GET /api/v1/invoices/{id}
- **Description**: Retrieve detailed invoice information
- **Path Parameters**:
  - id: string
- **Response**:
  ```json
  {
    "id": "string",
    "invoiceNumber": "string",
    "irn": "string",
    "buyer": {
      "id": "string",
      "name": "string",
      "rating": "number",
      "contactPerson": "string",
      "email": "string",
      "phone": "string"
    },
    "amount": "number",
    "currency": "string",
    "taxAmount": "number",
    "totalAmount": "number",
    "issueDate": "string",
    "dueDate": "string",
    "paymentTerms": "string",
    "status": "string",
    "paymentStatus": "string",
    "overdueDays": "number",
    "lineItems": [
      {
        "id": "string",
        "description": "string",
        "quantity": "number",
        "unitPrice": "number",
        "taxRate": "number",
        "taxAmount": "number",
        "totalAmount": "number"
      }
    ],
    "payments": [
      {
        "id": "string",
        "amount": "number",
        "date": "string",
        "method": "string",
        "reference": "string"
      }
    ],
    "documents": [
      {
        "id": "string",
        "type": "string",
        "name": "string",
        "url": "string",
        "uploadedAt": "string"
      }
    ],
    "history": [
      {
        "action": "string",
        "timestamp": "string",
        "user": "string",
        "details": "string"
      }
    ],
    "notes": "string",
    "createdAt": "string",
    "updatedAt": "string"
  }
  ```

#### 3.1.3 Create Invoice
- **Endpoint**: POST /api/v1/invoices
- **Description**: Create a new invoice
- **Request Body**:
  ```json
  {
    "buyerId": "string",
    "issueDate": "string",
    "dueDate": "string",
    "currency": "string",
    "paymentTerms": "string",
    "notes": "string",
    "lineItems": [
      {
        "description": "string",
        "quantity": "number",
        "unitPrice": "number",
        "taxRate": "number"
      }
    ],
    "documents": [
      {
        "type": "string",
        "name": "string",
        "fileId": "string"
      }
    ]
  }
  ```
- **Response**: Created invoice object with 201 status

#### 3.1.4 Update Invoice
- **Endpoint**: PATCH /api/v1/invoices/{id}
- **Description**: Update an existing invoice
- **Path Parameters**:
  - id: string
- **Request Body**: Partial invoice object
- **Response**: Updated invoice object

#### 3.1.5 Delete Invoice
- **Endpoint**: DELETE /api/v1/invoices/{id}
- **Description**: Delete an invoice (soft delete)
- **Path Parameters**:
  - id: string
- **Response**: 204 No Content

#### 3.1.6 Generate Invoice PDF
- **Endpoint**: GET /api/v1/invoices/{id}/pdf
- **Description**: Generate PDF version of invoice
- **Path Parameters**:
  - id: string
- **Response**: PDF file download

#### 3.1.7 Send Invoice
- **Endpoint**: POST /api/v1/invoices/{id}/send
- **Description**: Send invoice to buyer
- **Path Parameters**:
  - id: string
- **Request Body**:
  ```json
  {
    "recipientEmail": "string",
    "cc": ["string"],
    "message": "string"
  }
  ```
- **Response**: 200 OK with delivery status

### 3.2 Invoice Payment Endpoints

#### 3.2.1 Record Payment
- **Endpoint**: POST /api/v1/invoices/{id}/payments
- **Description**: Record payment for an invoice
- **Path Parameters**:
  - id: string
- **Request Body**:
  ```json
  {
    "amount": "number",
    "date": "string",
    "method": "string",
    "reference": "string",
    "notes": "string"
  }
  ```
- **Response**: Updated invoice with payment information

#### 3.2.2 Process Online Payment
- **Endpoint**: POST /api/v1/invoices/{id}/pay
- **Description**: Initiate online payment for invoice
- **Path Parameters**:
  - id: string
- **Request Body**:
  ```json
  {
    "paymentMethod": "string",
    "returnUrl": "string"
  }
  ```
- **Response**: Payment gateway redirect information

## 4. Buyer Management APIs

### 4.1 Buyer Endpoints

#### 4.1.1 List Buyers
- **Endpoint**: GET /api/v1/buyers
- **Description**: Retrieve paginated list of buyers
- **Query Parameters**:
  - page: number (default: 1)
  - limit: number (default: 20)
  - search: string
  - status: string (active, inactive)
  - minRating: number
  - maxRating: number
  - sortBy: string (name, rating, outstandingAmount)
  - sortOrder: string (asc, desc)
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "name": "string",
        "contactPerson": "string",
        "email": "string",
        "phone": "string",
        "rating": "number",
        "outstandingAmount": "number",
        "status": "string"
      }
    ],
    "pagination": {
      "page": "number",
      "limit": "number",
      "totalItems": "number",
      "totalPages": "number"
    }
  }
  ```

#### 4.1.2 Get Buyer
- **Endpoint**: GET /api/v1/buyers/{id}
- **Description**: Retrieve detailed buyer information
- **Path Parameters**:
  - id: string
- **Response**:
  ```json
  {
    "id": "string",
    "name": "string",
    "contactPerson": "string",
    "email": "string",
    "phone": "string",
    "address": {
      "street": "string",
      "city": "string",
      "state": "string",
      "postalCode": "string",
      "country": "string"
    },
    "taxIdentifier": {
      "type": "string",
      "value": "string"
    },
    "rating": {
      "overall": "number",
      "paymentBehavior": "number",
      "financialStability": "number",
      "industryStanding": "number"
    },
    "paymentStatistics": {
      "averageDaysLate": "number",
      "onTimePaymentPercentage": "number",
      "totalInvoices": "number",
      "totalPaid": "number",
      "totalOutstanding": "number",
      "totalOverdue": "number"
    },
    "customFields": {
      "field1": "value1",
      "field2": "value2"
    },
    "status": "string",
    "createdAt": "string",
    "updatedAt": "string"
  }
  ```

#### 4.1.3 Create Buyer
- **Endpoint**: POST /api/v1/buyers
- **Description**: Create a new buyer
- **Request Body**:
  ```json
  {
    "name": "string",
    "contactPerson": "string",
    "email": "string",
    "phone": "string",
    "address": {
      "street": "string",
      "city": "string",
      "state": "string",
      "postalCode": "string",
      "country": "string"
    },
    "taxIdentifier": {
      "type": "string",
      "value": "string"
    },
    "customFields": {
      "field1": "value1",
      "field2": "value2"
    }
  }
  ```
- **Response**: Created buyer object with 201 status

#### 4.1.4 Update Buyer
- **Endpoint**: PATCH /api/v1/buyers/{id}
- **Description**: Update an existing buyer
- **Path Parameters**:
  - id: string
- **Request Body**: Partial buyer object
- **Response**: Updated buyer object

#### 4.1.5 Delete Buyer
- **Endpoint**: DELETE /api/v1/buyers/{id}
- **Description**: Delete a buyer (soft delete)
- **Path Parameters**:
  - id: string
- **Response**: 204 No Content

#### 4.1.6 Get Buyer Rating Details
- **Endpoint**: GET /api/v1/buyers/{id}/rating
- **Description**: Retrieve detailed rating information for a buyer
- **Path Parameters**:
  - id: string
- **Response**:
  ```json
  {
    "overall": "number",
    "components": {
      "paymentBehavior": {
        "score": "number",
        "factors": [
          {
            "name": "string",
            "score": "number",
            "weight": "number",
            "description": "string"
          }
        ]
      },
      "financialStability": {
        "score": "number",
        "factors": [
          {
            "name": "string",
            "score": "number",
            "weight": "number",
            "description": "string"
          }
        ]
      },
      "industryStanding": {
        "score": "number",
        "factors": [
          {
            "name": "string",
            "score": "number",
            "weight": "number",
            "description": "string"
          }
        ]
      }
    },
    "history": [
      {
        "date": "string",
        "score": "number",
        "change": "number",
        "reason": "string"
      }
    ],
    "industryComparison": {
      "percentile": "number",
      "industryAverage": "number"
    },
    "recommendations": [
      {
        "type": "string",
        "description": "string",
        "impact": "string"
      }
    ]
  }
  ```

## 5. Payment Terms APIs

### 5.1 Payment Terms Endpoints

#### 5.1.1 Get Recommended Terms
- **Endpoint**: GET /api/v1/payment-terms/recommendations
- **Description**: Get recommended payment terms for a buyer
- **Query Parameters**:
  - buyerId: string
  - amount: number
  - transactionType: string
- **Response**:
  ```json
  {
    "recommended": {
      "daysToPayment": "number",
      "earlyPaymentDiscount": {
        "percentage": "number",
        "daysThreshold": "number"
      },
      "latePaymentPenalty": {
        "percentage": "number",
        "gracePeriod": "number"
      }
    },
    "alternatives": [
      {
        "daysToPayment": "number",
        "earlyPaymentDiscount": {
          "percentage": "number",
          "daysThreshold": "number"
        },
        "latePaymentPenalty": {
          "percentage": "number",
          "gracePeriod": "number"
        },
        "riskLevel": "string",
        "cashFlowImpact": "string"
      }
    ],
    "reasoning": [
      {
        "factor": "string",
        "impact": "string",
        "description": "string"
      }
    ],
    "industryBenchmarks": {
      "averageDaysToPayment": "number",
      "commonDiscountTerms": [
        {
          "percentage": "number",
          "daysThreshold": "number",
          "frequency": "string"
        }
      ]
    }
  }
  ```

#### 5.1.2 List Payment Terms Templates
- **Endpoint**: GET /api/v1/payment-terms/templates
- **Description**: Retrieve list of payment terms templates
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "name": "string",
        "daysToPayment": "number",
        "earlyPaymentDiscount": {
          "percentage": "number",
          "daysThreshold": "number"
        },
        "latePaymentPenalty": {
          "percentage": "number",
          "gracePeriod": "number"
        },
        "description": "string",
        "isDefault": "boolean"
      }
    ]
  }
  ```

#### 5.1.3 Create Payment Terms Template
- **Endpoint**: POST /api/v1/payment-terms/templates
- **Description**: Create a new payment terms template
- **Request Body**:
  ```json
  {
    "name": "string",
    "daysToPayment": "number",
    "earlyPaymentDiscount": {
      "percentage": "number",
      "daysThreshold": "number"
    },
    "latePaymentPenalty": {
      "percentage": "number",
      "gracePeriod": "number"
    },
    "description": "string",
    "isDefault": "boolean"
  }
  ```
- **Response**: Created template object with 201 status

## 6. Communication APIs

### 6.1 Communication Endpoints

#### 6.1.1 List Communications
- **Endpoint**: GET /api/v1/communications
- **Description**: Retrieve paginated list of communications
- **Query Parameters**:
  - page: number (default: 1)
  - limit: number (default: 20)
  - type: string (email, sms, whatsapp, in-app)
  - status: string (scheduled, sent, delivered, failed)
  - buyerId: string
  - invoiceId: string
  - fromDate: string (ISO date)
  - toDate: string (ISO date)
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "type": "string",
        "recipient": {
          "id": "string",
          "name": "string",
          "email": "string",
          "phone": "string"
        },
        "subject": "string",
        "status": "string",
        "scheduledAt": "string",
        "sentAt": "string",
        "deliveredAt": "string",
        "openedAt": "string",
        "relatedEntity": {
          "type": "string",
          "id": "string"
        }
      }
    ],
    "pagination": {
      "page": "number",
      "limit": "number",
      "totalItems": "number",
      "totalPages": "number"
    }
  }
  ```

#### 6.1.2 Get Communication
- **Endpoint**: GET /api/v1/communications/{id}
- **Description**: Retrieve detailed communication information
- **Path Parameters**:
  - id: string
- **Response**:
  ```json
  {
    "id": "string",
    "type": "string",
    "recipient": {
      "id": "string",
      "name": "string",
      "email": "string",
      "phone": "string"
    },
    "subject": "string",
    "content": "string",
    "attachments": [
      {
        "id": "string",
        "name": "string",
        "type": "string",
        "size": "number",
        "url": "string"
      }
    ],
    "status": "string",
    "scheduledAt": "string",
    "sentAt": "string",
    "deliveredAt": "string",
    "openedAt": "string",
    "clickedAt": "string",
    "failureReason": "string",
    "relatedEntity": {
      "type": "string",
      "id": "string"
    },
    "template": {
      "id": "string",
      "name": "string"
    },
    "createdAt": "string",
    "updatedAt": "string"
  }
  ```

#### 6.1.3 Send Communication
- **Endpoint**: POST /api/v1/communications
- **Description**: Send or schedule a communication
- **Request Body**:
  ```json
  {
    "type": "string",
    "recipientId": "string",
    "subject": "string",
    "content": "string",
    "attachments": [
      {
        "fileId": "string"
      }
    ],
    "scheduledAt": "string",
    "relatedEntity": {
      "type": "string",
      "id": "string"
    },
    "templateId": "string",
    "templateData": {
      "key1": "value1",
      "key2": "value2"
    }
  }
  ```
- **Response**: Created communication object with 201 status

#### 6.1.4 Cancel Scheduled Communication
- **Endpoint**: DELETE /api/v1/communications/{id}
- **Description**: Cancel a scheduled communication
- **Path Parameters**:
  - id: string
- **Response**: 204 No Content

### 6.2 Communication Template Endpoints

#### 6.2.1 List Communication Templates
- **Endpoint**: GET /api/v1/communication-templates
- **Description**: Retrieve list of communication templates
- **Query Parameters**:
  - type: string (email, sms, whatsapp, in-app)
  - purpose: string (reminder, confirmation, escalation)
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "name": "string",
        "type": "string",
        "purpose": "string",
        "subject": "string",
        "previewText": "string",
        "createdAt": "string",
        "updatedAt": "string"
      }
    ]
  }
  ```

#### 6.2.2 Get Communication Template
- **Endpoint**: GET /api/v1/communication-templates/{id}
- **Description**: Retrieve detailed template information
- **Path Parameters**:
  - id: string
- **Response**:
  ```json
  {
    "id": "string",
    "name": "string",
    "type": "string",
    "purpose": "string",
    "subject": "string",
    "content": "string",
    "variables": [
      {
        "name": "string",
        "description": "string",
        "required": "boolean"
      }
    ],
    "previewText": "string",
    "createdAt": "string",
    "updatedAt": "string"
  }
  ```

## 7. Analytics APIs

### 7.1 Dashboard Endpoints

#### 7.1.1 Get Dashboard Summary
- **Endpoint**: GET /api/v1/analytics/dashboard
- **Description**: Retrieve summary metrics for dashboard
- **Query Parameters**:
  - period: string (today, week, month, quarter, year)
- **Response**:
  ```json
  {
    "invoices": {
      "total": "number",
      "pending": "number",
      "paid": "number",
      "overdue": "number",
      "totalAmount": "number",
      "pendingAmount": "number",
      "overdueAmount": "number"
    },
    "payments": {
      "received": "number",
      "receivedAmount": "number",
      "expected": "number",
      "expectedAmount": "number"
    },
    "buyers": {
      "total": "number",
      "active": "number",
      "newThisPeriod": "number",
      "withOverdueInvoices": "number"
    },
    "metrics": {
      "dso": "number",
      "dsoTrend": "number",
      "collectionEffectiveness": "number",
      "averageDaysLate": "number"
    },
    "cashFlow": {
      "currentBalance": "number",
      "projectedInflow": "number",
      "projectedOutflow": "number",
      "netProjection": "number"
    }
  }
  ```

#### 7.1.2 Get Aging Analysis
- **Endpoint**: GET /api/v1/analytics/aging
- **Description**: Retrieve aging analysis of receivables
- **Response**:
  ```json
  {
    "buckets": [
      {
        "range": "string",
        "count": "number",
        "amount": "number",
        "percentage": "number"
      }
    ],
    "byBuyer": [
      {
        "buyerId": "string",
        "buyerName": "string",
        "buckets": [
          {
            "range": "string",
            "count": "number",
            "amount": "number",
            "percentage": "number"
          }
        ],
        "total": "number"
      }
    ],
    "summary": {
      "totalOutstanding": "number",
      "totalOverdue": "number",
      "overduePercentage": "number"
    }
  }
  ```

#### 7.1.3 Get Payment Trends
- **Endpoint**: GET /api/v1/analytics/payment-trends
- **Description**: Retrieve payment trend analysis
- **Query Parameters**:
  - period: string (week, month, quarter, year)
  - groupBy: string (day, week, month)
- **Response**:
  ```json
  {
    "trends": [
      {
        "period": "string",
        "invoiced": "number",
        "paid": "number",
        "overdue": "number"
      }
    ],
    "cumulativeTrends": [
      {
        "period": "string",
        "invoiced": "number",
        "paid": "number",
        "overdue": "number"
      }
    ],
    "summary": {
      "totalInvoiced": "number",
      "totalPaid": "number",
      "totalOverdue": "number",
      "paymentRatio": "number"
    }
  }
  ```

### 7.2 Predictive Analytics Endpoints

#### 7.2.1 Get Payment Predictions
- **Endpoint**: GET /api/v1/analytics/payment-predictions
- **Description**: Retrieve payment predictions for outstanding invoices
- **Response**:
  ```json
  {
    "predictions": [
      {
        "invoiceId": "string",
        "invoiceNumber": "string",
        "buyerId": "string",
        "buyerName": "string",
        "amount": "number",
        "dueDate": "string",
        "predictedPaymentDate": "string",
        "predictedDaysLate": "number",
        "probabilityOnTime": "number",
        "probabilityLate": "number",
        "probabilityVeryLate": "number",
        "confidenceScore": "number"
      }
    ],
    "summary": {
      "totalPredictedOnTime": "number",
      "totalPredictedLate": "number",
      "totalPredictedVeryLate": "number",
      "averageDaysLate": "number"
    }
  }
  ```

#### 7.2.2 Get Cash Flow Forecast
- **Endpoint**: GET /api/v1/analytics/cash-flow-forecast
- **Description**: Retrieve cash flow forecast for upcoming periods
- **Query Parameters**:
  - periods: number (default: 12)
  - periodType: string (day, week, month)
- **Response**:
  ```json
  {
    "forecast": [
      {
        "period": "string",
        "expectedInflow": "number",
        "predictedInflow": "number",
        "confidenceInterval": {
          "lower": "number",
          "upper": "number"
        },
        "cumulativeBalance": "number"
      }
    ],
    "summary": {
      "totalExpectedInflow": "number",
      "totalPredictedInflow": "number",
      "averageAccuracy": "number",
      "riskAssessment": "string"
    }
  }
  ```

## 8. Financing APIs

### 8.1 Financing Options Endpoints

#### 8.1.1 Get Financing Options
- **Endpoint**: GET /api/v1/financing/options
- **Description**: Retrieve available financing options
- **Query Parameters**:
  - invoiceIds: string[] (comma-separated)
  - amount: number
- **Response**:
  ```json
  {
    "options": [
      {
        "type": "string",
        "provider": "string",
        "eligibility": "boolean",
        "maxAmount": "number",
        "interestRate": "number",
        "processingFee": "number",
        "term": "number",
        "estimatedTotal": "number",
        "disbursementTime": "string",
        "requirements": [
          {
            "type": "string",
            "description": "string"
          }
        ]
      }
    ],
    "eligibilityFactors": [
      {
        "factor": "string",
        "status": "string",
        "description": "string"
      }
    ],
    "recommendedOption": {
      "type": "string",
      "provider": "string",
      "reason": "string"
    }
  }
  ```

#### 8.1.2 Apply for Financing
- **Endpoint**: POST /api/v1/financing/applications
- **Description**: Submit financing application
- **Request Body**:
  ```json
  {
    "optionType": "string",
    "provider": "string",
    "invoiceIds": ["string"],
    "amount": "number",
    "term": "number",
    "documents": [
      {
        "type": "string",
        "fileId": "string"
      }
    ],
    "additionalInfo": {
      "key1": "value1",
      "key2": "value2"
    }
  }
  ```
- **Response**: Application status with 201 status

#### 8.1.3 Get Financing Applications
- **Endpoint**: GET /api/v1/financing/applications
- **Description**: Retrieve list of financing applications
- **Query Parameters**:
  - status: string (pending, approved, rejected, disbursed)
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "type": "string",
        "provider": "string",
        "amount": "number",
        "term": "number",
        "status": "string",
        "submittedAt": "string",
        "updatedAt": "string"
      }
    ]
  }
  ```

### 8.2 TReDS Integration Endpoints

#### 8.2.1 Get TReDS Eligible Invoices
- **Endpoint**: GET /api/v1/financing/treds/eligible-invoices
- **Description**: Retrieve invoices eligible for TReDS financing
- **Response**:
  ```json
  {
    "data": [
      {
        "invoiceId": "string",
        "invoiceNumber": "string",
        "buyer": {
          "id": "string",
          "name": "string",
          "tredsBuyer": "boolean"
        },
        "amount": "number",
        "dueDate": "string",
        "eligibilityStatus": "string",
        "eligibilityReasons": ["string"]
      }
    ]
  }
  ```

#### 8.2.2 Submit to TReDS
- **Endpoint**: POST /api/v1/financing/treds/submit
- **Description**: Submit invoices to TReDS platform
- **Request Body**:
  ```json
  {
    "platform": "string",
    "invoiceIds": ["string"],
    "additionalInfo": {
      "key1": "value1",
      "key2": "value2"
    }
  }
  ```
- **Response**: Submission status with 201 status

## 9. Integration APIs

### 9.1 Accounting Integration Endpoints

#### 9.1.1 List Accounting Connections
- **Endpoint**: GET /api/v1/integrations/accounting
- **Description**: Retrieve list of accounting system connections
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "provider": "string",
        "status": "string",
        "lastSyncAt": "string",
        "connectedAt": "string"
      }
    ]
  }
  ```

#### 9.1.2 Connect Accounting System
- **Endpoint**: POST /api/v1/integrations/accounting/connect
- **Description**: Initiate connection to accounting system
- **Request Body**:
  ```json
  {
    "provider": "string",
    "credentials": {
      "key1": "value1",
      "key2": "value2"
    },
    "settings": {
      "syncFrequency": "string",
      "syncEntities": ["string"]
    }
  }
  ```
- **Response**: Connection status with 201 status

#### 9.1.3 Sync Accounting Data
- **Endpoint**: POST /api/v1/integrations/accounting/{id}/sync
- **Description**: Trigger manual sync with accounting system
- **Path Parameters**:
  - id: string
- **Request Body**:
  ```json
  {
    "entities": ["string"],
    "fromDate": "string",
    "toDate": "string"
  }
  ```
- **Response**: Sync status

### 9.2 Banking Integration Endpoints

#### 9.2.1 List Banking Connections
- **Endpoint**: GET /api/v1/integrations/banking
- **Description**: Retrieve list of banking connections
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "provider": "string",
        "accountType": "string",
        "accountNumber": "string",
        "status": "string",
        "lastSyncAt": "string",
        "connectedAt": "string"
      }
    ]
  }
  ```

#### 9.2.2 Connect Banking System
- **Endpoint**: POST /api/v1/integrations/banking/connect
- **Description**: Initiate connection to banking system
- **Request Body**:
  ```json
  {
    "provider": "string",
    "accountType": "string",
    "credentials": {
      "key1": "value1",
      "key2": "value2"
    },
    "settings": {
      "syncFrequency": "string"
    }
  }
  ```
- **Response**: Connection status with 201 status

#### 9.2.3 Get Bank Transactions
- **Endpoint**: GET /api/v1/integrations/banking/{id}/transactions
- **Description**: Retrieve bank transactions
- **Path Parameters**:
  - id: string
- **Query Parameters**:
  - fromDate: string (ISO date)
  - toDate: string (ISO date)
  - type: string (credit, debit)
  - minAmount: number
  - maxAmount: number
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "date": "string",
        "description": "string",
        "amount": "number",
        "type": "string",
        "balance": "number",
        "category": "string",
        "reference": "string",
        "matchedInvoice": {
          "id": "string",
          "invoiceNumber": "string"
        }
      }
    ],
    "pagination": {
      "page": "number",
      "limit": "number",
      "totalItems": "number",
      "totalPages": "number"
    }
  }
  ```

### 9.3 Payment Gateway Integration Endpoints

#### 9.3.1 List Payment Gateway Connections
- **Endpoint**: GET /api/v1/integrations/payment-gateways
- **Description**: Retrieve list of payment gateway connections
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "provider": "string",
        "status": "string",
        "supportedMethods": ["string"],
        "connectedAt": "string"
      }
    ]
  }
  ```

#### 9.3.2 Connect Payment Gateway
- **Endpoint**: POST /api/v1/integrations/payment-gateways/connect
- **Description**: Initiate connection to payment gateway
- **Request Body**:
  ```json
  {
    "provider": "string",
    "credentials": {
      "key1": "value1",
      "key2": "value2"
    },
    "settings": {
      "defaultCurrency": "string",
      "webhookUrl": "string"
    }
  }
  ```
- **Response**: Connection status with 201 status

## 10. Webhook APIs

### 10.1 Webhook Endpoints

#### 10.1.1 List Webhooks
- **Endpoint**: GET /api/v1/webhooks
- **Description**: Retrieve list of configured webhooks
- **Response**:
  ```json
  {
    "data": [
      {
        "id": "string",
        "url": "string",
        "events": ["string"],
        "status": "string",
        "createdAt": "string",
        "updatedAt": "string"
      }
    ]
  }
  ```

#### 10.1.2 Create Webhook
- **Endpoint**: POST /api/v1/webhooks
- **Description**: Create a new webhook subscription
- **Request Body**:
  ```json
  {
    "url": "string",
    "events": ["string"],
    "description": "string",
    "secret": "string"
  }
  ```
- **Response**: Created webhook object with 201 status

#### 10.1.3 Update Webhook
- **Endpoint**: PATCH /api/v1/webhooks/{id}
- **Description**: Update an existing webhook
- **Path Parameters**:
  - id: string
- **Request Body**: Partial webhook object
- **Response**: Updated webhook object

#### 10.1.4 Delete Webhook
- **Endpoint**: DELETE /api/v1/webhooks/{id}
- **Description**: Delete a webhook
- **Path Parameters**:
  - id: string
- **Response**: 204 No Content

### 10.2 Webhook Event Types

The following event types are supported for webhook subscriptions:

- `invoice.created`: Triggered when a new invoice is created
- `invoice.updated`: Triggered when an invoice is updated
- `invoice.sent`: Triggered when an invoice is sent to a buyer
- `invoice.viewed`: Triggered when a buyer views an invoice
- `invoice.paid`: Triggered when an invoice is marked as paid
- `invoice.overdue`: Triggered when an invoice becomes overdue
- `payment.received`: Triggered when a payment is received
- `payment.failed`: Triggered when a payment attempt fails
- `buyer.created`: Triggered when a new buyer is created
- `buyer.updated`: Triggered when a buyer information is updated
- `buyer.rating.changed`: Triggered when a buyer's rating changes
- `financing.application.submitted`: Triggered when a financing application is submitted
- `financing.application.approved`: Triggered when a financing application is approved
- `financing.application.rejected`: Triggered when a financing application is rejected
- `integration.sync.completed`: Triggered when an integration sync is completed
- `integration.sync.failed`: Triggered when an integration sync fails

## 11. Multi-Agent APIs

### 11.1 Agent Interaction Endpoints

#### 11.1.1 Get Agent Status
- **Endpoint**: GET /api/v1/agents/status
- **Description**: Retrieve status of all agents in the system
- **Response**:
  ```json
  {
    "agents": [
      {
        "id": "string",
        "type": "string",
        "status": "string",
        "lastActive": "string",
        "currentTasks": "number",
        "healthStatus": "string"
      }
    ],
    "systemStatus": {
      "overallHealth": "string",
      "activeAgents": "number",
      "totalAgents": "number"
    }
  }
  ```

#### 11.1.2 Trigger Agent Action
- **Endpoint**: POST /api/v1/agents/{type}/actions
- **Description**: Trigger a specific agent to perform an action
- **Path Parameters**:
  - type: string (orchestration, invoice, rating, terms, milestone, communication, financing, legal, analytics, integration, payment)
- **Request Body**:
  ```json
  {
    "action": "string",
    "parameters": {
      "key1": "value1",
      "key2": "value2"
    },
    "context": {
      "entityType": "string",
      "entityId": "string"
    }
  }
  ```
- **Response**: Action result or task ID for async operations

#### 11.1.3 Get Agent Task Status
- **Endpoint**: GET /api/v1/agents/tasks/{taskId}
- **Description**: Check status of an asynchronous agent task
- **Path Parameters**:
  - taskId: string
- **Response**:
  ```json
  {
    "taskId": "string",
    "agentType": "string",
    "action": "string",
    "status": "string",
    "progress": "number",
    "result": {
      "key1": "value1",
      "key2": "value2"
    },
    "error": {
      "code": "string",
      "message": "string"
    },
    "startedAt": "string",
    "completedAt": "string"
  }
  ```

### 11.2 Agent Configuration Endpoints

#### 11.2.1 Get Agent Configuration
- **Endpoint**: GET /api/v1/agents/{type}/configuration
- **Description**: Retrieve configuration for a specific agent
- **Path Parameters**:
  - type: string (orchestration, invoice, rating, terms, milestone, communication, financing, legal, analytics, integration, payment)
- **Response**:
  ```json
  {
    "agentType": "string",
    "enabled": "boolean",
    "parameters": {
      "key1": "value1",
      "key2": "value2"
    },
    "integrations": [
      {
        "type": "string",
        "enabled": "boolean",
        "config": {
          "key1": "value1"
        }
      }
    ],
    "aiModel": {
      "provider": "string",
      "model": "string",
      "parameters": {
        "key1": "value1"
      }
    }
  }
  ```

#### 11.2.2 Update Agent Configuration
- **Endpoint**: PATCH /api/v1/agents/{type}/configuration
- **Description**: Update configuration for a specific agent
- **Path Parameters**:
  - type: string
- **Request Body**: Partial configuration object
- **Response**: Updated configuration object

## 12. File Management APIs

### 12.1 File Endpoints

#### 12.1.1 Upload File
- **Endpoint**: POST /api/v1/files
- **Description**: Upload a file to the system
- **Request Body**: Multipart form data with file
- **Response**:
  ```json
  {
    "id": "string",
    "name": "string",
    "type": "string",
    "size": "number",
    "url": "string",
    "uploadedAt": "string"
  }
  ```

#### 12.1.2 Get File
- **Endpoint**: GET /api/v1/files/{id}
- **Description**: Retrieve file metadata
- **Path Parameters**:
  - id: string
- **Response**:
  ```json
  {
    "id": "string",
    "name": "string",
    "type": "string",
    "size": "number",
    "url": "string",
    "uploadedAt": "string",
    "relatedEntity": {
      "type": "string",
      "id": "string"
    }
  }
  ```

#### 12.1.3 Download File
- **Endpoint**: GET /api/v1/files/{id}/download
- **Description**: Download file content
- **Path Parameters**:
  - id: string
- **Response**: File content with appropriate content type

#### 12.1.4 Delete File
- **Endpoint**: DELETE /api/v1/files/{id}
- **Description**: Delete a file
- **Path Parameters**:
  - id: string
- **Response**: 204 No Content

## 13. Multi-tenancy APIs

### 13.1 Tenant Management Endpoints

#### 13.1.1 Create Tenant
- **Endpoint**: POST /api/v1/tenants
- **Description**: Create a new tenant (admin only)
- **Request Body**:
  ```json
  {
    "name": "string",
    "domain": "string",
    "plan": "string",
    "adminEmail": "string",
    "adminName": "string",
    "settings": {
      "key1": "value1",
      "key2": "value2"
    }
  }
  ```
- **Response**: Created tenant object with 201 status

#### 13.1.2 Get Tenant
- **Endpoint**: GET /api/v1/tenants/current
- **Description**: Retrieve current tenant information
- **Response**:
  ```json
  {
    "id": "string",
    "name": "string",
    "domain": "string",
    "plan": "string",
    "status": "string",
    "createdAt": "string",
    "settings": {
      "key1": "value1",
      "key2": "value2"
    },
    "usage": {
      "users": {
        "current": "number",
        "limit": "number"
      },
      "storage": {
        "current": "number",
        "limit": "number"
      },
      "invoices": {
        "current": "number",
        "limit": "number"
      }
    }
  }
  ```

#### 13.1.3 Update Tenant
- **Endpoint**: PATCH /api/v1/tenants/current
- **Description**: Update current tenant information
- **Request Body**: Partial tenant object
- **Response**: Updated tenant object

### 13.2 Tenant Settings Endpoints

#### 13.2.1 Get Tenant Settings
- **Endpoint**: GET /api/v1/tenants/current/settings
- **Description**: Retrieve tenant settings
- **Response**:
  ```json
  {
    "branding": {
      "logo": "string",
      "colors": {
        "primary": "string",
        "secondary": "string",
        "accent": "string"
      },
      "companyName": "string"
    },
    "defaults": {
      "paymentTerms": {
        "daysToPayment": "number",
        "earlyPaymentDiscount": {
          "percentage": "number",
          "daysThreshold": "number"
        },
        "latePaymentPenalty": {
          "percentage": "number",
          "gracePeriod": "number"
        }
      },
      "currency": "string",
      "language": "string",
      "timezone": "string"
    },
    "notifications": {
      "email": {
        "enabled": "boolean",
        "recipients": ["string"]
      },
      "sms": {
        "enabled": "boolean",
        "recipients": ["string"]
      },
      "inApp": {
        "enabled": "boolean"
      }
    },
    "security": {
      "mfaRequired": "boolean",
      "passwordPolicy": {
        "minLength": "number",
        "requireSpecialChars": "boolean",
        "requireNumbers": "boolean",
        "requireUppercase": "boolean",
        "expiryDays": "number"
      },
      "sessionTimeout": "number"
    }
  }
  ```

#### 13.2.2 Update Tenant Settings
- **Endpoint**: PATCH /api/v1/tenants/current/settings
- **Description**: Update tenant settings
- **Request Body**: Partial settings object
- **Response**: Updated settings object

## 14. Health and Monitoring APIs

### 14.1 Health Check Endpoints

#### 14.1.1 System Health
- **Endpoint**: GET /api/v1/health
- **Description**: Check overall system health
- **Response**:
  ```json
  {
    "status": "string",
    "version": "string",
    "uptime": "number",
    "components": [
      {
        "name": "string",
        "status": "string",
        "message": "string"
      }
    ],
    "timestamp": "string"
  }
  ```

#### 14.1.2 Database Health
- **Endpoint**: GET /api/v1/health/database
- **Description**: Check database health
- **Response**:
  ```json
  {
    "status": "string",
    "responseTime": "number",
    "connections": {
      "active": "number",
      "idle": "number",
      "max": "number"
    },
    "timestamp": "string"
  }
  ```

### 14.2 Metrics Endpoints

#### 14.2.1 System Metrics
- **Endpoint**: GET /api/v1/metrics/system
- **Description**: Retrieve system performance metrics
- **Response**:
  ```json
  {
    "cpu": {
      "usage": "number",
      "cores": "number"
    },
    "memory": {
      "total": "number",
      "used": "number",
      "free": "number",
      "usagePercentage": "number"
    },
    "disk": {
      "total": "number",
      "used": "number",
      "free": "number",
      "usagePercentage": "number"
    },
    "network": {
      "bytesIn": "number",
      "bytesOut": "number"
    },
    "timestamp": "string"
  }
  ```

#### 14.2.2 Application Metrics
- **Endpoint**: GET /api/v1/metrics/application
- **Description**: Retrieve application performance metrics
- **Response**:
  ```json
  {
    "requests": {
      "total": "number",
      "perSecond": "number",
      "byStatusCode": {
        "2xx": "number",
        "3xx": "number",
        "4xx": "number",
        "5xx": "number"
      }
    },
    "response": {
      "averageTime": "number",
      "p95Time": "number",
      "p99Time": "number"
    },
    "database": {
      "queries": "number",
      "averageQueryTime": "number"
    },
    "cache": {
      "hitRate": "number",
      "missRate": "number"
    },
    "agents": {
      "active": "number",
      "tasksProcessed": "number",
      "averageProcessingTime": "number"
    },
    "timestamp": "string"
  }
  ```

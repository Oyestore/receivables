# Smart Invoice Generation Module: Design and Implementation Plan

**Date:** May 08, 2025

## 1. Introduction

This document outlines the design and implementation plan for the Smart Invoice Generation Module, a key component of the SME Receivables Management Platform. This module is designed to handle the creation, management, and processing of invoices, incorporating AI-assisted data extraction, template management, and tax calculations, with a focus on the requirements outlined for Phase 1.1.

This plan synthesizes information from the `phase_1_1_detailed_design.md` and `Invoice Generation Agent_ Module Specifications.md` documents, along with other provided resources and knowledge items.

## 2. Scope (Phase 1.1)

Phase 1.1 will focus on delivering the following core functionalities:

*   **Robust Invoice Data Structure:** Implementation of PostgreSQL database schemas for invoices and line items, supporting multi-tenancy.
*   **Manual Invoice Creation:** Allowing users to create invoices manually through a user interface, with comprehensive validation.
*   **AI-Assisted Invoice Creation:**
    *   Integration with a Python-based Tesseract OCR microservice to extract raw text from uploaded existing invoice documents (PDFs/images).
    *   A custom parsing module (within the Node.js Invoice Generation Agent) to process the raw text and pre-fill invoice fields.
    *   Target fields for extraction: Invoice Number, Issue Date, Due Date, Vendor/Client details (best effort), Line Items (Description, Quantity, Unit Price, Line Total), Subtotal, Tax Amounts, and Grand Total.
*   **Core API Endpoints:** Development of RESTful APIs for invoice creation (manual and AI-assisted), retrieval, and updates.

## 3. Architecture

The Smart Invoice Generation Module will be a self-contained backend module, adhering to a layered architecture as specified in the `Invoice Generation Agent_ Module Specifications.md` (Section 7).

### 3.1. High-Level Components:

1.  **API Layer (Controller Layer - Node.js with NestJS recommended):**
    *   Handles HTTP requests, routing, request validation, authentication/authorization, and response formatting.
    *   Endpoints will align with those defined in `phase_1_1_detailed_design.md` (Section 5) and `Invoice Generation Agent_ Module Specifications.md` (Section 5).
2.  **Service Layer (Business Logic Layer - Node.js/NestJS):**
    *   Contains core business logic for invoice processing, AI-assist workflow orchestration, validation, and interaction with the Data Access Layer and AI Integration Service Client.
    *   Implements features detailed in `Invoice Generation Agent_ Module Specifications.md` (Section 2.1).
3.  **Data Access Layer (DAL - Node.js/NestJS with Sequelize ORM):**
    *   Abstracts database interactions with the PostgreSQL database.
    *   Enforces multi-tenancy (`tenant_id` filtering) for all queries.
    *   Manages database connections.
4.  **AI Integration Service Client (Node.js/NestJS):**
    *   Manages communication with the Python Tesseract OCR microservice.
    *   Handles request formatting and response parsing for OCR tasks.
5.  **Python Tesseract OCR Microservice (Python with Flask/FastAPI):**
    *   As detailed in `phase_1_1_detailed_design.md` (Section 3).
    *   Handles image pre-processing and OCR extraction.
    *   Deployed as a Docker container.

### 3.2. Internal Sub-modules (Logical Grouping within Service Layer):

*   **Core Invoice Processing Engine:** Manages invoice lifecycle, validation, and AI-assist workflow.
*   **Custom Parsing Module:** Processes raw text from OCR to extract structured invoice data (rule-based initially, as per `phase_1_1_detailed_design.md` Section 4.1).

## 4. Data Models (PostgreSQL)

The primary data models will be `invoices` and `invoice_line_items` as detailed in `phase_1_1_detailed_design.md` (Section 2). Key aspects include:

*   **`invoices` table:** `id`, `tenant_id`, `client_id`, `invoice_number`, `issue_date`, `due_date`, `status`, `currency`, `sub_total`, `total_tax_amount`, `total_discount_amount`, `grand_total`, `amount_paid`, `balance_due`, `notes`, `terms_and_conditions`, `ai_extraction_source`, `created_at`, `updated_at`.
*   **`invoice_line_items` table:** `id`, `invoice_id`, `tenant_id`, `description`, `quantity`, `unit_price`, `item_sub_total`, `tax_amount`, `discount_amount`, `line_total`, `order_index`.
*   All tables will include `tenant_id` for multi-tenancy.
*   Foreign keys will link to related entities (clients, tenants, etc.).

## 5. API Endpoints (Phase 1.1 Focus)

Based on `phase_1_1_detailed_design.md` (Section 5):

*   **`POST /api/v1/invoices/upload-for-ai-assist`**: For AI-assisted invoice creation.
    *   Workflow: Receives document -> Calls OCR microservice -> Receives raw text -> Passes to Custom Parsing Module -> Returns structured JSON.
*   **`POST /api/v1/invoices`**: For manual invoice creation or saving an AI-assisted draft.
    *   Workflow: Validates data -> Saves to database.
*   **`GET /api/v1/invoices/{invoice_id}`**: Retrieves a specific invoice.
*   **`PUT /api/v1/invoices/{invoice_id}`**: Updates an existing invoice.

## 6. Technology Stack

As per `Invoice Generation Agent_ Module Specifications.md` (Section 7.4) and `phase_1_1_detailed_design.md`:

*   **Backend Framework (Invoice Agent):** Node.js with NestJS (preferred) or Express.js.
*   **Backend Framework (OCR Microservice):** Python with Flask or FastAPI.
*   **Database:** PostgreSQL.
*   **ORM (Node.js):** Sequelize.
*   **OCR Engine:** Tesseract (via `pytesseract` in the Python microservice).
*   **Image Processing (Python):** OpenCV or Pillow.
*   **Deployment:** Docker containers (for both Node.js agent and Python microservice).
*   **PDF Generation (Future Phases/If needed for preview in 1.1):** WeasyPrint (for HTML/CSS to PDF) or FPDF2 (for simple text PDFs), considering CJK support as per knowledge item `builtin_1`.

## 7. Key Features and Considerations

*   **Multi-tenancy:** Strict data isolation using `tenant_id` at all levels.
*   **Modularity:** The agent will be a self-contained module.
*   **Validation:** Comprehensive server-side validation for all inputs as per `phase_1_1_detailed_design.md` (Section 6).
*   **Error Handling:** Robust error handling for OCR service failures, parsing issues, validation errors, and database errors as per `phase_1_1_detailed_design.md` (Section 7).
*   **Open Source Preference:** All chosen technologies align with the preference for widely-used open-source solutions suitable for financial applications.
*   **Workflow Customization (Future Phases):** The design will be extensible to support visual workflow definitions, as per knowledge items.
*   **Smart Invoice Distribution (Future Phases):** The architecture will allow for future integration of distribution channels like email and WhatsApp.
*   **AI Model Preferences (Deepseek R1):** While Phase 1.1 uses Tesseract for OCR, the architecture will be flexible to incorporate more advanced AI models like Deepseek R1 in future phases for enhanced data extraction or other AI capabilities.

## 8. Implementation Plan (High-Level Steps)

1.  **Environment Setup:**
    *   Set up PostgreSQL database.
    *   Set up Node.js/NestJS development environment for the Invoice Agent.
    *   Set up Python/Flask development environment for the OCR Microservice.
    *   Initialize Docker configurations.
2.  **Database Schema Implementation:**
    *   Create `invoices` and `invoice_line_items` tables in PostgreSQL based on the defined models.
3.  **OCR Microservice Development (Python):**
    *   Implement API endpoint (`POST /ocr-service/v1/extract-text`).
    *   Integrate image pre-processing (OpenCV/Pillow).
    *   Integrate Tesseract OCR (`pytesseract`).
    *   Implement error handling and logging.
    *   Dockerize the microservice.
4.  **Invoice Generation Agent Development (Node.js/NestJS):**
    *   **Data Access Layer (DAL):** Implement repositories/services for `invoices` and `invoice_line_items` using Sequelize, ensuring multi-tenancy.
    *   **AI Integration Service Client:** Develop the client to communicate with the OCR microservice.
    *   **Custom Parsing Module (Service Layer):** Implement rule-based parsing logic for extracting structured data from OCR text.
    *   **Core Invoice Processing Engine (Service Layer):** Implement logic for manual invoice creation, AI-assisted pre-fill, validation, and calculations.
    *   **API Layer (Controllers):** Implement API endpoints (`/upload-for-ai-assist`, `/invoices`, `/invoices/{id}`).
    *   Implement authentication/authorization stubs (to be integrated with a platform-wide solution later).
    *   Implement robust error handling and logging.
    *   Dockerize the agent.
5.  **Integration and Testing:**
    *   Develop unit tests for individual components (OCR service, parsing module, service layer logic, API endpoints).
    *   Perform integration testing between the Invoice Agent and the OCR Microservice.
    *   Test the end-to-end AI-assisted invoice creation flow using sample invoice images (e.g., `/home/ubuntu/sample_invoices/sample_invoice_070.png` if available, or request user to provide).
    *   Test manual invoice creation, update, and retrieval functionalities.
6.  **Documentation:**
    *   Document API endpoints (e.g., using Swagger/OpenAPI).
    *   Add code comments and document key architectural decisions.

## 9. Next Steps & Request for Feedback

This design and implementation plan provides a roadmap for developing Phase 1.1 of the Smart Invoice Generation Module. We request your feedback on this plan before proceeding with the implementation.

Specifically, please review:
*   Alignment with your expectations for Phase 1.1.
*   The proposed architecture and technology stack.
*   The defined scope and features.

Once we have your approval, we will proceed with the development tasks outlined in the implementation plan, starting with environment setup and database schema implementation.


import { Injectable, Logger } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { Inject } from '@nestjs/common';
import { Observable } from 'rxjs';
import { timeout, catchError } from 'rxjs/operators';
import { QueueHealthService } from './queue-health.service';

/**
 * Service for interacting with RabbitMQ message broker
 * Handles sending messages to queues and managing queue operations
 */
@Injectable()
export class RabbitMQService {
  private readonly logger = new Logger(RabbitMQService.name);
  
  // Queue names for different distribution channels
  private readonly QUEUES = {
    EMAIL: 'email_distribution',
    WHATSAPP: 'whatsapp_distribution',
    SMS: 'sms_distribution',
    GENERAL: 'general_distribution',
  };
  
  // Timeout for queue operations in milliseconds
  private readonly QUEUE_TIMEOUT = 30000;

  constructor(
    @Inject('DISTRIBUTION_SERVICE') private readonly client: ClientProxy,
    private readonly queueHealthService: QueueHealthService,
  ) {}

  /**
   * Initialize connection to RabbitMQ
   */
  async onModuleInit() {
    try {
      await this.client.connect();
      this.logger.log('Successfully connected to RabbitMQ');
      this.queueHealthService.setStatus('connected');
    } catch (error) {
      this.logger.error(`Failed to connect to RabbitMQ: ${error.message}`, error.stack);
      this.queueHealthService.setStatus('disconnected', error.message);
      // We don't throw here to allow the application to start even if RabbitMQ is not available
      // The health service will report the issue and reconnection will be attempted
    }
  }

  /**
   * Send a distribution message to the appropriate queue based on channel
   * @param data Distribution data to be sent
   * @param channel Communication channel (EMAIL, WHATSAPP, SMS)
   * @returns Observable with the result
   */
  sendDistribution(data: any, channel: string): Observable<any> {
    const queue = this.QUEUES[channel] || this.QUEUES.GENERAL;
    this.logger.log(`Sending distribution to ${queue} queue`);
    
    // Track queue metrics
    this.queueHealthService.incrementMessagesSent(queue);
    
    // Send message to queue with timeout and error handling
    return this.client.emit(queue, data).pipe(
      timeout(this.QUEUE_TIMEOUT),
      catchError((error) => {
        this.logger.error(`Error sending message to ${queue} queue: ${error.message}`, error.stack);
        this.queueHealthService.incrementErrors(queue);
        throw error;
      })
    );
  }

  /**
   * Send a follow-up message to the appropriate queue based on channel
   * @param data Follow-up data to be sent
   * @param channel Communication channel (EMAIL, WHATSAPP, SMS)
   * @returns Observable with the result
   */
  sendFollowUp(data: any, channel: string): Observable<any> {
    const queue = this.QUEUES[channel] || this.QUEUES.GENERAL;
    this.logger.log(`Sending follow-up to ${queue} queue`);
    
    // Track queue metrics
    this.queueHealthService.incrementMessagesSent(queue);
    
    // Send message to queue with timeout and error handling
    return this.client.emit(queue, {
      ...data,
      isFollowUp: true,
    }).pipe(
      timeout(this.QUEUE_TIMEOUT),
      catchError((error) => {
        this.logger.error(`Error sending follow-up to ${queue} queue: ${error.message}`, error.stack);
        this.queueHealthService.incrementErrors(queue);
        throw error;
      })
    );
  }

  /**
   * Check if a specific queue is available
   * @param channel Communication channel (EMAIL, WHATSAPP, SMS)
   * @returns Promise resolving to boolean indicating availability
   */
  async isQueueAvailable(channel: string): Promise<boolean> {
    try {
      const queue = this.QUEUES[channel] || this.QUEUES.GENERAL;
      // Send a ping message to check queue availability
      await this.client.emit(`${queue}.ping`, { timestamp: Date.now() }).toPromise();
      return true;
    } catch (error) {
      this.logger.warn(`Queue for channel ${channel} is not available: ${error.message}`);
      return false;
    }
  }

  /**
   * Get the current health status of all queues
   * @returns Object containing queue health metrics
   */
  getQueueHealth(): any {
    return this.queueHealthService.getHealthMetrics();
  }
}

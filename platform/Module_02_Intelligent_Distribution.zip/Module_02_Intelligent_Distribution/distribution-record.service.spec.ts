import { Test, TestingModule } from '@nestjs/testing';
import { DistributionRecordService } from '../../services/distribution-record.service';
import { DistributionRecord, DistributionStatus } from '../../entities/distribution-record.entity';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { NotFoundException } from '@nestjs/common';
import { CreateDistributionRecordDto, UpdateDistributionRecordDto } from '../../dto/distribution-record.dto';
import { RecipientContactService } from '../../services/recipient-contact.service';
import { CommunicationChannel } from '../../entities/recipient-contact.entity';

describe('DistributionRecordService', () => {
  let service: DistributionRecordService;
  let repository: Repository<DistributionRecord>;
  let recipientContactService: RecipientContactService;

  const mockRepository = {
    create: jest.fn(),
    save: jest.fn(),
    find: jest.fn(),
    findOne: jest.fn(),
    remove: jest.fn(),
  };

  const mockRecipientContactService = {
    findOne: jest.fn(),
  };

  const testOrganizationId = 'test-org-id';
  const testDistributionRecord = {
    id: 'test-id',
    invoiceId: 'test-invoice-id',
    recipientId: 'test-recipient-id',
    channel: CommunicationChannel.EMAIL,
    status: DistributionStatus.PENDING,
    sentAt: null,
    deliveredAt: null,
    openedAt: null,
    organizationId: testOrganizationId,
    createdAt: new Date(),
    recipient: {
      id: 'test-recipient-id',
      recipientName: 'Test Recipient',
      email: 'test@example.com',
    },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DistributionRecordService,
        {
          provide: getRepositoryToken(DistributionRecord),
          useValue: mockRepository,
        },
        {
          provide: RecipientContactService,
          useValue: mockRecipientContactService,
        },
      ],
    }).compile();

    service = module.get<DistributionRecordService>(DistributionRecordService);
    repository = module.get<Repository<DistributionRecord>>(getRepositoryToken(DistributionRecord));
    recipientContactService = module.get<RecipientContactService>(RecipientContactService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('create', () => {
    it('should create a new distribution record', async () => {
      const createDto: CreateDistributionRecordDto = {
        invoiceId: 'test-invoice-id',
        recipientId: 'test-recipient-id',
        channel: CommunicationChannel.EMAIL,
        organizationId: testOrganizationId,
      };

      mockRecipientContactService.findOne.mockResolvedValue({});
      mockRepository.create.mockReturnValue(testDistributionRecord);
      mockRepository.save.mockResolvedValue(testDistributionRecord);

      const result = await service.create(createDto);

      expect(mockRecipientContactService.findOne).toHaveBeenCalledWith(
        createDto.recipientId,
        createDto.organizationId,
      );
      expect(mockRepository.create).toHaveBeenCalledWith(createDto);
      expect(mockRepository.save).toHaveBeenCalledWith(testDistributionRecord);
      expect(result).toEqual(testDistributionRecord);
    });
  });

  describe('findAll', () => {
    it('should return an array of distribution records for the organization', async () => {
      mockRepository.find.mockResolvedValue([testDistributionRecord]);

      const result = await service.findAll(testOrganizationId);

      expect(mockRepository.find).toHaveBeenCalledWith({
        where: { organizationId: testOrganizationId },
        relations: ['recipient'],
        order: { createdAt: 'DESC' },
      });
      expect(result).toEqual([testDistributionRecord]);
    });
  });

  describe('findByInvoice', () => {
    it('should return distribution records for a specific invoice', async () => {
      mockRepository.find.mockResolvedValue([testDistributionRecord]);

      const result = await service.findByInvoice('test-invoice-id', testOrganizationId);

      expect(mockRepository.find).toHaveBeenCalledWith({
        where: { invoiceId: 'test-invoice-id', organizationId: testOrganizationId },
        relations: ['recipient'],
        order: { createdAt: 'DESC' },
      });
      expect(result).toEqual([testDistributionRecord]);
    });
  });

  describe('findOne', () => {
    it('should return a distribution record when it exists', async () => {
      mockRepository.findOne.mockResolvedValue(testDistributionRecord);

      const result = await service.findOne('test-id', testOrganizationId);

      expect(mockRepository.findOne).toHaveBeenCalledWith({
        where: { id: 'test-id', organizationId: testOrganizationId },
        relations: ['recipient'],
      });
      expect(result).toEqual(testDistributionRecord);
    });

    it('should throw NotFoundException when distribution record does not exist', async () => {
      mockRepository.findOne.mockResolvedValue(null);

      await expect(service.findOne('non-existent-id', testOrganizationId)).rejects.toThrow(
        NotFoundException,
      );
    });
  });

  describe('update', () => {
    it('should update and return the distribution record', async () => {
      const updateDto: UpdateDistributionRecordDto = {
        status: DistributionStatus.SENT,
        sentAt: new Date(),
      };

      const updatedRecord = { ...testDistributionRecord, ...updateDto };

      mockRepository.findOne.mockResolvedValue(testDistributionRecord);
      mockRepository.save.mockResolvedValue(updatedRecord);

      const result = await service.update('test-id', updateDto, testOrganizationId);

      expect(mockRepository.findOne).toHaveBeenCalledWith({
        where: { id: 'test-id', organizationId: testOrganizationId },
        relations: ['recipient'],
      });
      expect(mockRepository.save).toHaveBeenCalledWith({
        ...testDistributionRecord,
        ...updateDto,
      });
      expect(result).toEqual(updatedRecord);
    });
  });

  describe('updateStatus', () => {
    it('should update status to SENT and set sentAt timestamp', async () => {
      const status = DistributionStatus.SENT;
      const updatedRecord = { 
        ...testDistributionRecord, 
        status, 
        sentAt: expect.any(Date) 
      };

      mockRepository.findOne.mockResolvedValue(testDistributionRecord);
      mockRepository.save.mockResolvedValue(updatedRecord);

      const result = await service.updateStatus('test-id', status, testOrganizationId);

      expect(mockRepository.findOne).toHaveBeenCalledWith({
        where: { id: 'test-id', organizationId: testOrganizationId },
        relations: ['recipient'],
      });
      expect(mockRepository.save).toHaveBeenCalledWith(expect.objectContaining({
        ...testDistributionRecord,
        status,
        sentAt: expect.any(Date),
      }));
      expect(result).toEqual(updatedRecord);
    });

    it('should update status to DELIVERED and set deliveredAt timestamp', async () => {
      const status = DistributionStatus.DELIVERED;
      const updatedRecord = { 
        ...testDistributionRecord, 
        status, 
        deliveredAt: expect.any(Date) 
      };

      mockRepository.findOne.mockResolvedValue(testDistributionRecord);
      mockRepository.save.mockResolvedValue(updatedRecord);

      const result = await service.updateStatus('test-id', status, testOrganizationId);

      expect(mockRepository.save).toHaveBeenCalledWith(expect.objectContaining({
        ...testDistributionRecord,
        status,
        deliveredAt: expect.any(Date),
      }));
      expect(result).toEqual(updatedRecord);
    });

    it('should update status to OPENED and set openedAt timestamp', async () => {
      const status = DistributionStatus.OPENED;
      const updatedRecord = { 
        ...testDistributionRecord, 
        status, 
        openedAt: expect.any(Date) 
      };

      mockRepository.findOne.mockResolvedValue(testDistributionRecord);
      mockRepository.save.mockResolvedValue(updatedRecord);

      const result = await service.updateStatus('test-id', status, testOrganizationId);

      expect(mockRepository.save).toHaveBeenCalledWith(expect.objectContaining({
        ...testDistributionRecord,
        status,
        openedAt: expect.any(Date),
      }));
      expect(result).toEqual(updatedRecord);
    });
  });

  describe('remove', () => {
    it('should remove the distribution record', async () => {
      mockRepository.findOne.mockResolvedValue(testDistributionRecord);

      await service.remove('test-id', testOrganizationId);

      expect(mockRepository.findOne).toHaveBeenCalledWith({
        where: { id: 'test-id', organizationId: testOrganizationId },
        relations: ['recipient'],
      });
      expect(mockRepository.remove).toHaveBeenCalledWith(testDistributionRecord);
    });
  });
});

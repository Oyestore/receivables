import { Injectable, Logger } from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { DistributionConsumerService } from '../services/distribution-consumer.service';
import { SmsDistributorService } from '../../channel-integration/providers/sms-distributor.service';

/**
 * Consumer for SMS distribution messages from RabbitMQ
 */
@Injectable()
export class SmsDistributionConsumer {
  private readonly logger = new Logger(SmsDistributionConsumer.name);
  private readonly queueName = 'sms_distribution';

  constructor(
    private readonly distributionConsumerService: DistributionConsumerService,
    private readonly smsDistributorService: SmsDistributorService,
  ) {}

  /**
   * Process SMS distribution messages from the queue
   * @param data Distribution data from the queue
   */
  @MessagePattern('sms_distribution')
  async processSmsDistribution(@Payload() data: any) {
    const startTime = Date.now();
    this.logger.log(`Processing SMS distribution: ${JSON.stringify(data)}`);
    
    try {
      // Process the SMS distribution
      if (data.isTest) {
        this.logger.log('Test message received, simulating processing');
        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 500));
      } else {
        // Actual SMS distribution logic
        await this.smsDistributorService.sendSms(data);
      }
      
      // Record successful processing
      const processingTime = Date.now() - startTime;
      this.distributionConsumerService.recordMessageProcessed(this.queueName, processingTime);
      
      return { success: true, processingTime };
    } catch (error) {
      // Record processing error
      this.distributionConsumerService.recordProcessingError(this.queueName, error);
      
      // Return error response
      return { 
        success: false, 
        error: error.message,
        processingTime: Date.now() - startTime
      };
    }
  }

  /**
   * Handle ping messages to check queue availability
   * @param data Ping data
   */
  @MessagePattern('sms_distribution.ping')
  handlePing(@Payload() data: any) {
    this.logger.debug(`Received ping: ${JSON.stringify(data)}`);
    return { 
      pong: true, 
      timestamp: Date.now(),
      originalTimestamp: data.timestamp
    };
  }
}

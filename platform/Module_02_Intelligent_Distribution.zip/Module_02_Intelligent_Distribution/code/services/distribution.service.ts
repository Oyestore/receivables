import { Pool } from 'pg';
import { databaseService } from '../../../common/database/database.service';
import { Logger } from '../../../common/logging/logger';
import { metricsService } from '../../../common/monitoring/metrics.service';
import { notificationService } from '../../../common/notifications/notification.service';
import {
  NotFoundError,
  ValidationError,
  DatabaseError,
} from '../../../common/errors/app-error';
import {
  IDistributionChannel,
  IDistributionJob,
  IDistributionLog,
  DistributionStatus,
  ChannelType,
} from '../types/distribution.types';

const logger = new Logger('DistributionService');

/**
 * Distribution Service
 * Handles multi-channel invoice distribution (Email, WhatsApp, SMS, Portal)
 */
export class DistributionService {
  private pool: Pool;

  constructor() {
    this.pool = databaseService.getPool();
  }

  /**
   * Create distribution channel
   */
  async createChannel(
    tenantId: string,
    channelData: {
      name: string;
      channel_type: ChannelType;
      configuration: any;
      is_default?: boolean;
    }
  ): Promise<IDistributionChannel> {
    try {
      const query = `
        INSERT INTO distribution_channels (
          tenant_id, name, channel_type, configuration, is_default, is_active
        ) VALUES ($1, $2, $3, $4, $5, true)
        RETURNING *
      `;

      const result = await this.pool.query(query, [
        tenantId,
        channelData.name,
        channelData.channel_type,
        JSON.stringify(channelData.configuration),
        channelData.is_default || false,
      ]);

      logger.info('Distribution channel created', {
        channelId: result.rows[0].id,
        channelType: channelData.channel_type,
        tenantId,
      });

      return result.rows[0];
    } catch (error) {
      logger.error('Failed to create distribution channel', { error, tenantId });
      throw new DatabaseError('Failed to create distribution channel');
    }
  }

  /**
   * Distribute invoice through specified channels
   */
  async distributeInvoice(
    tenantId: string,
    invoiceId: string,
    channels: ChannelType[],
    userId: string
  ): Promise<IDistributionJob> {
    const client = await this.pool.connect();

    try {
      await client.query('BEGIN');

      // Get invoice details
      const invoiceResult = await client.query(
        `SELECT i.*, c.email, c.phone, c.company_name
         FROM invoices i
         JOIN customers c ON i.customer_id = c.id
         WHERE i.id = $1 AND i.tenant_id = $2`,
        [invoiceId, tenantId]
      );

      if (invoiceResult.rows.length === 0) {
        throw new NotFoundError('Invoice not found');
      }

      const invoice = invoiceResult.rows[0];

      // Create distribution job
      const jobQuery = `
        INSERT INTO distribution_jobs (
          tenant_id, invoice_id, channels, status, initiated_by
        ) VALUES ($1, $2, $3, 'pending', $4)
        RETURNING *
      `;

      const jobResult = await client.query(jobQuery, [
        tenantId,
        invoiceId,
        JSON.stringify(channels),
        userId,
      ]);

      const job = jobResult.rows[0];

      // Process each channel
      for (const channelType of channels) {
        await this.processChannel(client, tenantId, job.id, invoice, channelType);
      }

      // Update job status
      await client.query(
        'UPDATE distribution_jobs SET status = $1, completed_at = CURRENT_TIMESTAMP WHERE id = $2',
        ['completed', job.id]
      );

      // Update invoice status
      await client.query(
        'UPDATE invoices SET status = $1, sent_at = CURRENT_TIMESTAMP WHERE id = $2',
        ['sent', invoiceId]
      );

      await client.query('COMMIT');

      logger.info('Invoice distributed', {
        jobId: job.id,
        invoiceId,
        channels,
        tenantId,
      });

      return job;
    } catch (error) {
      await client.query('ROLLBACK');
      logger.error('Failed to distribute invoice', { error, invoiceId, tenantId });
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Get distribution history for invoice
   */
  async getDistributionHistory(
    tenantId: string,
    invoiceId: string
  ): Promise<IDistributionLog[]> {
    try {
      const query = `
        SELECT dl.*, dj.channels, dc.name as channel_name
        FROM distribution_logs dl
        JOIN distribution_jobs dj ON dl.job_id = dj.id
        LEFT JOIN distribution_channels dc ON dl.channel_id = dc.id
        WHERE dl.tenant_id = $1 AND dj.invoice_id = $2
        ORDER BY dl.created_at DESC
      `;

      const result = await this.pool.query(query, [tenantId, invoiceId]);
      return result.rows;
    } catch (error) {
      logger.error('Failed to get distribution history', { error, invoiceId, tenantId });
      throw new DatabaseError('Failed to retrieve distribution history');
    }
  }

  /**
   * Track delivery status
   */
  async trackDeliveryStatus(
    tenantId: string,
    logId: string
  ): Promise<{ status: string; details: any }> {
    try {
      const result = await this.pool.query(
        'SELECT * FROM distribution_logs WHERE id = $1 AND tenant_id = $2',
        [logId, tenantId]
      );

      if (result.rows.length === 0) {
        throw new NotFoundError('Distribution log not found');
      }

      const log = result.rows[0];

      // In production, this would query the actual delivery service
      // For email: check email service provider API
      // For WhatsApp: check WhatsApp Business API
      // For SMS: check SMS gateway API

      return {
        status: log.status,
        details: {
          sent_at: log.sent_at,
          delivered_at: log.delivered_at,
          opened_at: log.opened_at,
          channel_type: log.channel_type,
        },
      };
    } catch (error) {
      if (error instanceof NotFoundError) throw error;
      logger.error('Failed to track delivery status', { error, logId, tenantId });
      throw new DatabaseError('Failed to track delivery status');
    }
  }

  /**
   * Process distribution through specific channel
   */
  private async processChannel(
    client: any,
    tenantId: string,
    jobId: string,
    invoice: any,
    channelType: ChannelType
  ): Promise<void> {
    try {
      // Get channel configuration
      const channelResult = await client.query(
        'SELECT * FROM distribution_channels WHERE tenant_id = $1 AND channel_type = $2 AND is_active = true',
        [tenantId, channelType]
      );

      if (channelResult.rows.length === 0) {
        throw new ValidationError(`No active ${channelType} channel configured`);
      }

      const channel = channelResult.rows[0];

      // Send through channel
      let deliveryResult;
      switch (channelType) {
        case 'email':
          deliveryResult = await this.sendViaEmail(invoice, channel);
          break;
        case 'whatsapp':
          deliveryResult = await this.sendViaWhatsApp(invoice, channel);
          break;
        case 'sms':
          deliveryResult = await this.sendViaSMS(invoice, channel);
          break;
        case 'portal':
          deliveryResult = await this.publishToPortal(invoice, channel);
          break;
        default:
          throw new ValidationError(`Unsupported channel type: ${channelType}`);
      }

      // Log distribution
      await client.query(
        `INSERT INTO distribution_logs (
          tenant_id, job_id, channel_id, channel_type,
          recipient, status, metadata, sent_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP)`,
        [
          tenantId,
          jobId,
          channel.id,
          channelType,
          deliveryResult.recipient,
          'sent',
          JSON.stringify(deliveryResult.metadata),
        ]
      );

      logger.info('Invoice sent via channel', {
        jobId,
        channelType,
        recipient: deliveryResult.recipient,
      });
    } catch (error) {
      // Log failed delivery
      await client.query(
        `INSERT INTO distribution_logs (
          tenant_id, job_id, channel_type, status, error_message
        ) VALUES ($1, $2, $3, 'failed', $4)`,
        [tenantId, jobId, channelType, error.message]
      );

      logger.error('Failed to send via channel', {
        error,
        jobId,
        channelType,
      });
    }
  }

  /**
   * Send invoice via email
   */
  private async sendViaEmail(
    invoice: any,
    channel: IDistributionChannel
  ): Promise<{ recipient: string; metadata: any }> {
    // Generate invoice PDF
    const pdfUrl = await this.generateInvoicePDF(invoice);

    // Send email with invoice attachment
    await notificationService.sendEmail({
      to: invoice.email,
      subject: `Invoice ${invoice.invoice_number} from ${invoice.company_name}`,
      template: 'invoice',
      data: {
        invoice_number: invoice.invoice_number,
        total_amount: invoice.total_amount,
        due_date: invoice.due_date,
        pdf_url: pdfUrl,
      },
    });

    return {
      recipient: invoice.email,
      metadata: {
        pdf_url: pdfUrl,
        email_provider: channel.configuration.provider,
      },
    };
  }

  /**
   * Send invoice via WhatsApp
   */
  private async sendViaWhatsApp(
    invoice: any,
    channel: IDistributionChannel
  ): Promise<{ recipient: string; metadata: any }> {
    // Format phone number
    const phoneNumber = this.formatPhoneNumber(invoice.phone);

    // Generate invoice link
    const invoiceLink = await this.generateInvoiceLink(invoice);

    // Send WhatsApp message
    // In production, integrate with WhatsApp Business API
    const message = `Hi! Your invoice ${invoice.invoice_number} for ${invoice.total_amount} is ready. View it here: ${invoiceLink}`;

    // TODO: Integrate with WhatsApp Business API
    // await whatsappAPI.sendMessage(phoneNumber, message);

    return {
      recipient: phoneNumber,
      metadata: {
        invoice_link: invoiceLink,
        message_length: message.length,
      },
    };
  }

  /**
   * Send invoice via SMS
   */
  private async sendViaSMS(
    invoice: any,
    channel: IDistributionChannel
  ): Promise<{ recipient: string; metadata: any }> {
    const phoneNumber = this.formatPhoneNumber(invoice.phone);
    const invoiceLink = await this.generateInvoiceLink(invoice);

    const message = `Invoice ${invoice.invoice_number}: ${invoice.total_amount}. View: ${invoiceLink}`;

    await notificationService.sendSMS(phoneNumber, message);

    return {
      recipient: phoneNumber,
      metadata: {
        invoice_link: invoiceLink,
        message_length: message.length,
      },
    };
  }

  /**
   * Publish invoice to customer portal
   */
  private async publishToPortal(
    invoice: any,
    channel: IDistributionChannel
  ): Promise<{ recipient: string; metadata: any }> {
    // Create portal access link
    const portalLink = `${channel.configuration.portal_url}/invoices/${invoice.id}`;

    // Send notification that invoice is available
    await notificationService.sendEmail({
      to: invoice.email,
      subject: 'New invoice available in your portal',
      template: 'portal_notification',
      data: {
        invoice_number: invoice.invoice_number,
        portal_link: portalLink,
      },
    });

    return {
      recipient: invoice.email,
      metadata: {
        portal_link: portalLink,
      },
    };
  }

  /**
   * Generate invoice PDF
   */
  private async generateInvoicePDF(invoice: any): Promise<string> {
    // In production, use a PDF generation library
    // For now, return a placeholder URL
    return `https://invoices.example.com/pdf/${invoice.id}.pdf`;
  }

  /**
   * Generate invoice link
   */
  private async generateInvoiceLink(invoice: any): Promise<string> {
    // Generate secure, time-limited link
    const token = Buffer.from(`${invoice.id}:${Date.now()}`).toString('base64');
    return `https://invoices.example.com/view/${token}`;
  }

  /**
   * Format phone number
   */
  private formatPhoneNumber(phone: string): string {
    // Remove non-numeric characters
    const cleaned = phone.replace(/\D/g, '');

    // Add country code if missing (assuming India +91)
    if (!cleaned.startsWith('91') && cleaned.length === 10) {
      return `91${cleaned}`;
    }

    return cleaned;
  }
}

export const distributionService = new DistributionService();

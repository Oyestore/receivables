#!/bin/bash

# Enhanced deployment script for SME Receivables Management Platform
# This script sets up and validates the complete deployment

set -e

echo "Starting enhanced deployment of SME Receivables Management Platform..."

# Create necessary directories
mkdir -p ./logs
mkdir -p ./data/postgres
mkdir -p ./data/redis
mkdir -p ./data/minio
mkdir -p ./data/elasticsearch

# Check if .env file exists, if not create from example
if [ ! -f .env ]; then
  echo "Creating .env file from template..."
  cp .env.example .env
  echo "Please update the .env file with your specific configuration"
  echo "Then run this script again"
  exit 0
fi

# Validate environment
echo "Validating environment..."
docker --version
docker-compose --version

# Pull latest images
echo "Pulling latest Docker images..."
docker-compose pull

# Start the services
echo "Starting services..."
docker-compose up -d

# Wait for services to be ready
echo "Waiting for services to initialize (this may take a minute)..."
sleep 30

# Run database migrations
echo "Running database migrations..."
docker-compose exec -T api npm run migrate

# Run tests to verify deployment
echo "Running deployment verification tests..."
docker-compose exec -T api npm run test:deployment

# Check if Deepseek R1 is configured for local deployment
if grep -q "AI_MODEL_DEPLOYMENT=local" .env; then
  echo "Setting up local Deepseek R1 model..."
  
  # Check if model is already downloaded
  if [ ! -d "./ai/models/deepseek-r1" ]; then
    echo "Downloading Deepseek R1 model weights..."
    cd ai && ./download_deepseek_model.sh
    cd ..
  fi
  
  # Test AI service
  echo "Testing AI service with local model..."
  cd ai && python3 ai_service.py --function analyze_invoice --input test_data/sample_invoice.json --output test_output.json
  cd ..
  
  if [ -f "./ai/test_output.json" ]; then
    echo "AI service test successful!"
  else
    echo "Warning: AI service test failed. Please check the logs."
  fi
else
  echo "Deepseek R1 configured for API deployment. Skipping local model setup."
  echo "Testing API connectivity..."
  docker-compose exec -T api npm run test:ai-connectivity
fi

# Generate API documentation
echo "Generating API documentation..."
docker-compose exec -T api npm run generate-docs

# Print deployment information
echo ""
echo "=== SME Receivables Management Platform ==="
echo "Deployment completed successfully!"
echo ""
echo "Access the application at: http://localhost:8080"
echo "API documentation available at: http://localhost:8080/api-docs"
echo "Admin portal available at: http://localhost:8080/admin"
echo ""
echo "Default admin credentials:"
echo "Email: admin@demo.com"
echo "Password: admin123"
echo ""
echo "For production deployment, please:"
echo "1. Change all default passwords"
echo "2. Configure SSL/TLS"
echo "3. Set up regular backups"
echo "4. Review security settings"
echo ""
echo "For more information, see the deployment guide at ./docs/deployment_guide.md"
echo "=== Deployment Complete ==="

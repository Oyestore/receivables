import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Paper,
  TextField,
  Button,
  Grid,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  FormHelperText,
  CircularProgress,
  Alert,
  Divider
} from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { createInvoice } from '../../store/slices/invoiceSlice';
import { fetchOrganizations } from '../../store/slices/organizationSlice';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

const CreateInvoicePage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const { loading, error } = useSelector((state) => state.invoices);
  const { smes, buyers, loading: organizationsLoading } = useSelector((state) => state.organizations);
  
  const [formData, setFormData] = useState({
    invoice_number: '',
    sme_id: '',
    buyer_id: '',
    amount: '',
    currency: 'INR',
    issue_date: new Date(),
    due_date: new Date(new Date().setDate(new Date().getDate() + 30)), // Default to 30 days from now
    payment_terms: 'Net 30',
    description: ''
  });
  
  const [formErrors, setFormErrors] = useState({});
  
  useEffect(() => {
    dispatch(fetchOrganizations());
  }, [dispatch]);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error for this field if it exists
    if (formErrors[name]) {
      setFormErrors({
        ...formErrors,
        [name]: ''
      });
    }
  };
  
  const handleDateChange = (name, date) => {
    setFormData({
      ...formData,
      [name]: date
    });
    
    // Clear error for this field if it exists
    if (formErrors[name]) {
      setFormErrors({
        ...formErrors,
        [name]: ''
      });
    }
  };
  
  const validateForm = () => {
    const errors = {};
    
    if (!formData.invoice_number) {
      errors.invoice_number = 'Invoice number is required';
    }
    
    if (!formData.sme_id) {
      errors.sme_id = 'SME is required';
    }
    
    if (!formData.buyer_id) {
      errors.buyer_id = 'Buyer is required';
    }
    
    if (!formData.amount) {
      errors.amount = 'Amount is required';
    } else if (isNaN(formData.amount) || parseFloat(formData.amount) <= 0) {
      errors.amount = 'Amount must be a positive number';
    }
    
    if (!formData.currency) {
      errors.currency = 'Currency is required';
    }
    
    if (!formData.issue_date) {
      errors.issue_date = 'Issue date is required';
    }
    
    if (!formData.due_date) {
      errors.due_date = 'Due date is required';
    } else if (formData.issue_date && formData.due_date < formData.issue_date) {
      errors.due_date = 'Due date cannot be before issue date';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      const resultAction = await dispatch(createInvoice({
        ...formData,
        amount: parseFloat(formData.amount),
        issue_date: formData.issue_date.toISOString().split('T')[0],
        due_date: formData.due_date.toISOString().split('T')[0]
      }));
      
      if (createInvoice.fulfilled.match(resultAction)) {
        navigate('/invoices');
      }
    }
  };
  
  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/invoices')}
          sx={{ mr: 2 }}
        >
          Back
        </Button>
        <Typography variant="h4" component="h1">
          Create New Invoice
        </Typography>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Paper sx={{ p: 3 }}>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Invoice Number"
                name="invoice_number"
                value={formData.invoice_number}
                onChange={handleChange}
                error={!!formErrors.invoice_number}
                helperText={formErrors.invoice_number}
                disabled={loading}
                required
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth error={!!formErrors.currency} disabled={loading}>
                <InputLabel id="currency-label">Currency</InputLabel>
                <Select
                  labelId="currency-label"
                  name="currency"
                  value={formData.currency}
                  onChange={handleChange}
                  label="Currency"
                  required
                >
                  <MenuItem value="INR">Indian Rupee (INR)</MenuItem>
                  <MenuItem value="USD">US Dollar (USD)</MenuItem>
                  <MenuItem value="EUR">Euro (EUR)</MenuItem>
                  <MenuItem value="GBP">British Pound (GBP)</MenuItem>
                </Select>
                {formErrors.currency && <FormHelperText>{formErrors.currency}</FormHelperText>}
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth error={!!formErrors.sme_id} disabled={loading || organizationsLoading}>
                <InputLabel id="sme-label">SME</InputLabel>
                <Select
                  labelId="sme-label"
                  name="sme_id"
                  value={formData.sme_id}
                  onChange={handleChange}
                  label="SME"
                  required
                >
                  {organizationsLoading ? (
                    <MenuItem disabled>Loading...</MenuItem>
                  ) : smes.length === 0 ? (
                    <MenuItem disabled>No SMEs found</MenuItem>
                  ) : (
                    smes.map((sme) => (
                      <MenuItem key={sme.id} value={sme.id}>
                        {sme.name}
                      </MenuItem>
                    ))
                  )}
                </Select>
                {formErrors.sme_id && <FormHelperText>{formErrors.sme_id}</FormHelperText>}
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth error={!!formErrors.buyer_id} disabled={loading || organizationsLoading}>
                <InputLabel id="buyer-label">Buyer</InputLabel>
                <Select
                  labelId="buyer-label"
                  name="buyer_id"
                  value={formData.buyer_id}
                  onChange={handleChange}
                  label="Buyer"
                  required
                >
                  {organizationsLoading ? (
                    <MenuItem disabled>Loading...</MenuItem>
                  ) : buyers.length === 0 ? (
                    <MenuItem disabled>No buyers found</MenuItem>
                  ) : (
                    buyers.map((buyer) => (
                      <MenuItem key={buyer.id} value={buyer.id}>
                        {buyer.name}
                      </MenuItem>
                    ))
                  )}
                </Select>
                {formErrors.buyer_id && <FormHelperText>{formErrors.buyer_id}</FormHelperText>}
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Amount"
                name="amount"
                type="number"
                value={formData.amount}
                onChange={handleChange}
                error={!!formErrors.amount}
                helperText={formErrors.amount}
                disabled={loading}
                InputProps={{
                  startAdornment: formData.currency === 'INR' ? '₹' : 
                                 formData.currency === 'USD' ? '$' : 
                                 formData.currency === 'EUR' ? '€' : 
                                 formData.currency === 'GBP' ? '£' : '',
                }}
                required
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth error={!!formErrors.payment_terms} disabled={loading}>
                <InputLabel id="payment-terms-label">Payment Terms</InputLabel>
                <Select
                  labelId="payment-terms-label"
                  name="payment_terms"
                  value={formData.payment_terms}
                  onChange={handleChange}
                  label="Payment Terms"
                  required
                >
                  <MenuItem value="Net 15">Net 15</MenuItem>
                  <MenuItem value="Net 30">Net 30</MenuItem>
                  <MenuItem value="Net 45">Net 45</MenuItem>
                  <MenuItem value="Net 60">Net 60</MenuItem>
                  <MenuItem value="Due on Receipt">Due on Receipt</MenuItem>
                </Select>
                {formErrors.payment_terms && <FormHelperText>{formErrors.payment_terms}</FormHelperText>}
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Issue Date"
                  value={formData.issue_date}
                  onChange={(date) => handleDateChange('issue_date', date)}
                  slotProps={{
                    textField: {
                      fullWidth: true,
                      error: !!formErrors.issue_date,
                      helperText: formErrors.issue_date,
                      disabled: loading,
                      required: true
                    }
                  }}
                />
              </LocalizationProvider>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Due Date"
                  value={formData.due_date}
                  onChange={(date) => handleDateChange('due_date', date)}
                  slotProps={{
                    textField: {
                      fullWidth: true,
                      error: !!formErrors.due_date,
                      helperText: formErrors.due_date,
                      disabled: loading,
                      required: true
                    }
                  }}
                />
              </LocalizationProvider>
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                multiline
                rows={4}
                disabled={loading}
              />
            </Grid>
            
            <Grid item xs={12}>
              <Divider sx={{ my: 2 }} />
              <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
                <Button
                  variant="outlined"
                  onClick={() => navigate('/invoices')}
                  disabled={loading}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="contained"
                  disabled={loading || organizationsLoading}
                >
                  {loading ? <CircularProgress size={24} /> : 'Create Invoice'}
                </Button>
              </Box>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Box>
  );
};

export default CreateInvoicePage;

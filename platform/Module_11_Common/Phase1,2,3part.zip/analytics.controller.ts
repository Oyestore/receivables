import { Controller, Get, Post, Body, Query, Param, Logger } from '@nestjs/common';
import { AnalyticsService } from '../services/analytics.service';
import { ApiTags, ApiOperation, ApiResponse, ApiQuery } from '@nestjs/swagger';

/**
 * Controller for analytics dashboard API endpoints
 */
@ApiTags('analytics')
@Controller('analytics')
export class AnalyticsController {
  private readonly logger = new Logger(AnalyticsController.name);

  constructor(private readonly analyticsService: AnalyticsService) {}

  /**
   * Get complete dashboard data
   */
  @Get('dashboard')
  @ApiOperation({ summary: 'Get complete dashboard data' })
  @ApiResponse({ status: 200, description: 'Returns all dashboard metrics and data' })
  async getDashboardData() {
    this.logger.log('Request for complete dashboard data');
    return this.analyticsService.getDashboardData();
  }

  /**
   * Get distribution metrics
   */
  @Get('distribution')
  @ApiOperation({ summary: 'Get distribution metrics' })
  @ApiResponse({ status: 200, description: 'Returns distribution metrics across all channels' })
  @ApiQuery({ name: 'refresh', required: false, type: Boolean, description: 'Force data refresh' })
  async getDistributionMetrics(@Query('refresh') refresh: boolean = false) {
    this.logger.log(`Request for distribution metrics, refresh=${refresh}`);
    return this.analyticsService.getDistributionMetrics(refresh);
  }

  /**
   * Get follow-up metrics
   */
  @Get('follow-up')
  @ApiOperation({ summary: 'Get follow-up metrics' })
  @ApiResponse({ status: 200, description: 'Returns follow-up effectiveness metrics' })
  @ApiQuery({ name: 'refresh', required: false, type: Boolean, description: 'Force data refresh' })
  async getFollowUpMetrics(@Query('refresh') refresh: boolean = false) {
    this.logger.log(`Request for follow-up metrics, refresh=${refresh}`);
    return this.analyticsService.getFollowUpMetrics(refresh);
  }

  /**
   * Get system performance metrics
   */
  @Get('system')
  @ApiOperation({ summary: 'Get system performance metrics' })
  @ApiResponse({ status: 200, description: 'Returns system performance metrics' })
  @ApiQuery({ name: 'refresh', required: false, type: Boolean, description: 'Force data refresh' })
  async getSystemPerformanceMetrics(@Query('refresh') refresh: boolean = false) {
    this.logger.log(`Request for system performance metrics, refresh=${refresh}`);
    return this.analyticsService.getSystemPerformanceMetrics(refresh);
  }

  /**
   * Get template performance metrics
   */
  @Get('templates')
  @ApiOperation({ summary: 'Get template performance metrics' })
  @ApiResponse({ status: 200, description: 'Returns template performance comparison metrics' })
  @ApiQuery({ name: 'refresh', required: false, type: Boolean, description: 'Force data refresh' })
  async getTemplatePerformanceMetrics(@Query('refresh') refresh: boolean = false) {
    this.logger.log(`Request for template performance metrics, refresh=${refresh}`);
    return this.analyticsService.getTemplatePerformanceMetrics(refresh);
  }

  /**
   * Get queue health metrics
   */
  @Get('queue-health')
  @ApiOperation({ summary: 'Get queue health metrics' })
  @ApiResponse({ status: 200, description: 'Returns real-time queue health metrics' })
  getQueueHealthMetrics() {
    this.logger.log('Request for queue health metrics');
    return this.analyticsService.getQueueHealthMetrics();
  }

  /**
   * Generate analytics report
   */
  @Post('reports')
  @ApiOperation({ summary: 'Generate analytics report' })
  @ApiResponse({ status: 200, description: 'Returns generated report data or file path' })
  async generateReport(
    @Body() reportConfig: {
      reportType: string;
      dateRange: any;
      format: string;
    },
  ) {
    this.logger.log(`Request to generate ${reportConfig.reportType} report in ${reportConfig.format} format`);
    return this.analyticsService.generateReport(
      reportConfig.reportType,
      reportConfig.dateRange,
      reportConfig.format,
    );
  }

  /**
   * Check for anomalies
   */
  @Get('anomalies')
  @ApiOperation({ summary: 'Check for anomalies in system performance and metrics' })
  @ApiResponse({ status: 200, description: 'Returns detected anomalies if any' })
  async checkForAnomalies() {
    this.logger.log('Request to check for anomalies');
    return this.analyticsService.checkForAnomalies();
  }
}

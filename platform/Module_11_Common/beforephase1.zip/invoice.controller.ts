import { Controller, Post, Body, Get, Param, Put, Delete, Query, UsePipes, ValidationPipe, ParseUUIDPipe, UploadedFile, UseInterceptors, Logger } from "@nestjs/common";
import { FileInterceptor } from "@nestjs/platform-express";
import { InvoiceService } from "../services/invoice.service";
import { CreateInvoiceDto, UpdateInvoiceDto } from "../dto/invoice.dto";
import { Invoice } from "../entities/invoice.entity";
import { OcrIntegrationService } from "../../ocr-integration/services/ocr-integration.service"; // Import OCR Service
import { Express } from "express"; // For Multer file type

@Controller("api/v1/invoices")
export class InvoiceController {
  private readonly logger = new Logger(InvoiceController.name);

  constructor(
    private readonly invoiceService: InvoiceService,
    private readonly ocrIntegrationService: OcrIntegrationService, // Inject OCR Service
  ) {}

  @Post()
  @UsePipes(new ValidationPipe({ transform: true, whitelist: true, forbidNonWhitelisted: true }))
  async create(@Body() createInvoiceDto: CreateInvoiceDto): Promise<Invoice> {
    return this.invoiceService.create(createInvoiceDto);
  }

  @Get()
  async findAll(@Query("tenant_id", ParseUUIDPipe) tenant_id: string): Promise<Invoice[]> {
    return this.invoiceService.findAll(tenant_id);
  }

  @Get(":id")
  async findOne(
    @Param("id", ParseUUIDPipe) id: string,
    @Query("tenant_id", ParseUUIDPipe) tenant_id: string
  ): Promise<Invoice> {
    return this.invoiceService.findOne(id, tenant_id);
  }

  @Put(":id")
  @UsePipes(new ValidationPipe({ transform: true, whitelist: true, forbidNonWhitelisted: true }))
  async update(
    @Param("id", ParseUUIDPipe) id: string,
    @Body() updateInvoiceDto: UpdateInvoiceDto,
    @Query("tenant_id", ParseUUIDPipe) tenant_id: string
  ): Promise<Invoice> {
    return this.invoiceService.update(id, updateInvoiceDto, tenant_id);
  }

  @Delete(":id")
  async remove(
    @Param("id", ParseUUIDPipe) id: string,
    @Query("tenant_id", ParseUUIDPipe) tenant_id: string
  ): Promise<void> {
    return this.invoiceService.remove(id, tenant_id);
  }

  @Post("upload-for-ai-assist")
  @UseInterceptors(FileInterceptor("file", {
    // Add file validation if needed (e.g., file size, mimetypes)
    // limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit example
    // fileFilter: (req, file, cb) => {
    //   if (!file.originalname.match(/\.(jpg|jpeg|png|gif|pdf)$/)) {
    //     return cb(new Error("Only image and PDF files are allowed!"), false);
    //   }
    //   cb(null, true);
    // },
  }))
  async uploadForAiAssist(@UploadedFile() file: Express.Multer.File, @Query("tenant_id", ParseUUIDPipe) tenant_id: string) {
    this.logger.log(`Received file for AI assist: ${file.originalname}, tenant: ${tenant_id}`);
    if (!file) {
      throw new Error("No file uploaded."); // Or use BadRequestException
    }
    try {
      const extractedText = await this.ocrIntegrationService.extractTextFromImage(file);
      // TODO: Further process the extractedText to structure it or create a draft invoice.
      // For now, just returning the raw text.
      return { 
        message: "File processed successfully for AI assist.", 
        filename: file.originalname,
        extracted_text: extractedText,
        tenant_id: tenant_id // Echoing tenant_id for context
      };
    } catch (error) {
      this.logger.error(`Error in AI assist upload for ${file.originalname}: ${error.message}`, error.stack);
      throw error; // Re-throw the error to be handled by NestJS default error handler or a custom filter
    }
  }

  // TODO: Implement other endpoints from the design document:
  // POST /api/v1/invoices/{invoice_id}/duplicate
  // POST /api/v1/invoices/import-csv
}


import { Injectable, Logger } from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { DistributionConsumerService } from '../services/distribution-consumer.service';
import { WhatsappDistributorService } from '../../channel-integration/providers/whatsapp-distributor.service';

/**
 * Consumer for WhatsApp distribution messages from RabbitMQ
 */
@Injectable()
export class WhatsAppDistributionConsumer {
  private readonly logger = new Logger(WhatsAppDistributionConsumer.name);
  private readonly queueName = 'whatsapp_distribution';

  constructor(
    private readonly distributionConsumerService: DistributionConsumerService,
    private readonly whatsappDistributorService: WhatsappDistributorService,
  ) {}

  /**
   * Process WhatsApp distribution messages from the queue
   * @param data Distribution data from the queue
   */
  @MessagePattern('whatsapp_distribution')
  async processWhatsAppDistribution(@Payload() data: any) {
    const startTime = Date.now();
    this.logger.log(`Processing WhatsApp distribution: ${JSON.stringify(data)}`);
    
    try {
      // Process the WhatsApp distribution
      if (data.isTest) {
        this.logger.log('Test message received, simulating processing');
        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 500));
      } else {
        // Actual WhatsApp distribution logic
        await this.whatsappDistributorService.sendWhatsAppMessage(data);
      }
      
      // Record successful processing
      const processingTime = Date.now() - startTime;
      this.distributionConsumerService.recordMessageProcessed(this.queueName, processingTime);
      
      return { success: true, processingTime };
    } catch (error) {
      // Record processing error
      this.distributionConsumerService.recordProcessingError(this.queueName, error);
      
      // Return error response
      return { 
        success: false, 
        error: error.message,
        processingTime: Date.now() - startTime
      };
    }
  }

  /**
   * Handle ping messages to check queue availability
   * @param data Ping data
   */
  @MessagePattern('whatsapp_distribution.ping')
  handlePing(@Payload() data: any) {
    this.logger.debug(`Received ping: ${JSON.stringify(data)}`);
    return { 
      pong: true, 
      timestamp: Date.now(),
      originalTimestamp: data.timestamp
    };
  }
}

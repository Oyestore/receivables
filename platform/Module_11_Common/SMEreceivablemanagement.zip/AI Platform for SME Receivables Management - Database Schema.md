# AI Platform for SME Receivables Management - Database Schema

## 1. Database Technology Selection

The platform will use a combination of database technologies to address different data storage and access patterns:

### 1.1 Primary Operational Database
- **Technology**: PostgreSQL 15+
- **Rationale**: 
  - ACID compliance for transactional integrity
  - Robust support for JSON/JSONB for flexible schema elements
  - Advanced indexing capabilities
  - Mature multi-tenancy support
  - Strong open-source community
  - Excellent performance for relational data

### 1.2 Analytics Database
- **Technology**: ClickHouse
- **Rationale**:
  - Column-oriented storage optimized for analytics
  - High-performance for aggregation queries
  - Efficient storage with compression
  - Good integration with visualization tools
  - Open-source with active development

### 1.3 Document Storage
- **Technology**: MinIO (S3-compatible)
- **Rationale**:
  - Optimized for document storage
  - S3-compatible API for broad ecosystem support
  - Scalable and self-hostable
  - Versioning capabilities
  - Object lifecycle management

### 1.4 Caching Layer
- **Technology**: Redis
- **Rationale**:
  - In-memory performance
  - Support for complex data structures
  - Pub/sub capabilities for real-time features
  - Distributed caching support
  - Persistence options for reliability

### 1.5 Search Engine
- **Technology**: Elasticsearch
- **Rationale**:
  - Advanced full-text search capabilities
  - Faceted search support
  - Analytics capabilities
  - Scalable architecture
  - Rich query language

## 2. Multi-Tenancy Approach

The database schema will implement a schema-based multi-tenancy approach:

- Each tenant will have a dedicated PostgreSQL schema
- Tenant identifier will be part of the connection context
- Shared tables will include tenant_id column for additional isolation
- Cross-tenant operations will be strictly controlled through service layer
- Tenant metadata will be stored in a global schema

## 3. PostgreSQL Schema Design

### 3.1 Global Schema (public)

#### 3.1.1 Tenants Table
```sql
CREATE TABLE tenants (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    domain VARCHAR(255) UNIQUE,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    plan VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    settings JSONB,
    db_schema VARCHAR(63) NOT NULL UNIQUE
);
```

#### 3.1.2 Tenant Users Table
```sql
CREATE TABLE tenant_users (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    email VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, email)
);
```

#### 3.1.3 System Settings Table
```sql
CREATE TABLE system_settings (
    key VARCHAR(255) PRIMARY KEY,
    value JSONB NOT NULL,
    description TEXT,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
```

#### 3.1.4 Migration History Table
```sql
CREATE TABLE migration_history (
    id SERIAL PRIMARY KEY,
    version VARCHAR(255) NOT NULL,
    applied_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    description TEXT
);
```

### 3.2 Tenant Schema (per tenant)

#### 3.2.1 Users Table
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255),
    role VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    last_login_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    preferences JSONB,
    mfa_enabled BOOLEAN DEFAULT FALSE,
    reset_token VARCHAR(255),
    reset_token_expires_at TIMESTAMP WITH TIME ZONE
);
```

#### 3.2.2 Roles Table
```sql
CREATE TABLE roles (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    permissions JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
```

#### 3.2.3 User Roles Table
```sql
CREATE TABLE user_roles (
    user_id UUID NOT NULL REFERENCES users(id),
    role_id UUID NOT NULL REFERENCES roles(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, role_id)
);
```

#### 3.2.4 Companies Table
```sql
CREATE TABLE companies (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    legal_name VARCHAR(255),
    tax_identifier VARCHAR(255),
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    city VARCHAR(255),
    state VARCHAR(255),
    postal_code VARCHAR(50),
    country VARCHAR(100),
    phone VARCHAR(50),
    email VARCHAR(255),
    website VARCHAR(255),
    logo_url VARCHAR(1024),
    industry VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    settings JSONB,
    metadata JSONB
);
```

#### 3.2.5 Buyers Table
```sql
CREATE TABLE buyers (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    legal_name VARCHAR(255),
    tax_identifier VARCHAR(255),
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    city VARCHAR(255),
    state VARCHAR(255),
    postal_code VARCHAR(50),
    country VARCHAR(100),
    contact_person VARCHAR(255),
    phone VARCHAR(50),
    email VARCHAR(255),
    website VARCHAR(255),
    industry VARCHAR(255),
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    custom_fields JSONB,
    metadata JSONB
);
```

#### 3.2.6 Buyer Ratings Table
```sql
CREATE TABLE buyer_ratings (
    id UUID PRIMARY KEY,
    buyer_id UUID NOT NULL REFERENCES buyers(id),
    overall_rating DECIMAL(3,2) NOT NULL,
    payment_behavior_rating DECIMAL(3,2) NOT NULL,
    financial_stability_rating DECIMAL(3,2) NOT NULL,
    industry_standing_rating DECIMAL(3,2) NOT NULL,
    rating_factors JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    valid_from TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    valid_to TIMESTAMP WITH TIME ZONE,
    created_by UUID REFERENCES users(id),
    rating_source VARCHAR(50) NOT NULL DEFAULT 'system'
);
```

#### 3.2.7 Invoices Table
```sql
CREATE TABLE invoices (
    id UUID PRIMARY KEY,
    invoice_number VARCHAR(255) NOT NULL UNIQUE,
    irn VARCHAR(255),
    buyer_id UUID NOT NULL REFERENCES buyers(id),
    amount DECIMAL(19,4) NOT NULL,
    tax_amount DECIMAL(19,4) NOT NULL DEFAULT 0,
    total_amount DECIMAL(19,4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'INR',
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'draft',
    payment_status VARCHAR(50) NOT NULL DEFAULT 'unpaid',
    payment_terms VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    metadata JSONB,
    custom_fields JSONB
);

CREATE INDEX idx_invoices_buyer_id ON invoices(buyer_id);
CREATE INDEX idx_invoices_issue_date ON invoices(issue_date);
CREATE INDEX idx_invoices_due_date ON invoices(due_date);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_invoices_payment_status ON invoices(payment_status);
```

#### 3.2.8 Invoice Line Items Table
```sql
CREATE TABLE invoice_line_items (
    id UUID PRIMARY KEY,
    invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    quantity DECIMAL(19,4) NOT NULL,
    unit_price DECIMAL(19,4) NOT NULL,
    tax_rate DECIMAL(5,2) NOT NULL DEFAULT 0,
    tax_amount DECIMAL(19,4) NOT NULL DEFAULT 0,
    total_amount DECIMAL(19,4) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    metadata JSONB
);

CREATE INDEX idx_line_items_invoice_id ON invoice_line_items(invoice_id);
```

#### 3.2.9 Payments Table
```sql
CREATE TABLE payments (
    id UUID PRIMARY KEY,
    invoice_id UUID NOT NULL REFERENCES invoices(id),
    amount DECIMAL(19,4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'INR',
    payment_date DATE NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    reference_number VARCHAR(255),
    status VARCHAR(50) NOT NULL DEFAULT 'completed',
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    metadata JSONB
);

CREATE INDEX idx_payments_invoice_id ON payments(invoice_id);
CREATE INDEX idx_payments_payment_date ON payments(payment_date);
CREATE INDEX idx_payments_status ON payments(status);
```

#### 3.2.10 Documents Table
```sql
CREATE TABLE documents (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    file_path VARCHAR(1024) NOT NULL,
    file_type VARCHAR(255) NOT NULL,
    file_size BIGINT NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    metadata JSONB
);

CREATE INDEX idx_documents_entity ON documents(entity_type, entity_id);
```

#### 3.2.11 Communications Table
```sql
CREATE TABLE communications (
    id UUID PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    recipient_type VARCHAR(50) NOT NULL,
    recipient_id UUID NOT NULL,
    subject VARCHAR(255),
    content TEXT,
    channel VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    scheduled_at TIMESTAMP WITH TIME ZONE,
    sent_at TIMESTAMP WITH TIME ZONE,
    delivered_at TIMESTAMP WITH TIME ZONE,
    opened_at TIMESTAMP WITH TIME ZONE,
    clicked_at TIMESTAMP WITH TIME ZONE,
    failed_reason TEXT,
    template_id UUID,
    template_data JSONB,
    entity_type VARCHAR(50),
    entity_id UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    metadata JSONB
);

CREATE INDEX idx_communications_recipient ON communications(recipient_type, recipient_id);
CREATE INDEX idx_communications_entity ON communications(entity_type, entity_id);
CREATE INDEX idx_communications_status ON communications(status);
CREATE INDEX idx_communications_scheduled_at ON communications(scheduled_at);
```

#### 3.2.12 Communication Templates Table
```sql
CREATE TABLE communication_templates (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    purpose VARCHAR(50) NOT NULL,
    subject VARCHAR(255),
    content TEXT NOT NULL,
    variables JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    is_default BOOLEAN DEFAULT FALSE,
    status VARCHAR(50) NOT NULL DEFAULT 'active'
);

CREATE INDEX idx_comm_templates_type_purpose ON communication_templates(type, purpose);
```

#### 3.2.13 Milestones Table
```sql
CREATE TABLE milestones (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID NOT NULL,
    due_date DATE,
    completion_date DATE,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    completion_criteria JSONB,
    dependencies JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    metadata JSONB
);

CREATE INDEX idx_milestones_entity ON milestones(entity_type, entity_id);
CREATE INDEX idx_milestones_status ON milestones(status);
CREATE INDEX idx_milestones_due_date ON milestones(due_date);
```

#### 3.2.14 Payment Terms Table
```sql
CREATE TABLE payment_terms (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    days_to_payment INTEGER NOT NULL,
    early_payment_discount_percentage DECIMAL(5,2),
    early_payment_discount_days INTEGER,
    late_payment_penalty_percentage DECIMAL(5,2),
    late_payment_penalty_grace_period INTEGER,
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    status VARCHAR(50) NOT NULL DEFAULT 'active'
);
```

#### 3.2.15 Financing Options Table
```sql
CREATE TABLE financing_options (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    provider VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    interest_rate DECIMAL(5,2) NOT NULL,
    processing_fee DECIMAL(5,2) NOT NULL,
    term_days INTEGER NOT NULL,
    min_amount DECIMAL(19,4) NOT NULL,
    max_amount DECIMAL(19,4) NOT NULL,
    requirements JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    status VARCHAR(50) NOT NULL DEFAULT 'active'
);
```

#### 3.2.16 Financing Applications Table
```sql
CREATE TABLE financing_applications (
    id UUID PRIMARY KEY,
    option_id UUID REFERENCES financing_options(id),
    amount DECIMAL(19,4) NOT NULL,
    term_days INTEGER NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    application_data JSONB NOT NULL,
    approval_data JSONB,
    rejection_reason TEXT,
    disbursement_date DATE,
    repayment_schedule JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    metadata JSONB
);

CREATE INDEX idx_financing_applications_status ON financing_applications(status);
```

#### 3.2.17 Invoice Financing Table
```sql
CREATE TABLE invoice_financing (
    id UUID PRIMARY KEY,
    invoice_id UUID NOT NULL REFERENCES invoices(id),
    financing_application_id UUID NOT NULL REFERENCES financing_applications(id),
    amount DECIMAL(19,4) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_invoice_financing_invoice_id ON invoice_financing(invoice_id);
CREATE INDEX idx_invoice_financing_application_id ON invoice_financing(financing_application_id);
```

#### 3.2.18 Integration Connections Table
```sql
CREATE TABLE integration_connections (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    provider VARCHAR(255) NOT NULL,
    credentials JSONB,
    settings JSONB,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    last_sync_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    metadata JSONB
);

CREATE INDEX idx_integration_connections_type ON integration_connections(type);
CREATE INDEX idx_integration_connections_provider ON integration_connections(provider);
```

#### 3.2.19 Integration Sync Logs Table
```sql
CREATE TABLE integration_sync_logs (
    id UUID PRIMARY KEY,
    connection_id UUID NOT NULL REFERENCES integration_connections(id),
    status VARCHAR(50) NOT NULL,
    started_at TIMESTAMP WITH TIME ZONE NOT NULL,
    completed_at TIMESTAMP WITH TIME ZONE,
    entities_processed INTEGER NOT NULL DEFAULT 0,
    entities_created INTEGER NOT NULL DEFAULT 0,
    entities_updated INTEGER NOT NULL DEFAULT 0,
    entities_failed INTEGER NOT NULL DEFAULT 0,
    error_details JSONB,
    metadata JSONB
);

CREATE INDEX idx_integration_sync_logs_connection_id ON integration_sync_logs(connection_id);
CREATE INDEX idx_integration_sync_logs_started_at ON integration_sync_logs(started_at);
```

#### 3.2.20 Webhooks Table
```sql
CREATE TABLE webhooks (
    id UUID PRIMARY KEY,
    url VARCHAR(1024) NOT NULL,
    events JSONB NOT NULL,
    description TEXT,
    secret VARCHAR(255),
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);
```

#### 3.2.21 Webhook Deliveries Table
```sql
CREATE TABLE webhook_deliveries (
    id UUID PRIMARY KEY,
    webhook_id UUID NOT NULL REFERENCES webhooks(id),
    event_type VARCHAR(255) NOT NULL,
    payload JSONB NOT NULL,
    response_code INTEGER,
    response_body TEXT,
    status VARCHAR(50) NOT NULL,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_webhook_deliveries_webhook_id ON webhook_deliveries(webhook_id);
CREATE INDEX idx_webhook_deliveries_status ON webhook_deliveries(status);
CREATE INDEX idx_webhook_deliveries_next_retry_at ON webhook_deliveries(next_retry_at);
```

#### 3.2.22 Agent Tasks Table
```sql
CREATE TABLE agent_tasks (
    id UUID PRIMARY KEY,
    agent_type VARCHAR(50) NOT NULL,
    action VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    priority INTEGER NOT NULL DEFAULT 5,
    parameters JSONB,
    result JSONB,
    error_details JSONB,
    progress INTEGER NOT NULL DEFAULT 0,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    entity_type VARCHAR(50),
    entity_id UUID
);

CREATE INDEX idx_agent_tasks_agent_type ON agent_tasks(agent_type);
CREATE INDEX idx_agent_tasks_status ON agent_tasks(status);
CREATE INDEX idx_agent_tasks_entity ON agent_tasks(entity_type, entity_id);
```

#### 3.2.23 Audit Logs Table
```sql
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    action VARCHAR(255) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);
```

#### 3.2.24 Notifications Table
```sql
CREATE TABLE notifications (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id),
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL,
    read BOOLEAN NOT NULL DEFAULT FALSE,
    read_at TIMESTAMP WITH TIME ZONE,
    entity_type VARCHAR(50),
    entity_id UUID,
    action_url VARCHAR(1024),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_read ON notifications(read);
CREATE INDEX idx_notifications_entity ON notifications(entity_type, entity_id);
```

#### 3.2.25 Settings Table
```sql
CREATE TABLE settings (
    key VARCHAR(255) PRIMARY KEY,
    value JSONB NOT NULL,
    description TEXT,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_by UUID REFERENCES users(id)
);
```

## 4. ClickHouse Schema Design

### 4.1 Invoice Analytics Table
```sql
CREATE TABLE invoice_analytics (
    tenant_id String,
    invoice_id UUID,
    invoice_number String,
    buyer_id UUID,
    buyer_name String,
    amount Decimal(19,4),
    tax_amount Decimal(19,4),
    total_amount Decimal(19,4),
    currency String,
    issue_date Date,
    due_date Date,
    payment_date Nullable(Date),
    status String,
    payment_status String,
    days_to_payment Nullable(Int32),
    days_overdue Nullable(Int32),
    industry String,
    region String,
    created_at DateTime,
    updated_at DateTime
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(issue_date)
ORDER BY (tenant_id, issue_date, buyer_id);
```

### 4.2 Payment Analytics Table
```sql
CREATE TABLE payment_analytics (
    tenant_id String,
    payment_id UUID,
    invoice_id UUID,
    invoice_number String,
    buyer_id UUID,
    buyer_name String,
    amount Decimal(19,4),
    currency String,
    payment_date Date,
    payment_method String,
    status String,
    days_from_issue Nullable(Int32),
    days_from_due Nullable(Int32),
    early_payment Boolean,
    late_payment Boolean,
    created_at DateTime
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(payment_date)
ORDER BY (tenant_id, payment_date, buyer_id);
```

### 4.3 Buyer Analytics Table
```sql
CREATE TABLE buyer_analytics (
    tenant_id String,
    buyer_id UUID,
    buyer_name String,
    date Date,
    total_invoices Int32,
    total_amount Decimal(19,4),
    paid_invoices Int32,
    paid_amount Decimal(19,4),
    overdue_invoices Int32,
    overdue_amount Decimal(19,4),
    average_days_to_payment Nullable(Float64),
    on_time_payment_percentage Nullable(Float64),
    early_payment_percentage Nullable(Float64),
    overall_rating Nullable(Float64),
    payment_behavior_rating Nullable(Float64),
    financial_stability_rating Nullable(Float64),
    industry_standing_rating Nullable(Float64)
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(date)
ORDER BY (tenant_id, date, buyer_id);
```

### 4.4 Communication Analytics Table
```sql
CREATE TABLE communication_analytics (
    tenant_id String,
    communication_id UUID,
    date Date,
    type String,
    channel String,
    recipient_type String,
    recipient_id UUID,
    entity_type Nullable(String),
    entity_id Nullable(UUID),
    status String,
    delivered Boolean,
    opened Boolean,
    clicked Boolean,
    response_received Boolean,
    time_to_open Nullable(Int32),
    time_to_click Nullable(Int32),
    time_to_response Nullable(Int32)
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(date)
ORDER BY (tenant_id, date, channel, recipient_type);
```

### 4.5 Agent Performance Table
```sql
CREATE TABLE agent_performance (
    tenant_id String,
    date Date,
    agent_type String,
    action String,
    total_tasks Int32,
    successful_tasks Int32,
    failed_tasks Int32,
    average_duration_ms Int64,
    p95_duration_ms Int64,
    p99_duration_ms Int64
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(date)
ORDER BY (tenant_id, date, agent_type, action);
```

## 5. Redis Data Structures

### 5.1 Session Storage
- Key pattern: `session:{session_id}`
- Value: JSON object with session data
- TTL: Configurable (default: 24 hours)

### 5.2 Rate Limiting
- Key pattern: `ratelimit:{ip}:{endpoint}`
- Value: Counter
- TTL: Varies by endpoint

### 5.3 Cache Keys
- User data: `cache:user:{user_id}`
- Buyer data: `cache:buyer:{buyer_id}`
- Invoice data: `cache:invoice:{invoice_id}`
- Dashboard metrics: `cache:dashboard:{tenant_id}:{period}`
- API responses: `cache:api:{endpoint}:{query_hash}`

### 5.4 Pub/Sub Channels
- Notifications: `notifications:{tenant_id}`
- Agent tasks: `agent_tasks:{tenant_id}:{agent_type}`
- System events: `system_events:{tenant_id}`

### 5.5 Task Queues
- Agent tasks: `queue:agent_tasks:{priority}`
- Webhook deliveries: `queue:webhook_deliveries`
- Email notifications: `queue:email_notifications`
- SMS notifications: `queue:sms_notifications`

## 6. Elasticsearch Indices

### 6.1 Invoices Index
```json
{
  "mappings": {
    "properties": {
      "tenant_id": { "type": "keyword" },
      "id": { "type": "keyword" },
      "invoice_number": { "type": "keyword" },
      "buyer_id": { "type": "keyword" },
      "buyer_name": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "amount": { "type": "float" },
      "total_amount": { "type": "float" },
      "currency": { "type": "keyword" },
      "issue_date": { "type": "date" },
      "due_date": { "type": "date" },
      "status": { "type": "keyword" },
      "payment_status": { "type": "keyword" },
      "payment_terms": { "type": "text" },
      "notes": { "type": "text" },
      "line_items": {
        "type": "nested",
        "properties": {
          "description": { "type": "text" },
          "quantity": { "type": "float" },
          "unit_price": { "type": "float" },
          "total_amount": { "type": "float" }
        }
      },
      "created_at": { "type": "date" },
      "updated_at": { "type": "date" }
    }
  }
}
```

### 6.2 Buyers Index
```json
{
  "mappings": {
    "properties": {
      "tenant_id": { "type": "keyword" },
      "id": { "type": "keyword" },
      "name": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "legal_name": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "tax_identifier": { "type": "keyword" },
      "address": { "type": "text" },
      "city": { "type": "keyword" },
      "state": { "type": "keyword" },
      "country": { "type": "keyword" },
      "contact_person": { "type": "text" },
      "email": { "type": "keyword" },
      "phone": { "type": "keyword" },
      "industry": { "type": "keyword" },
      "status": { "type": "keyword" },
      "overall_rating": { "type": "float" },
      "payment_behavior_rating": { "type": "float" },
      "financial_stability_rating": { "type": "float" },
      "industry_standing_rating": { "type": "float" },
      "created_at": { "type": "date" },
      "updated_at": { "type": "date" }
    }
  }
}
```

### 6.3 Communications Index
```json
{
  "mappings": {
    "properties": {
      "tenant_id": { "type": "keyword" },
      "id": { "type": "keyword" },
      "type": { "type": "keyword" },
      "recipient_type": { "type": "keyword" },
      "recipient_id": { "type": "keyword" },
      "subject": { "type": "text" },
      "content": { "type": "text" },
      "channel": { "type": "keyword" },
      "status": { "type": "keyword" },
      "scheduled_at": { "type": "date" },
      "sent_at": { "type": "date" },
      "entity_type": { "type": "keyword" },
      "entity_id": { "type": "keyword" },
      "created_at": { "type": "date" },
      "updated_at": { "type": "date" }
    }
  }
}
```

### 6.4 Documents Index
```json
{
  "mappings": {
    "properties": {
      "tenant_id": { "type": "keyword" },
      "id": { "type": "keyword" },
      "name": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "description": { "type": "text" },
      "file_type": { "type": "keyword" },
      "content": { "type": "text" },
      "entity_type": { "type": "keyword" },
      "entity_id": { "type": "keyword" },
      "created_at": { "type": "date" },
      "updated_at": { "type": "date" },
      "created_by": { "type": "keyword" }
    }
  }
}
```

### 6.5 Audit Logs Index
```json
{
  "mappings": {
    "properties": {
      "tenant_id": { "type": "keyword" },
      "id": { "type": "keyword" },
      "user_id": { "type": "keyword" },
      "user_name": { "type": "text", "fields": { "keyword": { "type": "keyword" } } },
      "action": { "type": "keyword" },
      "entity_type": { "type": "keyword" },
      "entity_id": { "type": "keyword" },
      "details": { "type": "text" },
      "ip_address": { "type": "ip" },
      "user_agent": { "type": "text" },
      "created_at": { "type": "date" }
    }
  }
}
```

## 7. Data Migration and Seeding

### 7.1 Migration Strategy
- Database migrations will be managed using a migration tool (e.g., Flyway or Liquibase)
- Each migration will be versioned and tracked in the migration_history table
- Migrations will be applied automatically during deployment
- Rollback scripts will be provided for each migration

### 7.2 Initial Data Seeding
- Default roles and permissions
- System settings
- Default communication templates
- Default payment terms
- Sample data for testing (optional)

### 7.3 Tenant Provisioning
- Automated tenant creation process
- Schema creation for new tenants
- Initial data seeding for new tenants
- Default user creation

## 8. Data Backup and Recovery

### 8.1 Backup Strategy
- Regular full backups of PostgreSQL databases
- Continuous WAL (Write-Ahead Log) archiving for point-in-time recovery
- Regular backups of ClickHouse data
- Object storage backups for documents
- Backup verification and testing

### 8.2 Recovery Procedures
- Database restoration from backups
- Point-in-time recovery using WAL archives
- Document restoration from object storage backups
- Tenant-specific recovery options

## 9. Data Security

### 9.1 Encryption
- Encryption at rest for all databases
- Encryption of sensitive data within the database (e.g., credentials, personal information)
- TLS encryption for all database connections

### 9.2 Access Control
- Fine-grained access control at the database level
- Row-level security policies in PostgreSQL
- Separate database users for different services
- Least privilege principle for database access

### 9.3 Audit and Compliance
- Comprehensive audit logging of database changes
- Tracking of data access patterns
- Compliance with data protection regulations
- Data retention policies implementation

## 10. Performance Optimization

### 10.1 Indexing Strategy
- Strategic indexes on frequently queried columns
- Composite indexes for common query patterns
- Partial indexes for filtered queries
- Regular index maintenance and optimization

### 10.2 Query Optimization
- Prepared statements for frequent queries
- Query analysis and optimization
- Materialized views for complex aggregations
- Connection pooling for efficient resource utilization

### 10.3 Partitioning Strategy
- Table partitioning for large tables
- Time-based partitioning for historical data
- Partition pruning for query optimization
- Automated partition management

import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import time

class TestSMEReceivablesFrontend(unittest.TestCase):
    """Test suite for SME Receivables Management Platform Frontend"""
    
    BASE_URL = "http://localhost:8080"
    
    @classmethod
    def setUpClass(cls):
        """Set up test class - initialize headless Chrome browser"""
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        
        cls.driver = webdriver.Chrome(options=chrome_options)
        cls.driver.implicitly_wait(10)
    
    @classmethod
    def tearDownClass(cls):
        """Tear down test class - close browser"""
        cls.driver.quit()
    
    def test_01_login_page_loads(self):
        """Test that the login page loads correctly"""
        self.driver.get(f"{self.BASE_URL}/login")
        
        # Wait for the page to load
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.ID, "email"))
        )
        
        # Check that login form elements are present
        email_input = self.driver.find_element(By.ID, "email")
        password_input = self.driver.find_element(By.ID, "password")
        login_button = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Sign In')]")
        
        self.assertTrue(email_input.is_displayed())
        self.assertTrue(password_input.is_displayed())
        self.assertTrue(login_button.is_displayed())
    
    def test_02_login_with_valid_credentials(self):
        """Test login with valid credentials"""
        self.driver.get(f"{self.BASE_URL}/login")
        
        # Wait for the page to load
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.ID, "email"))
        )
        
        # Fill in login form
        email_input = self.driver.find_element(By.ID, "email")
        password_input = self.driver.find_element(By.ID, "password")
        login_button = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Sign In')]")
        
        email_input.send_keys("admin@demo.com")
        password_input.send_keys("admin123")
        login_button.click()
        
        # Wait for dashboard to load after successful login
        WebDriverWait(self.driver, 10).until(
            EC.url_contains("/dashboard")
        )
        
        # Verify we're on the dashboard page
        self.assertIn("/dashboard", self.driver.current_url)
        
        # Check for dashboard elements
        dashboard_title = self.driver.find_element(By.XPATH, "//h1[contains(text(), 'Dashboard')]")
        self.assertTrue(dashboard_title.is_displayed())
    
    def test_03_navigation_menu(self):
        """Test navigation menu functionality"""
        # Login first
        self.test_02_login_with_valid_credentials()
        
        # Test navigation to Invoices page
        invoices_link = self.driver.find_element(By.XPATH, "//span[contains(text(), 'Invoices')]")
        invoices_link.click()
        
        # Wait for invoices page to load
        WebDriverWait(self.driver, 10).until(
            EC.url_contains("/invoices")
        )
        
        # Verify we're on the invoices page
        self.assertIn("/invoices", self.driver.current_url)
        invoices_title = self.driver.find_element(By.XPATH, "//h1[contains(text(), 'Invoices')]")
        self.assertTrue(invoices_title.is_displayed())
        
        # Test navigation to Organizations page
        organizations_link = self.driver.find_element(By.XPATH, "//span[contains(text(), 'Organizations')]")
        organizations_link.click()
        
        # Wait for organizations page to load
        WebDriverWait(self.driver, 10).until(
            EC.url_contains("/organizations")
        )
        
        # Verify we're on the organizations page
        self.assertIn("/organizations", self.driver.current_url)
        organizations_title = self.driver.find_element(By.XPATH, "//h1[contains(text(), 'Organizations')]")
        self.assertTrue(organizations_title.is_displayed())
        
        # Test navigation to Users page
        users_link = self.driver.find_element(By.XPATH, "//span[contains(text(), 'Users')]")
        users_link.click()
        
        # Wait for users page to load
        WebDriverWait(self.driver, 10).until(
            EC.url_contains("/users")
        )
        
        # Verify we're on the users page
        self.assertIn("/users", self.driver.current_url)
        users_title = self.driver.find_element(By.XPATH, "//h1[contains(text(), 'Users')]")
        self.assertTrue(users_title.is_displayed())
    
    def test_04_logout_functionality(self):
        """Test logout functionality"""
        # Login first
        self.test_02_login_with_valid_credentials()
        
        # Click on user menu
        user_menu_button = self.driver.find_element(By.XPATH, "//button[contains(@class, 'MuiButton-root')]")
        user_menu_button.click()
        
        # Wait for menu to appear and click logout
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//li[contains(text(), 'Logout')]"))
        )
        logout_button = self.driver.find_element(By.XPATH, "//li[contains(text(), 'Logout')]")
        logout_button.click()
        
        # Wait for redirect to login page
        WebDriverWait(self.driver, 10).until(
            EC.url_contains("/login")
        )
        
        # Verify we're back on the login page
        self.assertIn("/login", self.driver.current_url)

if __name__ == "__main__":
    unittest.main(verbosity=2)

import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import DistributionDashboard from '../DistributionDashboard';

// Mock data
const mockDistributions = [
  {
    id: 'dist-1',
    invoiceId: 'inv-1',
    recipientId: 'rec-1',
    channel: 'EMAIL',
    status: 'SENT',
    sentAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    deliveredAt: new Date(Date.now() - 23.9 * 60 * 60 * 1000).toISOString(),
    openedAt: null,
    organizationId: 'org-123',
    recipient: {
      id: 'rec-1',
      recipientName: 'John Doe',
      email: 'john.doe@example.com'
    },
    invoice: {
      id: 'inv-1',
      invoiceNumber: 'INV-2025-001',
      amount: 1250.00
    }
  },
  {
    id: 'dist-2',
    invoiceId: 'inv-2',
    recipientId: 'rec-2',
    channel: 'WHATSAPP',
    status: 'DELIVERED',
    sentAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    deliveredAt: new Date(Date.now() - 11.8 * 60 * 60 * 1000).toISOString(),
    openedAt: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString(),
    organizationId: 'org-123',
    recipient: {
      id: 'rec-2',
      recipientName: 'Jane Smith',
      email: 'jane.smith@example.com'
    },
    invoice: {
      id: 'inv-2',
      invoiceNumber: 'INV-2025-002',
      amount: 750.50
    }
  }
];

const mockRecipients = [
  {
    id: 'rec-1',
    recipientName: 'John Doe',
    email: 'john.doe@example.com'
  },
  {
    id: 'rec-2',
    recipientName: 'Jane Smith',
    email: 'jane.smith@example.com'
  }
];

const mockInvoices = [
  {
    id: 'inv-1',
    invoiceNumber: 'INV-2025-001',
    amount: 1250.00
  },
  {
    id: 'inv-2',
    invoiceNumber: 'INV-2025-002',
    amount: 750.50
  },
  {
    id: 'inv-3',
    invoiceNumber: 'INV-2025-003',
    amount: 2100.75
  }
];

// Mock API calls
jest.mock('../../api/distributionApi', () => ({
  getDistributions: jest.fn(() => Promise.resolve(mockDistributions)),
  createDistribution: jest.fn((data) => Promise.resolve({ id: 'new-dist-id', ...data })),
  sendDistribution: jest.fn((id) => Promise.resolve({ id, status: 'SENT', sentAt: new Date().toISOString() }))
}));

jest.mock('../../api/recipientApi', () => ({
  getRecipients: jest.fn(() => Promise.resolve(mockRecipients))
}));

jest.mock('../../api/invoiceApi', () => ({
  getInvoices: jest.fn(() => Promise.resolve(mockInvoices))
}));

describe('DistributionDashboard Component', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  test('renders distribution dashboard component', async () => {
    render(<DistributionDashboard organizationId="org-123" />);
    
    // Check if the component title is rendered
    expect(screen.getByText('Distribution Dashboard')).toBeInTheDocument();
    
    // Check if the "New Distribution" button is rendered
    expect(screen.getByText('New Distribution')).toBeInTheDocument();
    
    // Wait for the table to be populated with mock data
    await waitFor(() => {
      expect(screen.getByText('INV-2025-001')).toBeInTheDocument();
      expect(screen.getByText('INV-2025-002')).toBeInTheDocument();
    });
    
    // Check if stats are displayed
    await waitFor(() => {
      expect(screen.getByText('Total')).toBeInTheDocument();
      expect(screen.getByText('Pending')).toBeInTheDocument();
      expect(screen.getByText('Sent')).toBeInTheDocument();
      expect(screen.getByText('Delivered')).toBeInTheDocument();
    });
  });

  test('opens new distribution dialog when button is clicked', async () => {
    render(<DistributionDashboard organizationId="org-123" />);
    
    // Click the "New Distribution" button
    fireEvent.click(screen.getByText('New Distribution'));
    
    // Check if the dialog is opened
    await waitFor(() => {
      expect(screen.getByText('New Distribution')).toBeInTheDocument();
      expect(screen.getByLabelText('Invoice')).toBeInTheDocument();
      expect(screen.getByLabelText('Recipient')).toBeInTheDocument();
      expect(screen.getByLabelText('Channel')).toBeInTheDocument();
    });
  });

  test('creates a new distribution when form is submitted', async () => {
    render(<DistributionDashboard organizationId="org-123" />);
    
    // Click the "New Distribution" button
    fireEvent.click(screen.getByText('New Distribution'));
    
    // Wait for the dialog to open and form to be populated
    await waitFor(() => {
      expect(screen.getByText('New Distribution')).toBeInTheDocument();
    });
    
    // Select invoice, recipient, and channel
    fireEvent.mouseDown(screen.getByLabelText('Invoice'));
    fireEvent.click(screen.getByText('INV-2025-003 ($2100.75)'));
    
    fireEvent.mouseDown(screen.getByLabelText('Recipient'));
    fireEvent.click(screen.getByText('John Doe (john.doe@example.com)'));
    
    fireEvent.mouseDown(screen.getByLabelText('Channel'));
    fireEvent.click(screen.getByText('Email'));
    
    // Submit the form
    fireEvent.click(screen.getByText('Create'));
    
    // Check if success message is shown
    await waitFor(() => {
      expect(screen.getByText('Distribution created successfully')).toBeInTheDocument();
    });
  });

  test('sends a pending distribution', async () => {
    // Add a pending distribution to the mock data
    const mockDistributionsWithPending = [
      ...mockDistributions,
      {
        id: 'dist-3',
        invoiceId: 'inv-3',
        recipientId: 'rec-1',
        channel: 'SMS',
        status: 'PENDING',
        sentAt: null,
        deliveredAt: null,
        openedAt: null,
        organizationId: 'org-123',
        recipient: {
          id: 'rec-1',
          recipientName: 'John Doe',
          email: 'john.doe@example.com'
        },
        invoice: {
          id: 'inv-3',
          invoiceNumber: 'INV-2025-003',
          amount: 2100.75
        }
      }
    ];
    
    // Override the mock implementation for this test
    require('../../api/distributionApi').getDistributions.mockImplementation(() => 
      Promise.resolve(mockDistributionsWithPending)
    );
    
    render(<DistributionDashboard organizationId="org-123" />);
    
    // Wait for the table to be populated
    await waitFor(() => {
      expect(screen.getByText('INV-2025-003')).toBeInTheDocument();
      expect(screen.getByText('PENDING')).toBeInTheDocument();
    });
    
    // Find and click the send button for the pending distribution
    const sendButtons = screen.getAllByTestId('send-button');
    fireEvent.click(sendButtons[0]);
    
    // Check if success message is shown
    await waitFor(() => {
      expect(screen.getByText('Distribution sent successfully')).toBeInTheDocument();
    });
  });

  test('refreshes distribution data when refresh button is clicked', async () => {
    render(<DistributionDashboard organizationId="org-123" />);
    
    // Wait for initial data to load
    await waitFor(() => {
      expect(screen.getByText('INV-2025-001')).toBeInTheDocument();
    });
    
    // Click the refresh button
    fireEvent.click(screen.getByText('Refresh'));
    
    // Check if the API was called again
    await waitFor(() => {
      expect(require('../../api/distributionApi').getDistributions).toHaveBeenCalledTimes(2);
    });
  });
});

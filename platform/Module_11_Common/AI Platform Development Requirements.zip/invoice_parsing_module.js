// Phase 1.1: Node.js Custom Parsing Module (invoice_parsing_module.js)
// This module is responsible for taking raw OCR text and attempting to extract structured invoice data.
// It will be called by the Invoice Generation Agent API.

// --- Helper functions for parsing and validation ---

function extractInvoiceNumber(text) {
    // Placeholder: Use regex and keyword spotting (e.g., "Invoice No", "Invoice #")
    // Example: const match = text.match(/(?:Invoice No|Invoice #|INV-):?\s*([A-Za-z0-9-]+)/i);
    // if (match && match[1]) return match[1].trim();
    // Handle errors/not found: return null or an object { value: null, error: "not_found" }
    return null; 
}

function extractDate(text, keywords) {
    // Placeholder: Look for keywords (e.g., ["Date", "Invoice Date"], ["Due Date"])
    // followed by common date formats. Use regex and date parsing libraries (e.g., moment.js or date-fns if available).
    // Example: const datePattern = /(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}|\d{4}[\/-]\d{1,2}[\/-]\d{1,2}|(?:Jan|Feb|...|Dec)\s\d{1,2},?\s\d{4})/i;
    // Validate extracted date string and format to YYYY-MM-DD.
    // Handle errors/not found/invalid format.
    return null;
}

function extractLineItems(text) {
    // Placeholder: This is the most complex part.
    // 1. Try to identify table headers (Description, Qty, Unit Price, Amount).
    // 2. Try to parse lines based on columnar alignment or patterns.
    // 3. For each potential line item, extract description, quantity, unit_price, line_total.
    // Validate numeric fields.
    // Handle errors if table structure is not clear or lines are unparseable.
    return []; // Array of line item objects
}

function extractCurrencyAmount(text, keywords) {
    // Placeholder: Look for keywords (e.g., ["Subtotal"], ["Total Due"], ["GST"])
    // followed by currency patterns (e.g., $123.45, 123.45 INR, £123.45).
    // Extract numeric value. Validate.
    // Handle errors/not found/invalid format.
    return null;
}

// --- Main Parsing Function ---

async function parseInvoiceText(rawText) {
    if (!rawText || typeof rawText !== "string" || rawText.trim().length === 0) {
        return {
            status: "error",
            message: "Input text is empty or invalid.",
            data: {}
        };
    }

    let extractedData = {};
    let errors = [];
    let warnings = [];

    try {
        // Invoice Number
        const invoiceNumber = extractInvoiceNumber(rawText);
        if (invoiceNumber) {
            extractedData.invoice_number = invoiceNumber;
        } else {
            warnings.push({ field: "invoice_number", message: "Could not reliably extract invoice number." });
        }

        // Issue Date
        const issueDate = extractDate(rawText, ["Date", "Invoice Date", "Issued on"]);
        if (issueDate) {
            extractedData.issue_date = issueDate; // Assuming YYYY-MM-DD format
        } else {
            warnings.push({ field: "issue_date", message: "Could not reliably extract issue date." });
        }

        // Due Date
        const dueDate = extractDate(rawText, ["Due Date", "Payment Due"]);
        if (dueDate) {
            extractedData.due_date = dueDate;
        } else {
            // Due date is often optional, so maybe a less critical warning or none.
        }

        // Line Items
        const lineItems = extractLineItems(rawText);
        if (lineItems.length > 0) {
            extractedData.line_items = lineItems;
        } else {
            warnings.push({ field: "line_items", message: "Could not extract any line items." });
        }
        
        // Currency (Attempt to infer or default - design doc says default INR)
        // extractedData.currency = "INR"; // Default, or try to find common symbols like $, £, € or ISO codes

        // Totals
        const subTotal = extractCurrencyAmount(rawText, ["Subtotal", "Sub-total", "Total before tax"]);
        if (subTotal) extractedData.sub_total = subTotal;

        const grandTotal = extractCurrencyAmount(rawText, ["Grand Total", "Total Due", "Amount Due", "Net Amount"]);
        if (grandTotal) extractedData.grand_total = grandTotal;
        
        // Placeholder for other fields like vendor_name, client_name, tax_amount
        // These would follow similar extraction patterns with keyword spotting and regex.

        // Basic validation of extracted structure (e.g., if line items exist, check totals)
        // This is more about the integrity of the *extraction process* rather than business rule validation yet.
        if (Object.keys(extractedData).length === 0 && warnings.length > 0) {
             return {
                status: "error",
                message: "Failed to extract any meaningful data from the invoice.",
                data: {},
                errors: warnings // Treat all warnings as errors if nothing is extracted
            };
        }

        return {
            status: "success",
            message: "Invoice data parsed. Review recommended.",
            data: extractedData,
            warnings: warnings.length > 0 ? warnings : undefined
        };

    } catch (error) {
        console.error("Error in parseInvoiceText:", error);
        return {
            status: "error",
            message: "An unexpected error occurred during invoice parsing.",
            details: error.message,
            data: extractedData, // Return any partially extracted data
            errors: [{ field: "general", message: error.message }]
        };
    }
}

// module.exports = { parseInvoiceText }; // To be used in invoice_controller_phase_1_1.js

console.log("Node.js parsing module structure outlined in invoice_parsing_module.js");


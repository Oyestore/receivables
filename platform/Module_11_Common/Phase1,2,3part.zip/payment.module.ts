import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { EventEmitterModule } from '@nestjs/event-emitter';

// Entities
import { PaymentGateway } from './entities/payment-gateway.entity';
import { PaymentMethod } from './entities/payment-method.entity';
import { PaymentTransaction } from './entities/payment-transaction.entity';
import { PaymentReconciliation } from './entities/payment-reconciliation.entity';

// Services
import { PaymentGatewayFactory } from './services/payment-gateway-factory.service';
import { PaymentProcessingService } from './services/payment-processing.service';
import { InvoicePaymentIntegrationService } from './services/invoice-payment-integration.service';
import { DistributionPaymentIntegrationService } from './services/distribution-payment-integration.service';

// Controllers
import { PaymentGatewayController } from './controllers/payment-gateway.controller';
import { PaymentMethodController } from './controllers/payment-method.controller';
import { PaymentTransactionController } from './controllers/payment-transaction.controller';

// External module entities
import { Invoice } from '../invoices/entities/invoice.entity';
import { DistributionRecord } from '../distribution/entities/distribution-record.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      PaymentGateway,
      PaymentMethod,
      PaymentTransaction,
      PaymentReconciliation,
      Invoice,
      DistributionRecord,
    ]),
    ConfigModule,
    EventEmitterModule.forRoot(),
  ],
  controllers: [
    PaymentGatewayController,
    PaymentMethodController,
    PaymentTransactionController,
  ],
  providers: [
    PaymentGatewayFactory,
    PaymentProcessingService,
    InvoicePaymentIntegrationService,
    DistributionPaymentIntegrationService,
  ],
  exports: [
    PaymentProcessingService,
    InvoicePaymentIntegrationService,
    DistributionPaymentIntegrationService,
  ],
})
export class PaymentModule {}

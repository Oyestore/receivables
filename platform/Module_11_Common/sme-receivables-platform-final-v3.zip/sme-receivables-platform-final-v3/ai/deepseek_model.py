#!/usr/bin/env python3

import os
import argparse
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline

class DeepseekModel:
    def __init__(self, model_path=None, device=None):
        """Initialize the Deepseek R1 model for financial applications.
        
        Args:
            model_path: Path to the model weights. If None, will use the default path.
            device: Device to run the model on. If None, will use CUDA if available.
        """
        if model_path is None:
            model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models/deepseek-r1")
        
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        
        print(f"Loading Deepseek R1 model from {model_path} on {device}...")
        
        self.tokenizer = AutoTokenizer.from_pretrained(model_path)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_path,
            torch_dtype=torch.float16 if device == "cuda" else torch.float32,
            low_cpu_mem_usage=True,
            device_map=device
        )
        
        self.pipe = pipeline(
            "text-generation",
            model=self.model,
            tokenizer=self.tokenizer,
            max_length=2048,
            temperature=0.7,
            top_p=0.95,
            repetition_penalty=1.1
        )
        
        print("Model loaded successfully!")
    
    def generate(self, prompt, max_length=1024, temperature=0.7):
        """Generate text based on the prompt.
        
        Args:
            prompt: The input prompt.
            max_length: Maximum length of the generated text.
            temperature: Temperature for sampling.
            
        Returns:
            Generated text.
        """
        result = self.pipe(
            prompt,
            max_length=max_length,
            temperature=temperature,
            do_sample=True
        )[0]["generated_text"]
        
        # Return only the newly generated text
        return result[len(prompt):]
    
    def analyze_invoice(self, invoice_text):
        """Analyze an invoice and extract key information.
        
        Args:
            invoice_text: The text of the invoice.
            
        Returns:
            Dictionary with extracted information.
        """
        prompt = f"""
        Analyze the following invoice and extract key information:
        
        {invoice_text}
        
        Extract the following information in JSON format:
        - Invoice number
        - Issue date
        - Due date
        - Vendor name
        - Customer name
        - Line items (with description, quantity, unit price, and amount)
        - Subtotal
        - Tax
        - Total amount
        """
        
        response = self.generate(prompt)
        # In a real implementation, we would parse the JSON response
        # For now, we just return the raw response
        return response
    
    def assess_buyer_risk(self, buyer_data):
        """Assess the risk of a buyer based on historical data.
        
        Args:
            buyer_data: Dictionary with buyer information and payment history.
            
        Returns:
            Risk assessment report.
        """
        prompt = f"""
        Assess the risk of the following buyer based on their payment history:
        
        Buyer: {buyer_data['name']}
        Industry: {buyer_data['industry']}
        Years in business: {buyer_data['years_in_business']}
        
        Payment history:
        {buyer_data['payment_history']}
        
        Provide a risk assessment with the following:
        1. Risk score (1-10, where 10 is highest risk)
        2. Key risk factors
        3. Recommendations for payment terms
        """
        
        return self.generate(prompt)
    
    def optimize_payment_terms(self, invoice_data, buyer_data):
        """Optimize payment terms for an invoice based on buyer data.
        
        Args:
            invoice_data: Dictionary with invoice information.
            buyer_data: Dictionary with buyer information and payment history.
            
        Returns:
            Recommended payment terms.
        """
        prompt = f"""
        Optimize payment terms for the following invoice:
        
        Invoice amount: {invoice_data['amount']}
        Current payment terms: {invoice_data['current_terms']}
        
        Buyer information:
        Name: {buyer_data['name']}
        Industry: {buyer_data['industry']}
        Years in business: {buyer_data['years_in_business']}
        Average days to payment: {buyer_data['avg_days_to_payment']}
        
        Recommend optimal payment terms with the following:
        1. Recommended payment period (days)
        2. Early payment discount (if applicable)
        3. Late payment penalties (if applicable)
        4. Justification for recommendations
        """
        
        return self.generate(prompt)
    
    def draft_communication(self, communication_type, invoice_data, buyer_data):
        """Draft a communication to a buyer.
        
        Args:
            communication_type: Type of communication (reminder, thank you, etc.)
            invoice_data: Dictionary with invoice information.
            buyer_data: Dictionary with buyer information.
            
        Returns:
            Draft communication text.
        """
        prompt = f"""
        Draft a {communication_type} message for the following invoice:
        
        Invoice number: {invoice_data['number']}
        Issue date: {invoice_data['issue_date']}
        Due date: {invoice_data['due_date']}
        Amount: {invoice_data['amount']}
        
        Buyer:
        Name: {buyer_data['name']}
        Contact person: {buyer_data['contact_name']}
        
        The tone should be professional but friendly. Include all relevant invoice details.
        """
        
        return self.generate(prompt)

def main():
    parser = argparse.ArgumentParser(description="Deepseek R1 Financial AI")
    parser.add_argument("--model_path", type=str, help="Path to model weights")
    parser.add_argument("--device", type=str, choices=["cpu", "cuda"], help="Device to run on")
    parser.add_argument("--function", type=str, required=True, 
                        choices=["analyze_invoice", "assess_risk", "optimize_terms", "draft_communication"],
                        help="Function to run")
    parser.add_argument("--input", type=str, required=True, help="Input file path")
    parser.add_argument("--output", type=str, help="Output file path")
    
    args = parser.parse_args()
    
    model = DeepseekModel(model_path=args.model_path, device=args.device)
    
    with open(args.input, 'r') as f:
        input_data = f.read()
    
    if args.function == "analyze_invoice":
        result = model.analyze_invoice(input_data)
    elif args.function == "assess_risk":
        # In a real implementation, we would parse the input data as JSON
        result = model.assess_buyer_risk({"name": "Example Buyer", "industry": "Technology", 
                                         "years_in_business": 5, "payment_history": input_data})
    elif args.function == "optimize_terms":
        # In a real implementation, we would parse the input data as JSON
        result = model.optimize_payment_terms(
            {"amount": 10000, "current_terms": "Net 30"},
            {"name": "Example Buyer", "industry": "Technology", 
             "years_in_business": 5, "avg_days_to_payment": 25}
        )
    elif args.function == "draft_communication":
        # In a real implementation, we would parse the input data as JSON
        result = model.draft_communication(
            "reminder",
            {"number": "INV-2025-001", "issue_date": "2025-04-01", 
             "due_date": "2025-05-01", "amount": 10000},
            {"name": "Example Corp", "contact_name": "John Doe"}
        )
    
    if args.output:
        with open(args.output, 'w') as f:
            f.write(result)
    else:
        print(result)

if __name__ == "__main__":
    main()

# Deployment Guide - SME Receivables Management Platform

## Introduction

This deployment guide provides step-by-step instructions for deploying the SME Receivables Management Platform in various environments. The platform is designed to be self-hosted and can be deployed on-premises or in any cloud environment of your choice.

## Prerequisites

Before deploying the platform, ensure you have the following prerequisites:

### Hardware Requirements
- **Minimum**: 4 CPU cores, 8GB RAM, 50GB storage
- **Recommended**: 8 CPU cores, 16GB RAM, 100GB storage
- **Production**: Scale based on expected user load and data volume

### Software Requirements
- Docker Engine (version 20.10.0 or later)
- Docker Compose (version 2.0.0 or later)
- Git (for cloning the repository)
- A domain name with DNS configured (for production)
- SSL certificate (for production)

### Network Requirements
- Outbound internet access for pulling Docker images
- Inbound access to ports 80 and 443 for web traffic
- Firewall rules to restrict access to management ports

## Deployment Options

The platform can be deployed in several ways depending on your requirements:

### 1. Development Environment

A lightweight setup for development and testing purposes.

### 2. Single-Server Production

All components running on a single server, suitable for small to medium deployments.

### 3. Distributed Production

Components distributed across multiple servers for high availability and scalability.

### 4. Cloud Provider Deployment

Deployment on major cloud providers (AWS, Azure, GCP) with provider-specific optimizations.

## Deployment Steps

### 1. Clone the Repository

```bash
git clone https://github.com/your-organization/sme-receivables-platform.git
cd sme-receivables-platform
```

### 2. Configure Environment Variables

Create a `.env` file in the root directory with the appropriate configuration:

```bash
# Create .env file from template
cp .env.example .env

# Edit the .env file with your configuration
nano .env
```

Update the following variables in the `.env` file:

```
# Database Configuration
DATABASE_URL=postgres://postgres:your_secure_password@postgres:5432/sme_receivables
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_secure_password
POSTGRES_DB=sme_receivables

# JWT Configuration
JWT_SECRET=your_secure_jwt_secret

# Redis Configuration
REDIS_URL=redis://redis:6379

# MinIO Configuration
MINIO_ROOT_USER=your_minio_username
MINIO_ROOT_PASSWORD=your_minio_password
MINIO_ENDPOINT=minio
MINIO_PORT=9000
MINIO_USE_SSL=false
MINIO_BUCKET=sme-receivables

# API Configuration
PORT=3000
NODE_ENV=production
```

### 3. Configure SSL (Production Only)

For production deployments, configure SSL:

```bash
# Run the SSL setup script
./deployment/ssl_setup.sh
```

For production, replace the self-signed certificates with valid certificates from a trusted certificate authority.

### 4. Build and Start the Containers

#### Development Environment

```bash
docker-compose up -d
```

#### Production Environment

```bash
docker-compose -f docker-compose.prod.yml up -d
```

### 5. Initialize the Database

The database will be automatically initialized with the schema and sample data. To verify:

```bash
docker-compose exec postgres psql -U postgres -d sme_receivables -c "\dt"
```

### 6. Create Admin User

If you need to create an additional admin user:

```bash
docker-compose exec api node scripts/create-admin.js
```

### 7. Verify Deployment

Check that all containers are running:

```bash
docker-compose ps
```

Verify the API is accessible:

```bash
curl http://localhost:8080/api/health
```

## Multi-Tenancy Setup

The platform supports multi-tenancy. To configure:

### 1. Create Tenant

```bash
docker-compose exec api node scripts/create-tenant.js
```

### 2. Configure Tenant-Specific Settings

Access the Admin Portal at `/admin` and configure tenant-specific settings.

## Scaling the Deployment

### Vertical Scaling

Increase resources allocated to the Docker containers:

```bash
docker-compose up -d --scale api=2
```

### Horizontal Scaling

For distributed deployments, use Docker Swarm or Kubernetes:

#### Docker Swarm

```bash
# Initialize swarm
docker swarm init

# Deploy stack
docker stack deploy -c docker-compose.prod.yml sme-platform
```

#### Kubernetes

```bash
# Apply Kubernetes manifests
kubectl apply -f kubernetes/
```

## Backup and Recovery

### Database Backup

```bash
# Run the backup script
./deployment/backup.sh
```

### Database Restore

```bash
# Restore from backup
cat backups/db_backup_YYYYMMDD_HHMMSS.sql | docker-compose exec -T postgres psql -U postgres sme_receivables
```

## Monitoring

### Health Checks

Monitor the health endpoints:

```bash
curl http://localhost:8080/api/health
```

### Logs

View container logs:

```bash
docker-compose logs -f
```

### Metrics

The platform exposes metrics at:

```
http://localhost:8080/api/metrics
```

## Upgrading

To upgrade to a new version:

```bash
# Pull latest changes
git pull

# Backup the database
./deployment/backup.sh

# Rebuild and restart containers
docker-compose down
docker-compose -f docker-compose.prod.yml build
docker-compose -f docker-compose.prod.yml up -d

# Verify upgrade
curl http://localhost:8080/api/health
```

## Troubleshooting

### Common Issues

#### Containers Fail to Start

Check the logs:

```bash
docker-compose logs <service-name>
```

#### Database Connection Issues

Verify database credentials and connectivity:

```bash
docker-compose exec api node scripts/check-db-connection.js
```

#### Permission Issues

Ensure proper file permissions:

```bash
chmod -R 755 ./
```

#### Memory Issues

Check container memory usage:

```bash
docker stats
```

## Security Considerations

### Firewall Configuration

Restrict access to management ports:

```bash
ufw allow 80/tcp
ufw allow 443/tcp
ufw deny 5432/tcp
ufw deny 6379/tcp
ufw deny 9000/tcp
```

### Regular Updates

Keep the system updated:

```bash
apt update && apt upgrade -y
docker-compose pull
```

### Audit Logging

Enable audit logging in the Admin Portal.

## Cloud-Specific Deployment

### AWS Deployment

1. Launch EC2 instances with appropriate security groups
2. Install Docker and Docker Compose
3. Clone the repository and configure as above
4. Consider using RDS for PostgreSQL and ElastiCache for Redis

### Azure Deployment

1. Create Azure VMs with appropriate network security groups
2. Install Docker and Docker Compose
3. Clone the repository and configure as above
4. Consider using Azure Database for PostgreSQL and Azure Cache for Redis

### Google Cloud Deployment

1. Create Compute Engine instances with appropriate firewall rules
2. Install Docker and Docker Compose
3. Clone the repository and configure as above
4. Consider using Cloud SQL for PostgreSQL and Memorystore for Redis

## Conclusion

You have successfully deployed the SME Receivables Management Platform. For additional support, refer to the Administrator Guide or contact the support team.

---

This deployment guide is regularly updated. For the latest version, please check the official documentation repository.

import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { Inject } from '@nestjs/common';
import { QueueHealthService } from '../../queue/services/queue-health.service';

/**
 * Service that coordinates distribution consumers for different channels
 */
@Injectable()
export class DistributionConsumerService implements OnModuleInit {
  private readonly logger = new Logger(DistributionConsumerService.name);

  constructor(
    @Inject('DISTRIBUTION_SERVICE') private readonly client: ClientProxy,
    private readonly queueHealthService: QueueHealthService,
  ) {}

  /**
   * Initialize connection to RabbitMQ when module starts
   */
  async onModuleInit() {
    try {
      await this.client.connect();
      this.logger.log('Distribution consumer service connected to RabbitMQ');
    } catch (error) {
      this.logger.error(`Failed to connect distribution consumer to RabbitMQ: ${error.message}`, error.stack);
    }
  }

  /**
   * Record successful message processing
   * @param queueName Name of the queue
   * @param processingTime Time taken to process the message in milliseconds
   */
  recordMessageProcessed(queueName: string, processingTime: number): void {
    this.queueHealthService.incrementMessagesProcessed(queueName, processingTime);
    this.logger.debug(`Message from ${queueName} processed in ${processingTime}ms`);
  }

  /**
   * Record error in message processing
   * @param queueName Name of the queue
   * @param error Error that occurred
   */
  recordProcessingError(queueName: string, error: any): void {
    this.queueHealthService.incrementErrors(queueName);
    this.logger.error(`Error processing message from ${queueName}: ${error.message}`, error.stack);
  }
}

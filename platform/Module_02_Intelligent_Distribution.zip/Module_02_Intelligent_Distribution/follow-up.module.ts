import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FollowUpRule } from './entities/follow-up-rule.entity';
import { FollowUpSequence } from './entities/follow-up-sequence.entity';
import { FollowUpStep } from './entities/follow-up-step.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      FollowUpRule,
      FollowUpSequence,
      FollowUpStep,
    ]),
  ],
  controllers: [],
  providers: [],
  exports: [],
})
export class FollowUpModule {}

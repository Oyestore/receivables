/*
Main JavaScript file for the Smart Invoice Template Editor (GrapesJS Integration)
File: /home/ubuntu/smart_invoice_module/invoice_agent_nestjs/src/frontend_app/js/editor-main.js
*/

document.addEventListener("DOMContentLoaded", () => {
    const currentOrganizationId = "mock-org-uuid"; 
    let currentTemplateId = "new"; 
    let currentTemplateVersion = 1;
    let currentTemplateStatus = "DRAFT";
    const DEFAULT_SYSTEM_TEMPLATE_ID = "default-classic-professional"; // Placeholder ID for the default template

    const API_BASE_URL = "/api"; 

    function updateTemplateInfoUI(name, version, status) {
        const nameEl = document.getElementById("template-name-input");
        const versionEl = document.getElementById("template-version-display");
        const statusEl = document.getElementById("template-status-display");
        if (nameEl) nameEl.value = name || "Untitled Template";
        if (versionEl) versionEl.textContent = `Version: ${version || 1}`;
        if (statusEl) statusEl.textContent = `Status: ${status || "DRAFT"}`;
    }

    const editor = grapesjs.init({
        container: "#gjs-editor-container",
        height: "calc(100vh - 150px)", 
        width: "auto",
        fromElement: false, 

        storageManager: {
            type: "remote",
            autosave: false, 
            stepsBeforeSave: 1,
            contentTypeJson: true,
            onStore: (data, editor) => {
                let templateName = document.getElementById("template-name-input").value || "Untitled Template";
                let templateDescription = document.getElementById("template-description-input").value || "";
                
                editor.Config.templateName = templateName; 

                const method = currentTemplateId === "new" || currentTemplateId === DEFAULT_SYSTEM_TEMPLATE_ID ? "POST" : "PUT";
                // If currentTemplateId is default, treat save as creating a new template from it
                const url = (currentTemplateId === "new" || currentTemplateId === DEFAULT_SYSTEM_TEMPLATE_ID)
                    ? `${API_BASE_URL}/organizations/${currentOrganizationId}/templates` 
                    : `${API_BASE_URL}/organizations/${currentOrganizationId}/templates/${currentTemplateId}`;

                let payload = {
                    template_name: templateName,
                    description: templateDescription,
                    template_definition: data, 
                    organization_id: currentOrganizationId,
                };
                // If saving a new template based on the default, we might want to indicate its origin
                if (currentTemplateId === DEFAULT_SYSTEM_TEMPLATE_ID) {
                    payload.source_template_id = DEFAULT_SYSTEM_TEMPLATE_ID; 
                }

                return {
                    url,
                    method,
                    data: payload
                };
            },
            onLoad: (result) => {
                if (result && result.template_definition) {
                    editor.Config.templateName = result.template_name;
                    editor.Config.templateDescription = result.description;
                    currentTemplateVersion = result.version;
                    currentTemplateStatus = result.status;
                    updateTemplateInfoUI(result.template_name, result.version, result.status);
                    document.getElementById("template-description-input").value = result.description || "";
                    return result.template_definition;
                }
                updateTemplateInfoUI("Untitled Template", 1, "DRAFT");
                return {}; 
            },
            fetch: async (url, options) => {
                const storeParams = options.onStore(editor.getProjectData(), editor);
                
                const fetchOptions = {
                    method: storeParams.method,
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(storeParams.data)
                };
                const response = await fetch(storeParams.url, fetchOptions);
                if (!response.ok) {
                    const errData = await response.json();
                    console.error("Save Error:", errData);
                    alert(`Error saving template: ${errData.message || response.statusText}`);
                    throw new Error(errData.message || `Request failed with status ${response.status}`);
                }
                const responseData = await response.json();
                // After a successful POST (new or from default), update currentTemplateId to the new ID
                if ((storeParams.method === "POST") && responseData.id) {
                    currentTemplateId = responseData.id;
                    currentTemplateVersion = responseData.version;
                    currentTemplateStatus = responseData.status;
                    editor.Storage.set("remote", { 
                        ...editor.Storage.get("remote").getConfig(), 
                        urlStore: `${API_BASE_URL}/organizations/${currentOrganizationId}/templates/${currentTemplateId}`,
                        urlLoad: `${API_BASE_URL}/organizations/${currentOrganizationId}/templates/${currentTemplateId}`
                    });
                    window.history.pushState({}, "", `?templateId=${currentTemplateId}`); 
                } else if (storeParams.method === "PUT") {
                    currentTemplateId = responseData.id; 
                    currentTemplateVersion = responseData.version;
                    currentTemplateStatus = responseData.status;
                     editor.Storage.set("remote", { 
                        ...editor.Storage.get("remote").getConfig(), 
                        urlStore: `${API_BASE_URL}/organizations/${currentOrganizationId}/templates/${currentTemplateId}`,
                        urlLoad: `${API_BASE_URL}/organizations/${currentOrganizationId}/templates/${currentTemplateId}`
                    });
                }
                updateTemplateInfoUI(responseData.template_name, responseData.version, responseData.status);
                alert("Template saved successfully!");
                return responseData; 
            },
            fetchLoad: async (options) => {
                // This fetchLoad is called by editor.load(). currentTemplateId should be set before calling it.
                if (currentTemplateId === "new" || !currentTemplateId) { // Should not happen if we set default ID
                    updateTemplateInfoUI("Untitled Template", 1, "DRAFT");
                    return {}; 
                }
                const loadUrl = `${API_BASE_URL}/organizations/${currentOrganizationId}/templates/${currentTemplateId}`;
                const response = await fetch(loadUrl, { headers: { } });
                if (!response.ok) {
                    const errData = await response.json();
                    console.error("Load Error:", errData);
                    alert(`Error loading template ${currentTemplateId}: ${errData.message || response.statusText}`);
                    // If default template load fails, fallback to a blank editor
                    if (currentTemplateId === DEFAULT_SYSTEM_TEMPLATE_ID) {
                        currentTemplateId = "new";
                        updateTemplateInfoUI("Untitled Template", 1, "DRAFT");
                        return {}; // Return empty to start blank
                    }
                    throw new Error(errData.message || `Failed to load template: ${response.status}`);
                }
                return response.json();
            }
        },

        blockManager: {
            appendTo: "#blocks-container",
            blocks: [
                { id: "text", label: "Text", content: "<div data-gjs-type=\"text\">Insert your text here</div>", category: "Basic" },
                { id: "image", label: "Image", select: true, content: { type: "image" }, activate: true, category: "Basic" },
                {
                    id: "invoice-header-block",
                    label: "Invoice Header",
                    content: `
                        <div class="invoice-header-section" data-gjs-droppable=".company-logo-area, .company-details-area, .invoice-info-area" data-gjs-custom-name="Invoice Header">
                            <div class="company-logo-area" data-gjs-custom-name="Logo Area" style="padding:10px; min-height:50px; border:1px dashed #ccc;"><!-- Drag Logo Image Here --></div>
                            <div class="company-details-area" data-gjs-custom-name="Company Details" style="padding:10px; min-height:50px; border:1px dashed #ccc;">
                                <h1 data-field-id="company.name" data-gjs-type="text">{{company.name}}</h1>
                                <p data-field-id="company.address" data-gjs-type="text">{{company.address}}</p>
                            </div>
                            <div class="invoice-info-area" data-gjs-custom-name="Invoice Info" style="padding:10px; min-height:50px; border:1px dashed #ccc;">
                                <h2 data-field-id="invoice.title" data-gjs-type="text">INVOICE</h2>
                                <p data-gjs-type="text">Invoice #: <span data-field-id="invoice.number">{{invoice.number}}</span></p>
                                <p data-gjs-type="text">Date: <span data-field-id="invoice.date">{{invoice.date}}</span></p>
                            </div>
                        </div>
                    `,
                    category: "Invoice Sections",
                },
                {
                    id: "line-items-table-block",
                    label: "Line Items Table",
                    content: `
                        <table class="table table-bordered invoice-line-items" data-gjs-custom-name="Line Items Table" data-field-id="invoice.line_items_table">
                            <thead>
                                <tr>
                                    <th data-field-id="line_items.header.description">Description</th>
                                    <th data-field-id="line_items.header.quantity">Quantity</th>
                                    <th data-field-id="line_items.header.unit_price">Unit Price</th>
                                    <th data-field-id="line_items.header.total">Total</th>
                                </tr>
                            </thead>
                            <tbody data-gjs-repeatable="line_items" data-gjs-repeatable-source="invoice.line_items">
                                <tr data-gjs-repeatable-item>
                                    <td data-field-id="description">{{item.description}}</td>
                                    <td data-field-id="quantity">{{item.quantity}}</td>
                                    <td data-field-id="unit_price">{{item.unit_price}}</td>
                                    <td data-field-id="line_total">{{item.line_total}}</td>
                                </tr>
                            </tbody>
                        </table>
                    `,
                    category: "Invoice Sections",
                },
                 {
                    id: "totals-section-block",
                    label: "Totals Section",
                    content: `
                        <div class="invoice-totals-section" data-gjs-custom-name="Totals Section" style="padding:10px; margin-top:20px; border:1px dashed #ccc;">
                            <p>Subtotal: <span data-field-id="invoice.subtotal">{{invoice.subtotal}}</span></p>
                            <p>Tax ({{invoice.tax_rate}}%): <span data-field-id="invoice.tax_amount">{{invoice.tax_amount}}</span></p>
                            <h3>Total: <span data-field-id="invoice.total_amount">{{invoice.total_amount}}</span></h3>
                        </div>
                    `, 
                    category: "Invoice Sections"
                },
                {
                    id: "terms-block",
                    label: "Terms & Conditions",
                    content: `<div data-gjs-type="text" data-field-id="invoice.terms" data-gjs-custom-name="Terms">Enter terms and conditions here...</div>`,
                    category: "Invoice Sections"
                },
                {
                    id: "footer-block",
                    label: "Footer Block",
                    content: `<div style="text-align:center; padding:10px; margin-top:30px; border-top:1px solid #eee;" data-gjs-type="text" data-field-id="invoice.footer" data-gjs-custom-name="Footer">Thank you for your business!</div>`,
                    category: "Invoice Sections"
                }
            ],
        },

        styleManager: { appendTo: "#styles-container" },
        layerManager: { appendTo: "#layers-container" },
        traitManager: { appendTo: "#traits-container" },
        deviceManager: {
            devices: [
                { name: "Desktop", width: "" },
                { name: "Tablet", width: "768px", widthMedia: "992px" },
                { name: "Mobile", width: "320px", widthMedia: "480px" },
            ],
        },
        assetManager: {
            assets: [],
            upload: `${API_BASE_URL}/organizations/${currentOrganizationId}/assets/upload`, 
            uploadName: "files",
        },
        canvas: {
            styles: [
                "https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css",
                "css/editor-canvas-styles.css"
            ],
        },
        plugins: [
            function(editor) {
                editor.DomComponents.addType("text", {
                    model: {
                        defaults: {
                            traits: [
                                { type: "text", name: "data-field-id", label: "Data Field ID" }
                            ]
                        }
                    }
                });
            }
        ], 
        pluginsOpts: {}
    });

    editor.Commands.add("save-template-cmd", {
        run: function(editor, sender) {
            sender && sender.set("active", false);
            editor.store().catch(err => {
                console.error("Error explicitly saving template:", err);
                sender && sender.set("active", true);
            });
        }
    });

    editor.Panels.addButton("options", [{
        id: "save-db-btn",
        className: "fa fa-floppy-o",
        command: "save-template-cmd",
        attributes: { title: "Save Template" }
    }]);

    editor.Commands.add("publish-template-cmd", {
        run: async function(editor, sender) {
            if (currentTemplateId === "new" || currentTemplateId === DEFAULT_SYSTEM_TEMPLATE_ID || !currentTemplateId) {
                alert("Please save the template first before publishing.");
                return;
            }
            if (currentTemplateStatus === "PUBLISHED") {
                alert("Template is already published.");
                return;
            }
            sender && sender.set("active", false);
            try {
                const response = await fetch(`${API_BASE_URL}/organizations/${currentOrganizationId}/templates/${currentTemplateId}/publish`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" }
                });
                if (!response.ok) throw new Error((await response.json()).message || "Failed to publish");
                const updatedTemplate = await response.json();
                currentTemplateStatus = updatedTemplate.status;
                currentTemplateVersion = updatedTemplate.version; 
                updateTemplateInfoUI(updatedTemplate.template_name, updatedTemplate.version, updatedTemplate.status);
                alert("Template pub
(Content truncated due to size limit. Use line ranges to read in chunks)
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AnalyticsService } from './services/analytics.service';
import { AnalyticsController } from './controllers/analytics.controller';
import { QueueModule } from '../queue/queue.module';
import { DistributionModule } from '../distribution/distribution.module';
import { FollowUpModule } from '../follow-up/follow-up.module';
import { AnalyticsDataService } from './services/analytics-data.service';
import { ReportingService } from './services/reporting.service';
import { AlertService } from './services/alert.service';
import { ScheduleModule } from '@nestjs/schedule';

@Module({
  imports: [
    TypeOrmModule.forFeature([]),
    QueueModule,
    DistributionModule,
    FollowUpModule,
    ScheduleModule.forRoot(),
  ],
  controllers: [AnalyticsController],
  providers: [
    AnalyticsService,
    AnalyticsDataService,
    ReportingService,
    AlertService,
  ],
  exports: [AnalyticsService],
})
export class AnalyticsModule {}

# User Testing Guide Creation

- [ ] Create the main structure for `user_testing_guide.md`.
- [ ] Outline the user testing sequence (Admin and SME user flows).
- [ ] Describe key screens and their expected UI elements in `user_testing_guide.md`.
- [ ] Generate conceptual images for key screens:
    - [X] Login Page Image (Description provided) (`/home/ubuntu/testing_images/login_page.png`)
    - [X] Admin Dashboard Image (Description provided) (`/home/ubuntu/testing_images/admin_dashboard.png`)
    - [X] SME Dashboard Image (Description provided) (`/home/ubuntu/testing_images/sme_dashboard.png`)
    - [X] Organization List Page Image (Description provided) (`/home/ubuntu/testing_images/organization_list_page.png`)
    - [X] Create/Edit Organization Page Image (Description provided) (`/home/ubuntu/testing_images/organization_form_page.png`)
    - [X] User List Page Image (Admin) (Description provided) (`/home/ubuntu/testing_images/user_list_page.png`)
    - [X] Create/Edit User Page Image (Admin) (Description provided) (`/home/ubuntu/testing_images/user_form_page.png`)
    - [X] Invoice List Page Image (Description provided) (`/home/ubuntu/testing_images/invoice_list_page.png`)
    - [X] Create/Edit Invoice Page Image (Description provided) (`/home/ubuntu/testing_images/invoice_form_page.png`)
    - [X] Invoice Detail Page Image (Description provided) (`/home/ubuntu/testing_images/invoice_detail_page.png`)
    - [X] Profile Page Image (Description provided) (`/home/ubuntu/testing_images/profile_page.png`)
- [~] Add generated images (or placeholders) to `user_testing_guide.md` (Handled by detailed text descriptions as image generation was unavailable).
- [X] Specify functionalities to test on each screen in `user_testing_guide.md`, including actions and expected outcomes.
- [X] Incorporate testing for smart invoice distribution (email, WhatsApp) and workflow customization in `user_testing_guide.md`.

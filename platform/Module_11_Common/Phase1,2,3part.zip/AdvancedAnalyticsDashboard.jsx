import React, { useState, useEffect, useContext } from 'react';
import { 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Box, 
  Tabs, 
  Tab, 
  CircularProgress,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Alert,
  useMediaQuery,
  useTheme,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  IconButton,
  Divider
} from '@mui/material';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell,
  AreaChart,
  Area,
  ComposedChart,
  Scatter,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Treemap
} from 'recharts';
import RefreshIcon from '@mui/icons-material/Refresh';
import DownloadIcon from '@mui/icons-material/Download';
import WarningIcon from '@mui/icons-material/Warning';
import MenuIcon from '@mui/icons-material/Menu';
import DashboardIcon from '@mui/icons-material/Dashboard';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import NotificationsIcon from '@mui/icons-material/Notifications';
import DescriptionIcon from '@mui/icons-material/Description';
import SettingsIcon from '@mui/icons-material/Settings';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import PeopleIcon from '@mui/icons-material/People';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import { UserContext } from '../contexts/UserContext';

/**
 * Advanced Analytics Dashboard Component
 * Provides comprehensive visualization of distribution metrics, follow-up performance,
 * system health, template effectiveness, and SMB-focused KPIs
 */
const AdvancedAnalyticsDashboard = () => {
  // Access user context for role-based views
  const { user } = useContext(UserContext);
  const userRole = user?.role || 'arSpecialist'; // Default to AR Specialist if no role

  // State for dashboard data
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [timeRange, setTimeRange] = useState('week');
  const [refreshing, setRefreshing] = useState(false);
  const [alertOpen, setAlertOpen] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSeverity, setAlertSeverity] = useState('info');
  
  // Mobile responsive state
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));
  const [drawerOpen, setDrawerOpen] = useState(false);
  
  // Available tabs based on user role
  const [availableTabs, setAvailableTabs] = useState([]);
  const [availableActions, setAvailableActions] = useState([]);

  // Colors for charts
  const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088FE', '#00C49F'];
  const channelColors = {
    email: '#8884d8',
    whatsapp: '#82ca9d',
    sms: '#ffc658'
  };

  // Define all possible tabs
  const allTabs = [
    { id: 'overview', label: 'Overview', icon: <DashboardIcon /> },
    { id: 'distribution', label: 'Distribution', icon: <LocalShippingIcon /> },
    { id: 'followUp', label: 'Follow-up', icon: <NotificationsIcon /> },
    { id: 'template', label: 'Templates', icon: <DescriptionIcon /> },
    { id: 'system', label: 'System Health', icon: <SettingsIcon /> },
    { id: 'cashFlow', label: 'Cash Flow', icon: <MonetizationOnIcon /> },
    { id: 'customerBehavior', label: 'Customer Behavior', icon: <PeopleIcon /> },
    { id: 'performance', label: 'Performance', icon: <TrendingUpIcon /> }
  ];

  // Load dashboard data on component mount and when time range changes
  useEffect(() => {
    fetchDashboardData();
    
    // Set up WebSocket connection for real-time updates
    const ws = new WebSocket('ws://localhost:3000/analytics');
    
    ws.onopen = () => {
      console.log('WebSocket connection established');
    };
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'analytics_update') {
        updateDashboardData(data.payload);
      }
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      // Fall back to polling if WebSocket fails
      const interval = setInterval(() => {
        fetchDashboardData(false); // Silent refresh
      }, 30000);
      return () => clearInterval(interval);
    };
    
    ws.onclose = () => {
      console.log('WebSocket connection closed');
    };
    
    // Clean up WebSocket on unmount
    return () => {
      ws.close();
    };
  }, [timeRange, userRole]);

  // Fetch available tabs and actions based on user role
  useEffect(() => {
    fetchAvailableTabsAndActions();
  }, [userRole]);

  // Fetch available tabs and actions for the user's role
  const fetchAvailableTabsAndActions = async () => {
    try {
      // In a real implementation, this would be an API call
      // const response = await fetch(`/api/analytics/access?role=${userRole}`);
      // const data = await response.json();
      
      // For demonstration, we'll simulate API response with mock data
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay
      
      let availableDashboards;
      let availableActionsList;
      
      switch(userRole) {
        case 'admin':
          availableDashboards = ['overview', 'distribution', 'followUp', 'template', 'system', 'customerBehavior', 'cashFlow', 'performance'];
          availableActionsList = ['export', 'configure', 'share'];
          break;
        case 'financeManager':
          availableDashboards = ['overview', 'distribution', 'followUp', 'cashFlow'];
          availableActionsList = ['export', 'configure'];
          break;
        case 'arSpecialist':
          availableDashboards = ['overview', 'distribution', 'followUp', 'customerBehavior'];
          availableActionsList = ['export'];
          break;
        case 'executive':
          availableDashboards = ['overview', 'performance'];
          availableActionsList = ['export'];
          break;
        default:
          availableDashboards = ['overview'];
          availableActionsList = [];
      }
      
      // Filter tabs based on available dashboards
      const filteredTabs = allTabs.filter(tab => availableDashboards.includes(tab.id));
      setAvailableTabs(filteredTabs);
      setAvailableActions(availableActionsList);
      
      // If current active tab is not available, set to first available tab
      if (!availableDashboards.includes(allTabs[activeTab]?.id)) {
        setActiveTab(0);
      }
    } catch (err) {
      console.error('Error fetching available tabs:', err);
      setAvailableTabs([allTabs[0]]); // Default to overview tab
      setAvailableActions([]);
    }
  };

  // Fetch dashboard data from API
  const fetchDashboardData = async (showLoading = true) => {
    if (showLoading) {
      setLoading(true);
    } else {
      setRefreshing(true);
    }
    
    try {
      // In a real implementation, this would be an API call
      // const response = await fetch(`/api/analytics/dashboard?timeRange=${timeRange}&role=${userRole}`);
      // const data = await response.json();
      
      // For demonstration, we'll simulate API response with mock data
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay
      const data = getMockDashboardData();
      
      setDashboardData(data);
      setError(null);
      
      if (!showLoading) {
        setAlertMessage('Dashboard data refreshed successfully');
        setAlertSeverity('success');
        setAlertOpen(true);
      }
    } catch (err) {
      setError('Failed to load dashboard data. Please try again.');
      setAlertMessage('Error loading dashboard data');
      setAlertSeverity('error');
      setAlertOpen(true);
    } finally {
      if (showLoading) {
        setLoading(false);
      } else {
        setRefreshing(false);
      }
    }
  };

  // Update dashboard data with real-time updates
  const updateDashboardData = (newData) => {
    if (!dashboardData) return;
    
    // Merge new data with existing data
    setDashboardData(prevData => ({
      ...prevData,
      ...newData,
    }));
    
    setAlertMessage('Dashboard data updated in real-time');
    setAlertSeverity('info');
    setAlertOpen(true);
  };

  // Handle tab change
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  // Handle time range change
  const handleTimeRangeChange = (event) => {
    setTimeRange(event.target.value);
  };

  // Handle manual refresh
  const handleRefresh = () => {
    fetchDashboardData(false);
  };

  // Handle alert close
  const handleAlertClose = () => {
    setAlertOpen(false);
  };

  // Handle report generation
  const handleGenerateReport = (format) => {
    if (!availableActions.includes('export')) {
      setAlertMessage('You do not have permission to export reports');
      setAlertSeverity('warning');
      setAlertOpen(true);
      return;
    }
    
    setAlertMessage(`Generating ${format} report...`);
    setAlertSeverity('info');
    setAlertOpen(true);
    
    // In a real implementation, this would call an API to generate the report
    setTimeout(() => {
      setAlertMessage(`${format.toUpperCase()} report generated successfully`);
      setAlertSeverity('success');
      setAlertOpen(true);
    }, 2000);
  };

  // Toggle drawer for mobile view
  const toggleDrawer = () => {
    setDrawerOpen(!drawerOpen);
  };

  // Render loading state
  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
        <Typography variant="h6" sx={{ ml: 2 }}>
          Loading Analytics Dashboard...
        </Typography>
      </Box>
    );
  }

  // Render error state
  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <Alert severity="error" sx={{ width: '80%' }}>
          {error}
          <Button color="inherit" size="small" onClick={() => fetchDashboardData()}>
            Retry
          </Button>
        </Alert>
      </Box>
    );
  }

  // Render mobile navigation drawer
  const renderMobileDrawer = () => (
    <Drawer
      anchor="left"
      open={drawerOpen}
      onClose={toggleDrawer}
    >
      <Box
        sx={{ width: 250 }}
        role="presentation"
        onClick={toggleDrawer}
      >
        <List>
          <ListItem>
            <Typography variant="h6">Analytics Dashboard</Typography>
          </ListItem>
          <Divider />
          {availableTabs.map((tab, index) => (
            <ListItem 
              button 
              key={tab.id}
              selected={activeTab === index}
              onClick={() => setActiveTab(index)}
            >
              <ListItemIcon>
                {tab.icon}
              </ListItemIcon>
              <ListItemText primary={tab.label} />
            </ListItem>
          ))}
        </List>
        <Divider />
        <List>
          <ListItem>
            <FormControl variant="outlined" size="small" fullWidth>
              <InputLabel>Time Range</InputLabel>
              <Select
                value={timeRange}
                onChange={handleTimeRangeChange}
                label="Time Range"
              >
                <MenuItem value="day">Today</MenuItem>
                <MenuItem value="week">This Week</MenuItem>
                <MenuItem value="month">This Month</MenuItem>
                <MenuItem value="quarter">This Quarter</MenuItem>
              </Select>
            </FormControl>
          </ListItem>
          <ListItem>
            <Button 
              variant="outlined" 
              startIcon={<RefreshIcon />} 
              onClick={handleRefresh}
              disabled={refreshing}
              fullWidth
            >
              {refreshing ? 'Refreshing...' : 'Refresh'}
            </Button>
          </ListItem>
          {availableActions.includes('export') && (
            <>
              <ListItem>
                <Button 
                  variant="outlined" 
                  startIcon={<DownloadIcon />}
                  onClick={() => handleGenerateReport('pdf')}
                  fullWidth
                >
                  Export PDF
                </Button>
              </ListItem>
              <ListItem>
                <Button 
                  variant="outlined" 
                  startIcon={<DownloadIcon />}
                  onClick={() => handleGenerateReport('csv')}
                  fullWidth
                >
                  Export CSV
                </Button>
              </ListItem>
            </>
          )}
        </List>
      </Box>
    </Drawer>
  );

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      {/* Dashboard Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        {isMobile ? (
          <>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              edge="start"
              onClick={toggleDrawer}
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h5" component="h1">
              Analytics
            </Typography>
            {renderMobileDrawer()}
          </>
        ) : (
          <>
            <Typography variant="h4" component="h1" gutterBottom>
              Analytics Dashboard
            </Typography>
            
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <FormControl variant="outlined" size="small" sx={{ minWidth: 120, mr: 2 }}>
                <InputLabel>Time Range</InputLabel>
                <Select
                  value={timeRange}
                  onChange={handleTimeRangeChange}
                  label="Time Range"
                >
                  <MenuItem value="day">Today</MenuItem>
                  <MenuItem value="week">This Week</MenuItem>
                  <MenuItem value="month">This Month</MenuItem>
                  <MenuItem value="quarter">This Quarter</MenuItem>
                </Select>
              </FormControl>
              
              <Button 
                variant="outlined" 
                startIcon={<RefreshIcon />} 
                onClick={handleRefresh}
                disabled={refreshing}
                sx={{ mr: 2 }}
              >
                {refreshing ? 'Refreshing...' : 'Refresh'}
              </Button>
              
              {availableActions.includes('export') && (
                <>
                  <Button 
                    variant="outlined" 
                    startIcon={<DownloadIcon />}
                    onClick={() => handleGenerateReport('pdf')}
                    sx={{ mr: 2 }}
                  >
                    Export PDF
                  </Button>
                  
                  <Button 
                    variant="outlined" 
                    startIcon={<DownloadIcon />}
                    onClick={() => handleGenerateReport('csv')}
                  >
                    Export CSV
                  </Button>
                </>
              )}
            </Box>
          </>
        )}
      </Box>

      {/* Dashboard Tabs - Only show on non-mobile */}
      {!isMobile && (
        <Paper sx={{ mb: 3 }}>
          <Tabs
            value={activeTab}
            onChange={handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            variant={isTablet ? "scrollable" : "fullWidth"}
            scrollButtons={isTablet ? "auto" : false}
          >
            {availableTabs.map(tab => (
              <Tab key={tab.id} label={tab.labe
(Content truncated due to size limit. Use line ranges to read in chunks)
import { Injectable, Logger } from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { DistributionConsumerService } from '../services/distribution-consumer.service';
import { EmailDistributorService } from '../../channel-integration/providers/email-distributor.service';

/**
 * Consumer for email distribution messages from RabbitMQ
 */
@Injectable()
export class EmailDistributionConsumer {
  private readonly logger = new Logger(EmailDistributionConsumer.name);
  private readonly queueName = 'email_distribution';

  constructor(
    private readonly distributionConsumerService: DistributionConsumerService,
    private readonly emailDistributorService: EmailDistributorService,
  ) {}

  /**
   * Process email distribution messages from the queue
   * @param data Distribution data from the queue
   */
  @MessagePattern('email_distribution')
  async processEmailDistribution(@Payload() data: any) {
    const startTime = Date.now();
    this.logger.log(`Processing email distribution: ${JSON.stringify(data)}`);
    
    try {
      // Process the email distribution
      if (data.isTest) {
        this.logger.log('Test message received, simulating processing');
        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 500));
      } else {
        // Actual email distribution logic
        await this.emailDistributorService.sendEmail(data);
      }
      
      // Record successful processing
      const processingTime = Date.now() - startTime;
      this.distributionConsumerService.recordMessageProcessed(this.queueName, processingTime);
      
      return { success: true, processingTime };
    } catch (error) {
      // Record processing error
      this.distributionConsumerService.recordProcessingError(this.queueName, error);
      
      // Return error response
      return { 
        success: false, 
        error: error.message,
        processingTime: Date.now() - startTime
      };
    }
  }

  /**
   * Handle ping messages to check queue availability
   * @param data Ping data
   */
  @MessagePattern('email_distribution.ping')
  handlePing(@Payload() data: any) {
    this.logger.debug(`Received ping: ${JSON.stringify(data)}`);
    return { 
      pong: true, 
      timestamp: Date.now(),
      originalTimestamp: data.timestamp
    };
  }
}

import { Injectable, Logger } from '@nestjs/common';
import { RabbitMQService } from '../../queue/services/rabbitmq.service';
import { QueueHealthService } from '../../queue/services/queue-health.service';
import { AnalyticsDataService } from './analytics-data.service';
import { ReportingService } from './reporting.service';
import { AlertService } from './alert.service';
import { Cron, CronExpression } from '@nestjs/schedule';

/**
 * Core service for analytics dashboard functionality
 * Coordinates data collection, processing, and access for dashboard visualizations
 */
@Injectable()
export class AnalyticsService {
  private readonly logger = new Logger(AnalyticsService.name);
  
  // Cache for analytics data to improve dashboard performance
  private analyticsCache = {
    distributionMetrics: null,
    followUpMetrics: null,
    systemPerformance: null,
    templatePerformance: null,
    lastUpdated: {
      distributionMetrics: null,
      followUpMetrics: null,
      systemPerformance: null,
      templatePerformance: null,
    },
    // Cache TTL in milliseconds (5 minutes)
    cacheTTL: 5 * 60 * 1000,
  };

  constructor(
    private readonly rabbitMQService: RabbitMQService,
    private readonly queueHealthService: QueueHealthService,
    private readonly analyticsDataService: AnalyticsDataService,
    private readonly reportingService: ReportingService,
    private readonly alertService: AlertService,
  ) {}

  /**
   * Get comprehensive dashboard data including all metrics
   * @returns Complete dashboard data object
   */
  async getDashboardData() {
    this.logger.log('Retrieving complete dashboard data');
    
    return {
      distributionMetrics: await this.getDistributionMetrics(),
      followUpMetrics: await this.getFollowUpMetrics(),
      systemPerformance: await this.getSystemPerformanceMetrics(),
      templatePerformance: await this.getTemplatePerformanceMetrics(),
      queueHealth: this.getQueueHealthMetrics(),
    };
  }

  /**
   * Get distribution metrics across all channels
   * @param forceRefresh Whether to bypass cache and force data refresh
   * @returns Distribution metrics data
   */
  async getDistributionMetrics(forceRefresh = false) {
    const cacheKey = 'distributionMetrics';
    
    if (!forceRefresh && this.isCacheValid(cacheKey)) {
      return this.analyticsCache[cacheKey];
    }
    
    this.logger.log('Collecting distribution metrics data');
    const metrics = await this.analyticsDataService.collectDistributionMetrics();
    
    // Update cache
    this.analyticsCache[cacheKey] = metrics;
    this.analyticsCache.lastUpdated[cacheKey] = new Date();
    
    return metrics;
  }

  /**
   * Get follow-up effectiveness metrics
   * @param forceRefresh Whether to bypass cache and force data refresh
   * @returns Follow-up metrics data
   */
  async getFollowUpMetrics(forceRefresh = false) {
    const cacheKey = 'followUpMetrics';
    
    if (!forceRefresh && this.isCacheValid(cacheKey)) {
      return this.analyticsCache[cacheKey];
    }
    
    this.logger.log('Collecting follow-up metrics data');
    const metrics = await this.analyticsDataService.collectFollowUpMetrics();
    
    // Update cache
    this.analyticsCache[cacheKey] = metrics;
    this.analyticsCache.lastUpdated[cacheKey] = new Date();
    
    return metrics;
  }

  /**
   * Get system performance metrics
   * @param forceRefresh Whether to bypass cache and force data refresh
   * @returns System performance metrics data
   */
  async getSystemPerformanceMetrics(forceRefresh = false) {
    const cacheKey = 'systemPerformance';
    
    if (!forceRefresh && this.isCacheValid(cacheKey)) {
      return this.analyticsCache[cacheKey];
    }
    
    this.logger.log('Collecting system performance metrics');
    const metrics = await this.analyticsDataService.collectSystemPerformanceMetrics();
    
    // Update cache
    this.analyticsCache[cacheKey] = metrics;
    this.analyticsCache.lastUpdated[cacheKey] = new Date();
    
    return metrics;
  }

  /**
   * Get template performance comparison metrics
   * @param forceRefresh Whether to bypass cache and force data refresh
   * @returns Template performance metrics data
   */
  async getTemplatePerformanceMetrics(forceRefresh = false) {
    const cacheKey = 'templatePerformance';
    
    if (!forceRefresh && this.isCacheValid(cacheKey)) {
      return this.analyticsCache[cacheKey];
    }
    
    this.logger.log('Collecting template performance metrics');
    const metrics = await this.analyticsDataService.collectTemplatePerformanceMetrics();
    
    // Update cache
    this.analyticsCache[cacheKey] = metrics;
    this.analyticsCache.lastUpdated[cacheKey] = new Date();
    
    return metrics;
  }

  /**
   * Get real-time queue health metrics
   * @returns Queue health metrics
   */
  getQueueHealthMetrics() {
    // This data is always retrieved in real-time, no caching
    return this.queueHealthService.getHealthMetrics();
  }

  /**
   * Generate a comprehensive analytics report
   * @param reportType Type of report to generate
   * @param dateRange Date range for the report
   * @param format Output format (PDF, CSV, Excel)
   * @returns Report data or file path
   */
  async generateReport(reportType: string, dateRange: any, format: string) {
    this.logger.log(`Generating ${reportType} report in ${format} format`);
    
    // Collect all necessary data for the report
    const reportData = {
      distributionMetrics: await this.getDistributionMetrics(true),
      followUpMetrics: await this.getFollowUpMetrics(true),
      systemPerformance: await this.getSystemPerformanceMetrics(true),
      templatePerformance: await this.getTemplatePerformanceMetrics(true),
      queueHealth: this.getQueueHealthMetrics(),
      dateRange,
      generatedAt: new Date(),
    };
    
    // Generate the report using the reporting service
    return this.reportingService.generateReport(reportType, reportData, format);
  }

  /**
   * Check for anomalies in system performance and distribution metrics
   * @returns Detected anomalies if any
   */
  async checkForAnomalies() {
    this.logger.log('Checking for anomalies in system performance');
    
    const systemMetrics = await this.getSystemPerformanceMetrics(true);
    const distributionMetrics = await this.getDistributionMetrics(true);
    const queueHealth = this.getQueueHealthMetrics();
    
    return this.alertService.detectAnomalies(systemMetrics, distributionMetrics, queueHealth);
  }

  /**
   * Scheduled job to refresh analytics cache periodically
   */
  @Cron(CronExpression.EVERY_10_MINUTES)
  async refreshAnalyticsCache() {
    this.logger.log('Refreshing analytics cache');
    
    try {
      await this.getDistributionMetrics(true);
      await this.getFollowUpMetrics(true);
      await this.getSystemPerformanceMetrics(true);
      await this.getTemplatePerformanceMetrics(true);
      
      this.logger.log('Analytics cache refresh completed');
    } catch (error) {
      this.logger.error(`Error refreshing analytics cache: ${error.message}`, error.stack);
    }
  }

  /**
   * Scheduled job to check for anomalies and trigger alerts
   */
  @Cron(CronExpression.EVERY_HOUR)
  async scheduledAnomalyCheck() {
    this.logger.log('Running scheduled anomaly check');
    
    try {
      const anomalies = await this.checkForAnomalies();
      
      if (anomalies && anomalies.length > 0) {
        this.logger.warn(`Detected ${anomalies.length} anomalies`);
        await this.alertService.triggerAlerts(anomalies);
      } else {
        this.logger.log('No anomalies detected');
      }
    } catch (error) {
      this.logger.error(`Error in scheduled anomaly check: ${error.message}`, error.stack);
    }
  }

  /**
   * Check if cached data is still valid
   * @param cacheKey Key of the cached data to check
   * @returns Whether the cache is still valid
   */
  private isCacheValid(cacheKey: string): boolean {
    const lastUpdated = this.analyticsCache.lastUpdated[cacheKey];
    
    if (!lastUpdated) {
      return false;
    }
    
    const now = new Date();
    const cacheAge = now.getTime() - lastUpdated.getTime();
    
    return cacheAge < this.analyticsCache.cacheTTL;
  }
}

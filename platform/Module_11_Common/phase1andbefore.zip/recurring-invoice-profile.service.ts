import { Injectable, NotFoundException, BadRequestException, InternalServerErrorException, Logger } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { RecurringInvoiceProfile, RecurringStatus, RecurringFrequency } from "../entities/recurring-invoice-profile.entity";
import { CreateRecurringInvoiceProfileDto, UpdateRecurringInvoiceProfileDto } from "../dto/recurring-invoice-profile.dto";
import { InvoiceService } from "../../invoices/services/invoice.service";
import { CreateInvoiceDto } from "../../invoices/dto/invoice.dto";

@Injectable()
export class RecurringInvoiceProfileService {
  private readonly logger = new Logger(RecurringInvoiceProfileService.name);

  constructor(
    @InjectRepository(RecurringInvoiceProfile)
    private readonly profileRepository: Repository<RecurringInvoiceProfile>,
    private readonly invoiceService: InvoiceService,
  ) {}

  private calculateNextRunDate(startDate: Date, frequency: RecurringFrequency): Date {
    const nextDate = new Date(startDate);
    switch (frequency) {
      case RecurringFrequency.DAILY:
        nextDate.setDate(nextDate.getDate() + 1);
        break;
      case RecurringFrequency.WEEKLY:
        nextDate.setDate(nextDate.getDate() + 7);
        break;
      case RecurringFrequency.MONTHLY:
        nextDate.setMonth(nextDate.getMonth() + 1);
        break;
      case RecurringFrequency.QUARTERLY:
        nextDate.setMonth(nextDate.getMonth() + 3);
        break;
      case RecurringFrequency.YEARLY:
        nextDate.setFullYear(nextDate.getFullYear() + 1);
        break;
      default:
        throw new BadRequestException("Invalid recurring frequency");
    }
    return nextDate;
  }

  async create(createDto: CreateRecurringInvoiceProfileDto): Promise<RecurringInvoiceProfile> {
    try {
      const startDate = new Date(createDto.start_date);
      const endDate = createDto.end_date ? new Date(createDto.end_date) : undefined;
      const { next_run_date: nextRunDateString, ...restOfCreateDto } = createDto;

      const profileData: Partial<RecurringInvoiceProfile> = {
        ...restOfCreateDto,
        start_date: startDate,
        end_date: endDate,
      };

      if (!nextRunDateString) {
        profileData.next_run_date = this.calculateNextRunDate(startDate, createDto.frequency);
      } else {
        profileData.next_run_date = new Date(nextRunDateString);
      }

      const newProfile = this.profileRepository.create(profileData as RecurringInvoiceProfile);
      return await this.profileRepository.save(newProfile);
    } catch (error) {
      this.logger.error("Error creating recurring invoice profile:", error.message, error.stack);
      throw new InternalServerErrorException("Could not create recurring profile. " + error.message);
    }
  }

  async findAll(tenant_id: string): Promise<RecurringInvoiceProfile[]> {
    return this.profileRepository.find({ where: { tenant_id }, relations: ["source_invoice"] });
  }

  async findOne(id: string, tenant_id: string): Promise<RecurringInvoiceProfile> {
    const profile = await this.profileRepository.findOne({ where: { id, tenant_id }, relations: ["source_invoice"] });
    if (!profile) {
      throw new NotFoundException(`Recurring profile with ID "${id}" not found for this tenant.`);
    }
    return profile;
  }

  async update(id: string, updateDto: UpdateRecurringInvoiceProfileDto, tenant_id: string): Promise<RecurringInvoiceProfile> {
    const profile = await this.findOne(id, tenant_id);

    const updateData: Partial<RecurringInvoiceProfile> = {};

    for (const key in updateDto) {
      if (Object.prototype.hasOwnProperty.call(updateDto, key)) {
        const value = updateDto[key as keyof UpdateRecurringInvoiceProfileDto];
        if (key === 'start_date' || key === 'next_run_date') {
          if (value && typeof value === 'string') {
            (updateData as any)[key] = new Date(value);
          } else if (value === null && (key === 'next_run_date')) {
             (updateData as any)[key] = undefined; 
          }
        } else if (key === 'end_date') {
          if (value && typeof value === 'string') {
            (updateData as any)[key] = new Date(value);
          } else if (value === null) { 
            (updateData as any)[key] = undefined;
          }
        } else if (value !== undefined) { 
          (updateData as any)[key] = value;
        }
      }
    }

    this.profileRepository.merge(profile, updateData);
    try {
      return await this.profileRepository.save(profile);
    } catch (error) {
      this.logger.error(`Error updating recurring invoice profile ${id}:`, error.message, error.stack);
      throw new InternalServerErrorException(`Could not update recurring profile ${id}. ` + error.message);
    }
  }

  async remove(id: string, tenant_id: string): Promise<void> {
    const profile = await this.findOne(id, tenant_id);
    await this.profileRepository.remove(profile);
  }

  async processDueProfiles(): Promise<void> {
    const now = new Date();
    const dueProfiles = await this.profileRepository.createQueryBuilder("profile")
      .where("profile.status = :status", { status: RecurringStatus.ACTIVE })
      .andWhere("profile.next_run_date <= :now", { now })
      .andWhere("(profile.end_date IS NULL OR profile.end_date >= :now)", { now })
      .getMany();

    for (const profile of dueProfiles) {
      try {
        if (!profile.invoice_data) {
          this.logger.warn(`Profile ${profile.id} has no invoice_data, skipping.`);
          continue;
        }

        const invoiceToCreate: CreateInvoiceDto = {
          ...(profile.invoice_data as Omit<CreateInvoiceDto, 'tenant_id' | 'client_id' | 'issue_date'>),
          tenant_id: profile.tenant_id,
          client_id: profile.client_id,
          issue_date: profile.next_run_date.toISOString().split("T")[0],
        };
        
        delete (invoiceToCreate as any).id;
        if (invoiceToCreate.line_items) {
            invoiceToCreate.line_items.forEach(item => delete (item as any).id);
        }

        await this.invoiceService.create(invoiceToCreate);

        profile.next_run_date = this.calculateNextRunDate(profile.next_run_date, profile.frequency);
        if (profile.end_date && profile.next_run_date > profile.end_date) {
          profile.status = RecurringStatus.COMPLETED;
        }
        await this.profileRepository.save(profile);
        this.logger.log(`Processed recurring profile ${profile.id}, generated invoice.`);

      } catch (error) {
        this.logger.error(`Error processing recurring profile ${profile.id}:`, error.message, error.stack);
      }
    }
  }
}


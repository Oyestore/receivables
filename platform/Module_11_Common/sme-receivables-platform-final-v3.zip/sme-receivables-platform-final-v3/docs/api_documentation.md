# API Documentation - SME Receivables Management Platform

## Introduction

This document provides comprehensive documentation for the SME Receivables Management Platform API. The API follows RESTful principles and uses JSON for data exchange. All endpoints are secured using JWT authentication except for the authentication endpoints.

## Base URL

```
https://your-domain.com/api
```

## Authentication

### Obtain JWT Token

```
POST /auth/login
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "your_password"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "role": "manager",
    "tenant_id": "123e4567-e89b-12d3-a456-426614174001"
  }
}
```

### Using Authentication

Include the JWT token in the Authorization header for all protected endpoints:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Refresh Token

```
POST /auth/refresh
```

**Request Headers:**
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "role": "manager",
    "tenant_id": "123e4567-e89b-12d3-a456-426614174001"
  }
}
```

## User Management

### Get Current User

```
GET /users/me
```

**Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "role": "manager",
  "tenant_id": "123e4567-e89b-12d3-a456-426614174001",
  "created_at": "2025-01-01T00:00:00.000Z",
  "updated_at": "2025-01-01T00:00:00.000Z"
}
```

### List Users

```
GET /users
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `role` (optional): Filter by role
- `search` (optional): Search by name or email

**Response:**
```json
{
  "data": [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "email": "user@example.com",
      "first_name": "John",
      "last_name": "Doe",
      "role": "manager",
      "status": "active",
      "created_at": "2025-01-01T00:00:00.000Z"
    },
    {
      "id": "223e4567-e89b-12d3-a456-426614174000",
      "email": "user2@example.com",
      "first_name": "Jane",
      "last_name": "Smith",
      "role": "user",
      "status": "active",
      "created_at": "2025-01-02T00:00:00.000Z"
    }
  ],
  "pagination": {
    "total": 25,
    "page": 1,
    "limit": 10,
    "pages": 3
  }
}
```

### Create User

```
POST /users
```

**Request Body:**
```json
{
  "email": "newuser@example.com",
  "password": "secure_password",
  "first_name": "New",
  "last_name": "User",
  "role": "user"
}
```

**Response:**
```json
{
  "id": "323e4567-e89b-12d3-a456-426614174000",
  "email": "newuser@example.com",
  "first_name": "New",
  "last_name": "User",
  "role": "user",
  "status": "active",
  "created_at": "2025-04-23T00:00:00.000Z"
}
```

### Get User by ID

```
GET /users/:id
```

**Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "role": "manager",
  "status": "active",
  "created_at": "2025-01-01T00:00:00.000Z",
  "updated_at": "2025-01-01T00:00:00.000Z"
}
```

### Update User

```
PUT /users/:id
```

**Request Body:**
```json
{
  "first_name": "Updated",
  "last_name": "Name",
  "role": "admin"
}
```

**Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "email": "user@example.com",
  "first_name": "Updated",
  "last_name": "Name",
  "role": "admin",
  "status": "active",
  "created_at": "2025-01-01T00:00:00.000Z",
  "updated_at": "2025-04-23T00:00:00.000Z"
}
```

### Delete User

```
DELETE /users/:id
```

**Response:**
```json
{
  "message": "User deleted successfully"
}
```

## Organization Management

### List Organizations

```
GET /organizations
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `type` (optional): Filter by type (sme, buyer)
- `search` (optional): Search by name or tax ID

**Response:**
```json
{
  "data": [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "name": "ABC Corporation",
      "type": "sme",
      "tax_id": "ABCDE1234F",
      "status": "active",
      "city": "Mumbai",
      "state": "Maharashtra",
      "country": "India",
      "created_at": "2025-01-01T00:00:00.000Z"
    },
    {
      "id": "223e4567-e89b-12d3-a456-426614174000",
      "name": "XYZ Enterprises",
      "type": "buyer",
      "tax_id": "XYZAB5678G",
      "status": "active",
      "city": "Delhi",
      "state": "Delhi",
      "country": "India",
      "created_at": "2025-01-02T00:00:00.000Z"
    }
  ],
  "pagination": {
    "total": 25,
    "page": 1,
    "limit": 10,
    "pages": 3
  }
}
```

### Create Organization

```
POST /organizations
```

**Request Body:**
```json
{
  "name": "New Organization",
  "type": "buyer",
  "tax_id": "NEWOR1234H",
  "address": "123 Main Street",
  "city": "Bangalore",
  "state": "Karnataka",
  "postal_code": "560001",
  "country": "India",
  "phone": "+91 9876543210",
  "email": "contact@neworg.com",
  "website": "https://neworg.com"
}
```

**Response:**
```json
{
  "id": "323e4567-e89b-12d3-a456-426614174000",
  "name": "New Organization",
  "type": "buyer",
  "tax_id": "NEWOR1234H",
  "address": "123 Main Street",
  "city": "Bangalore",
  "state": "Karnataka",
  "postal_code": "560001",
  "country": "India",
  "phone": "+91 9876543210",
  "email": "contact@neworg.com",
  "website": "https://neworg.com",
  "status": "active",
  "created_at": "2025-04-23T00:00:00.000Z"
}
```

### Get Organization by ID

```
GET /organizations/:id
```

**Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "name": "ABC Corporation",
  "type": "sme",
  "tax_id": "ABCDE1234F",
  "address": "456 Business Park",
  "city": "Mumbai",
  "state": "Maharashtra",
  "postal_code": "400001",
  "country": "India",
  "phone": "+91 9876543210",
  "email": "contact@abc.com",
  "website": "https://abc.com",
  "status": "active",
  "created_at": "2025-01-01T00:00:00.000Z",
  "updated_at": "2025-01-01T00:00:00.000Z"
}
```

### Update Organization

```
PUT /organizations/:id
```

**Request Body:**
```json
{
  "name": "Updated Organization Name",
  "phone": "+91 9876543211",
  "email": "new-contact@abc.com"
}
```

**Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "name": "Updated Organization Name",
  "type": "sme",
  "tax_id": "ABCDE1234F",
  "address": "456 Business Park",
  "city": "Mumbai",
  "state": "Maharashtra",
  "postal_code": "400001",
  "country": "India",
  "phone": "+91 9876543211",
  "email": "new-contact@abc.com",
  "website": "https://abc.com",
  "status": "active",
  "created_at": "2025-01-01T00:00:00.000Z",
  "updated_at": "2025-04-23T00:00:00.000Z"
}
```

### Delete Organization

```
DELETE /organizations/:id
```

**Response:**
```json
{
  "message": "Organization deleted successfully"
}
```

## Invoice Management

### List Invoices

```
GET /invoices
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `status` (optional): Filter by status (draft, sent, paid, overdue, etc.)
- `sme_id` (optional): Filter by SME organization ID
- `buyer_id` (optional): Filter by buyer organization ID
- `start_date` (optional): Filter by issue date range start
- `end_date` (optional): Filter by issue date range end

**Response:**
```json
{
  "data": [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "invoice_number": "INV-2025-001",
      "sme_id": "123e4567-e89b-12d3-a456-426614174000",
      "sme_name": "ABC Corporation",
      "buyer_id": "223e4567-e89b-12d3-a456-426614174000",
      "buyer_name": "XYZ Enterprises",
      "amount": 10000.00,
      "currency": "INR",
      "status": "sent",
      "issue_date": "2025-04-01",
      "due_date": "2025-05-01",
      "created_at": "2025-04-01T00:00:00.000Z"
    },
    {
      "id": "223e4567-e89b-12d3-a456-426614174000",
      "invoice_number": "INV-2025-002",
      "sme_id": "123e4567-e89b-12d3-a456-426614174000",
      "sme_name": "ABC Corporation",
      "buyer_id": "323e4567-e89b-12d3-a456-426614174000",
      "buyer_name": "New Organization",
      "amount": 15000.00,
      "currency": "INR",
      "status": "draft",
      "issue_date": "2025-04-15",
      "due_date": "2025-05-15",
      "created_at": "2025-04-15T00:00:00.000Z"
    }
  ],
  "pagination": {
    "total": 25,
    "page": 1,
    "limit": 10,
    "pages": 3
  }
}
```

### Create Invoice

```
POST /invoices
```

**Request Body:**
```json
{
  "invoice_number": "INV-2025-003",
  "sme_id": "123e4567-e89b-12d3-a456-426614174000",
  "buyer_id": "223e4567-e89b-12d3-a456-426614174000",
  "amount": 20000.00,
  "currency": "INR",
  "issue_date": "2025-04-23",
  "due_date": "2025-05-23",
  "payment_terms": "Net 30",
  "description": "Consulting services",
  "line_items": [
    {
      "description": "Service A",
      "quantity": 10,
      "unit_price": 1000.00,
      "amount": 10000.00
    },
    {
      "description": "Service B",
      "quantity": 5,
      "unit_price": 2000.00,
      "amount": 10000.00
    }
  ],
  "notes": "Thank you for your business"
}
```

**Response:**
```json
{
  "id": "323e4567-e89b-12d3-a456-426614174000",
  "invoice_number": "INV-2025-003",
  "sme_id": "123e4567-e89b-12d3-a456-426614174000",
  "sme_name": "ABC Corporation",
  "buyer_id": "223e4567-e89b-12d3-a456-426614174000",
  "buyer_name": "XYZ Enterprises",
  "amount": 20000.00,
  "currency": "INR",
  "status": "draft",
  "issue_date": "2025-04-23",
  "due_date": "2025-05-23",
  "payment_terms": "Net 30",
  "description": "Consulting services",
  "line_items": [
    {
      "description": "Service A",
      "quantity": 10,
      "unit_price": 1000.00,
      "amount": 10000.00
    },
    {
      "description": "Service B",
      "quantity": 5,
      "unit_price": 2000.00,
      "amount": 10000.00
    }
  ],
  "notes": "Thank you for your business",
  "created_at": "2025-04-23T00:00:00.000Z"
}
```

### Get Invoice by ID

```
GET /invoices/:id
```

**Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "invoice_number": "INV-2025-001",
  "sme_id": "123e4567-e89b-12d3-a456-426614174000",
  "sme_name": "ABC Corporation",
  "sme_details": {
    "tax_id": "ABCDE1234F",
    "address": "456 Business Park",
    "city": "Mumbai",
    "state": "Maharashtra",
    "postal_code": "400001",
    "country": "India",
    "phone": "+91 9876543210",
    "email": "contact@abc.com"
  },
  "buyer_id": "223e4567-e89b-12d3-a456-426614174000",
  "buyer_name": "XYZ Enterprises",
  "buyer_details": {
    "tax_id": "XYZAB5678G",
    "address": "789 Corporate Tower",
    "city": "Delhi",
    "state": "Delhi",
    "postal_code": "110001",
    "country": "India",
    "phone": "+91 9876543220",
    "email": "contact@xyz.com"
  },
  "amount": 10000.00,
  "currency": "INR",
  "status": "sent",
  "issue_date": "2025-04-01",
  "due_date": "2025-05-01",
  "payment_terms": "Net 30",
  "description": "IT Services",
  "line_items": [
    {
      "description": "Web Development",
      "quantity": 1,
      "unit_price": 10000.00,
      "amount": 10000.00
    }
  ],
  "notes": "Thank you for your business",
  "created_at": "2025-04-01T00:00:00.000Z",
  "updated_at": "2025-04-01T00:00:00.000Z",
  "history": [
    {
      "action": "created",
      "timestamp": "2025-04-01T00:00:00.000Z",
      "user_id": "123e4567-e89b-12d3-a456-426614174000",
      "user_name": "John Doe"
    },
    {
      "action": "sent",
      "timestamp": "2025-04-01T01:00:00.000Z",
      "user_id": "123e4567-e89b-12d3-a456-426614174000",
      "user_name": "John Doe"
    }
  ]
}
```

### Update Invoice

```
PUT /invoices/:id
```

**Request Body:**
```json
{
  "amount": 12000.00,
  "due_date": "2025-05-15",
  "line_items": [
    {
      "description": "Web Development",
      "quantity": 1,
      "unit_price": 12000.00,
      "amount": 12000.00
    }
  ],
  "notes": "Updated: Thank you for your business"
}
```

**Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "invoice_number": "INV-2025-001",
  "sme_id": "123e4567-e89b-12d3-a456-426614174000",
  "sme_name": "ABC Corporation",
  "buyer_id": "223e4567-e89b-12d3-a456-426614174000",
  "buyer_name": "XYZ Enterprises",
  "amount": 12000.00,
  "currency": "INR",
  "status": "sent",
  "issue_date": "2025-04-01",
  "due_date": "2025-05-15",
  "payment_terms": "Net 30",
  "description": "IT Services",
  "line_items": [
    {
      "description": "Web Development",
      "quantity": 1,
      "unit_price": 12000.00,
      "amount": 12000.00
    }
  ],
  "notes": "Updated: Thank you for your business",
  "created_at": "2025-04-01T00:00:00.000Z",
  "updated_at": "2025-04-23T00:00:00.000Z"
}
```

### Delete Invoice

```
DELETE /invoices/:id
```

**Response:**
```json
{
  "message": "Invoice deleted successfully"
}
```

### Send Invoice

```
POST /invoices/:id/send
```

**Request Body:**
```json
{
  "email_recipients": ["buyer@example.com", "accounts@example.com"],
  "message": "Please find attached invoice for recent services."
}
```

**Response:**
```json
{
  "message": "Invoice sent successfully",
  "invoice": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "status": "sent",
    "updated_at": "2025-04-23T00:00:00.000Z"
  }
}
```

### Record Payment

```
POST /invoices/:id/payments
```

**Request Body:**
```json
{
  "amount": 10000.00,
  "payment_date": "2025-04-20",
  "payment_method": "bank_transfer",
  "reference_number": "TRX123456",
  "notes": "Full payment received"
}
```

**Response:**
```json
{
  "id": "423e4567-e89b-12d3-a456-426614174000",
  "invoice_id": "123e4567-e89b-12d3-a456-426614174000",
  "amount": 10000.00,
  "payment_date": "2025-04-20",
  "payment_method": "bank_transfer",
  "reference_number": "TRX123456",
  "notes": "Full payment received",
  "created_at": "2025-04-23T00:00:00.000Z",
  "invoice": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "status": "paid",
    "updated_at": "2025-04-23T00:00:00.000Z"
  }
}
```

## Analytics and Reporting

### Get Dashboard Summary

```
GET /analytics/dashboard
```

**Response:**
```json
{
  "total_outstanding": 150000.00,
  "total_overdue": 50000.00,
  "average_days_to_payment": 35,
  "invoices_by_status": {
    "draft": 5,
    "sent": 15,
    "partially_paid": 3,
    "paid": 20,
    "overdue": 7
  },
  "monthly_invoices": [
    {
      "month": "2025-01",
      "amount": 80000.00,
      "count": 8
    },
    {
      "month": "2025-02",
      "amount": 95000.00,
      "count": 10
    },
    {
      "month": "2025-03",
      "amount": 110000.00,
      "count": 12
    },
    {
      "month": "2025-04",
      "amount": 120000.00,
      "count": 15
    }
  ],
  "top_buyers": [
    {
      "id": "223e4567-e89b-12d3-a456-426614174000",
      "name": "XYZ Enterprises",
      "total_amount": 75000.00,
      "invoice_count": 5,
      "average_days_to_payment": 28
    },
    {
      "id": "323e4567-e89b-12d3-a456-426614174000",
      "name": "New Organization",
      "total_amount": 60000.00,
      "invoice_count": 4,
      "average_days_to_payment": 32
    }
  ]
}
```

### Get Aging Report

```
GET /analytics/aging-report
```

**Query Parameters:**
- `as_of_date` (optional): Report date (default: current date)

**Response:**
```json
{
  "as_of_date": "2025-04-23",
  "total_outstanding": 150000.00,
  "aging_buckets": {
    "current": 70000.00,
    "1_30_days": 30000.00,
    "31_60_days": 25000.00,
    "61_90_days": 15000.00,
    "over_90_days": 10000.00
  },
  "invoices": [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "invoice_number": "INV-2025-001",
      "buyer_name": "XYZ Enterprises",
      "amount": 10000.00,
      "due_date": "2025-05-01",
      "days_outstanding": -8,
      "bucket": "current"
    },
    {
      "id": "523e4567-e89b-12d3-a456-426614174000",
      "invoice_number": "INV-2025-005",
      "buyer_name": "ABC Buyer",
      "amount": 5000.00,
      "due_date": "2025-03-15",
      "days_outstanding": 39,
      "bucket": "31_60_days"
    }
  ]
}
```

### Get Cash Flow Forecast

```
GET /analytics/cash-flow-forecast
```

**Query Parameters:**
- `months` (optional): Number of months to forecast (default: 3)

**Response:**
```json
{
  "forecast_date": "2025-04-23",
  "forecast_periods": [
    {
      "period": "2025-04-23 to 2025-05-23",
      "expected_inflow": 80000.00,
      "probability_adjusted_inflow": 72000.00,
      "invoices_count": 8
    },
    {
      "period": "2025-05-24 to 2025-06-23",
      "expected_inflow": 65000.00,
      "probability_adjusted_inflow": 58500.00,
      "invoices_count": 6
    },
    {
      "period": "2025-06-24 to 2025-07-23",
      "expected_inflow": 50000.00,
      "probability_adjusted_inflow": 45000.00,
      "invoices_count": 5
    }
  ],
  "total_expected_inflow": 195000.00,
  "total_probability_adjusted_inflow": 175500.00
}
```

## Health and Monitoring

### Health Check

```
GET /health
```

**Response:**
```json
{
  "status": "ok",
  "version": "1.0.0",
  "timestamp": "2025-04-23T00:00:00.000Z",
  "services": {
    "database": "ok",
    "cache": "ok",
    "storage": "ok"
  }
}
```

### System Metrics

```
GET /metrics
```

**Response:**
```json
{
  "uptime": 86400,
  "memory_usage": {
    "total_memory": 8192,
    "used_memory": 4096,
    "free_memory": 4096
  },
  "request_stats": {
    "total_requests": 15000,
    "requests_per_minute": 10.4,
    "average_response_time": 120
  },
  "database_stats": {
    "connections": 5,
    "active_queries": 2
  }
}
```

## Error Handling

All API errors follow a consistent format:

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": [
      {
        "field": "email",
        "message": "Must be a valid email address"
      },
      {
        "field": "password",
        "message": "Must be at least 6 characters long"
      }
    ]
  }
}
```

### Common Error Codes

- `AUTHENTICATION_ERROR`: Authentication failed
- `AUTHORIZATION_ERROR`: Insufficient permissions
- `VALIDATION_ERROR`: Invalid input data
- `RESOURCE_NOT_FOUND`: Requested resource not found
- `CONFLICT_ERROR`: Resource conflict (e.g., duplicate entry)
- `INTERNAL_SERVER_ERROR`: Unexpected server error

## Rate Limiting

The API implements rate limiting to prevent abuse. Rate limits are applied per API key or IP address.

Rate limit headers are included in all responses:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1619283600
```

When rate limit is exceeded, the API returns a 429 Too Many Requests response.

## Webhooks

The platform can send webhook notifications for various events.

### Configure Webhooks

```
POST /webhooks
```

**Request Body:**
```json
{
  "url": "https://your-server.com/webhook-endpoint",
  "events": ["invoice.created", "invoice.paid", "payment.received"],
  "secret": "your_webhook_secret"
}
```

**Response:**
```json
{
  "id": "623e4567-e89b-12d3-a456-426614174000",
  "url": "https://your-server.com/webhook-endpoint",
  "events": ["invoice.created", "invoice.paid", "payment.received"],
  "created_at": "2025-04-23T00:00:00.000Z"
}
```

### Webhook Payload Format

```json
{
  "id": "webhook_event_id",
  "event": "invoice.created",
  "created_at": "2025-04-23T00:00:00.000Z",
  "data": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "invoice_number": "INV-2025-001",
    "amount": 10000.00,
    "status": "draft"
  }
}
```

### Webhook Signature Verification

Each webhook request includes a signature header:

```
X-Webhook-Signature: t=1619283600,v1=5257a869e7ecebeda32affa62cdca3fa51cad7e77a0e56ff536d0ce8e108d8bd
```

The signature is generated using HMAC SHA-256 with your webhook secret.

## Versioning

The API uses versioning to ensure backward compatibility. The current version is v1.

You can specify the API version in the Accept header:

```
Accept: application/json; version=1
```

## Changelog

### v1.0.0 (2025-04-23)
- Initial release of the API

---

This API documentation is regularly updated. For the latest version, please check the developer portal.

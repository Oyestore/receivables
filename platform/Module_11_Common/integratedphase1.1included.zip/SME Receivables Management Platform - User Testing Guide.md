# SME Receivables Management Platform - User Testing Guide

## Introduction

This document provides a structured approach to testing the SME Receivables Management Platform. It covers key functionalities for different user roles and aims to ensure the platform meets its core requirements, including multi-tenancy, AI-based data pipelines, smart invoice distribution, and workflow customization.

## Pre-requisites

- The application is deployed and accessible via a URL (e.g., `http://<your_server_ip>:8080`).
- Default admin credentials are known (e.g., `admin@demo.com` / `admin123`).
- A modern web browser (Chrome, Firefox recommended).
- Test data (sample SME details, buyer details, invoice information) may be useful.

## Testing Scope

This guide covers:
- Admin User Functionalities
- SME User Functionalities
- Core Platform Features (Multi-tenancy, AI, Smart Invoicing, Workflows)

## User Roles for Testing

1.  **Admin User:** Manages tenants (if applicable), organizations (SMEs and Buyers), users, and platform-wide settings.
2.  **SME User:** Manages their organization's profile, buyers, invoices, payments, and communications.

## User Testing Sequence

This sequence is designed to test the platform progressively. Testers should document any issues, errors, or unexpected behavior with screenshots and steps to reproduce.




### Phase 1: Admin User - Initial Setup and Core Management

**1.1. Admin Login**
    - **Action:** Navigate to the login page.
    - **Screen:** Login Page (Image: `/home/ubuntu/testing_images/login_page.png`)
    - **Functionality to Test:**
        - Enter valid admin email and password.
        - Click "Login".
        - **Expected Outcome:** Successful login, redirected to Admin Dashboard.
        - Enter invalid email/password.
        - **Expected Outcome:** Error message displayed, login fails.
        - Test "Forgot Password" link (if implemented).

**1.2. Admin Dashboard**
    - **Action:** After login, view the Admin Dashboard.
    - **Screen:** Admin Dashboard (Image: `/home/ubuntu/testing_images/admin_dashboard.png`)
    - **Functionality to Test:**
        - Verify key metrics are displayed (e.g., total tenants, total users, total SMEs, total buyers).
        - Check navigation links (e.g., to Organizations, Users, Settings).
        - **Expected Outcome:** Dashboard loads correctly with relevant information and navigation.

**1.3. Organization Management (as Admin)**
    - **1.3.1. View Organizations List**
        - **Action:** Navigate to the Organizations section.
        - **Screen:** Organization List Page (Image: `/home/ubuntu/testing_images/organization_list_page.png`)
        - **Functionality to Test:**
            - List of existing organizations (SMEs and Buyers) is displayed.
            - Pagination (if many organizations).
            - Search/filter functionality for organizations.
            - **Expected Outcome:** Organizations are listed with key details (Name, Type, Status).
    - **1.3.2. Create New SME Organization**
        - **Action:** Click "Create Organization" or similar, select type "SME".
        - **Screen:** Create/Edit Organization Page (Image: `/home/ubuntu/testing_images/organization_form_page.png`)
        - **Functionality to Test:**
            - Fill in all required fields for an SME (Name, Tax ID, Address, Contact Info, etc.).
            - Test input validation (e.g., invalid email format, missing required fields).
            - Save the new SME organization.
            - **Expected Outcome:** SME is created successfully and appears in the Organization List. A new tenant might be implicitly created or linked.
    - **1.3.3. Create New Buyer Organization**
        - **Action:** Click "Create Organization" or similar, select type "Buyer".
        - **Screen:** Create/Edit Organization Page (Image: `/home/ubuntu/testing_images/organization_form_page.png`)
        - **Functionality to Test:**
            - Fill in all required fields for a Buyer.
            - Save the new Buyer organization.
            - **Expected Outcome:** Buyer is created successfully and appears in the Organization List.
    - **1.3.4. Edit Existing Organization**
        - **Action:** Select an existing organization from the list and click "Edit".
        - **Screen:** Create/Edit Organization Page (Image: `/home/ubuntu/testing_images/organization_form_page.png`)
        - **Functionality to Test:**
            - Modify some details of the organization.
            - Save the changes.
            - **Expected Outcome:** Changes are saved and reflected in the Organization List and detail view.
    - **1.3.5. View Organization Details**
        - **Action:** Click on an organization's name or a "View" button.
        - **Screen:** Organization Detail Page (similar to form but read-only or with more details)
        - **Functionality to Test:**
            - All relevant details of the organization are displayed correctly.
            - **Expected Outcome:** Accurate display of organization information.
    - **1.3.6. Deactivate/Activate Organization**
        - **Action:** Change the status of an organization.
        - **Functionality to Test:**
            - Deactivate an active organization.
            - **Expected Outcome:** Organization status changes, and it might be filtered out from active lists or its users might lose access.
            - Activate a deactivated organization.
            - **Expected Outcome:** Organization status changes back to active.

**1.4. User Management (as Admin, for a specific SME/Tenant)**
    - **1.4.1. View Users List (for a selected SME/Tenant)**
        - **Action:** Navigate to Users section (potentially filtered by or within an SME context if multi-tenancy is strict).
        - **Screen:** User List Page (Admin) (Image: `/home/ubuntu/testing_images/user_list_page.png`)
        - **Functionality to Test:**
            - List of users associated with the default/selected tenant/SME.
            - Search/filter functionality for users.
            - **Expected Outcome:** Users are listed with key details (Email, Name, Role, Status).
    - **1.4.2. Create New SME User**
        - **Action:** Click "Create User" or similar.
        - **Screen:** Create/Edit User Page (Admin) (Image: `/home/ubuntu/testing_images/user_form_page.png`)
        - **Functionality to Test:**
            - Fill in user details (Email, First Name, Last Name, Password, Role - e.g., SME Admin, SME Staff).
            - Associate the user with an existing SME organization (Tenant).
            - Test input validation.
            - Save the new user.
            - **Expected Outcome:** User is created successfully and associated with the correct SME. User should receive login credentials or a setup link (if implemented).
    - **1.4.3. Edit Existing User**
        - **Action:** Select a user and click "Edit".
        - **Screen:** Create/Edit User Page (Admin) (Image: `/home/ubuntu/testing_images/user_form_page.png`)
        - **Functionality to Test:**
            - Modify user details (e.g., role, name). Test password reset functionality.
            - Save changes.
            - **Expected Outcome:** Changes are saved and reflected.
    - **1.4.4. Deactivate/Activate User**
        - **Action:** Change the status of a user.
        - **Functionality to Test:**
            - Deactivate an active user.
            - **Expected Outcome:** User status changes, and the user should not be able to log in.
            - Activate a deactivated user.
            - **Expected Outcome:** User status changes, and the user should be able to log in.

**1.5. Admin Profile Management**
    - **Action:** Navigate to Profile/Account Settings.
    - **Screen:** Profile Page (Image: `/home/ubuntu/testing_images/profile_page.png`)
    - **Functionality to Test:**
        - View admin profile details.
        - Update profile information (e.g., name, email - if allowed).
        - Change password.
        - **Expected Outcome:** Profile updates are saved. Password change requires re-login or confirmation.

**1.6. Admin Logout**
    - **Action:** Click the "Logout" button.
    - **Functionality to Test:**
        - **Expected Outcome:** User is logged out and redirected to the Login Page. Session is terminated.

### Phase 2: SME User - Core Receivables Management

**(Assumption: An SME organization and an SME user have been created by the Admin in Phase 1. The SME user will now log in.)**

**2.1. SME User Login**
    - **Action:** Navigate to the login page.
    - **Screen:** Login Page (Image: `/home/ubuntu/testing_images/login_page.png`)
    - **Functionality to Test:**
        - Enter valid SME user email and password.
        - Click "Login".
        - **Expected Outcome:** Successful login, redirected to SME Dashboard. Access should be restricted to their own SME's data (multi-tenancy test).

**2.2. SME Dashboard**
    - **Action:** After login, view the SME Dashboard.
    - **Screen:** SME Dashboard (Image: `/home/ubuntu/testing_images/sme_dashboard.png`)
    - **Functionality to Test:**
        - Verify key metrics for the SME (e.g., total outstanding invoices, overdue amount, recent payments).
        - Check navigation links (e.g., to Invoices, Buyers, Payments, Reports).
        - **Expected Outcome:** Dashboard loads correctly with SME-specific data.

**2.3. Buyer Management (as SME User)**
    - **2.3.1. View Buyers List**
        - **Action:** Navigate to the Buyers/Customers section.
        - **Screen:** Organization List Page (filtered for Buyers associated with the SME) (Image: `/home/ubuntu/testing_images/organization_list_page.png`)
        - **Functionality to Test:**
            - List of buyers associated with the logged-in SME.
            - **Expected Outcome:** Only buyers linked to this SME are visible.
    - **2.3.2. Add New Buyer**
        - **Action:** Click "Add Buyer" or similar.
        - **Screen:** Create/Edit Organization Page (Buyer context for SME) (Image: `/home/ubuntu/testing_images/organization_form_page.png`)
        - **Functionality to Test:**
            - Fill in buyer details.
            - Save the new buyer.
            - **Expected Outcome:** Buyer is created and linked to the SME.
    - **2.3.3. Edit Existing Buyer**
        - **Action:** Select a buyer and click "Edit".
        - **Functionality to Test:**
            - Modify buyer details.
            - **Expected Outcome:** Changes are saved.
    - **2.3.4. View Buyer Details & Ratings**
        - **Action:** Click on a buyer to view details.
        - **Screen:** Organization Detail Page (Buyer context)
        - **Functionality to Test:**
            - View buyer's contact information, address.
            - View buyer ratings (payment score, communication score, etc.) - these might be AI-generated or manually entered.
            - **Expected Outcome:** Accurate display of buyer information and ratings.

**2.4. Invoice Management (as SME User)**
    - **2.4.1. View Invoices List**
        - **Action:** Navigate to the Invoices section.
        - **Screen:** Invoice List Page (Image: `/home/ubuntu/testing_images/invoice_list_page.png`)
        - **Functionality to Test:**
            - List of invoices for the SME.
            - Columns: Invoice #, Buyer, Amount, Issue Date, Due Date, Status (Draft, Sent, Paid, Overdue).
            - Search/filter by status, buyer, date range.
            - Sorting functionality.
            - **Expected Outcome:** Invoices are listed correctly with accurate data and filtering works.
    - **2.4.2. Create New Invoice**
        - **Action:** Click "Create Invoice" or similar.
        - **Screen:** Create/Edit Invoice Page (Image: `/home/ubuntu/testing_images/invoice_form_page.png`)
        - **Functionality to Test:**
            - Select/Add Buyer.
            - Enter invoice details (invoice #, items/services, quantities, rates, amounts, tax, issue date, due date, payment terms).
            - **AI-based Data Pipeline Test:** If invoice creation supports uploading a document (PDF, image) for data extraction:
                - Upload a sample invoice document.
                - **Expected Outcome:** Relevant fields (buyer, amount, dates) are auto-populated with high accuracy.
            - Save as Draft.
            - **Expected Outcome:** Invoice saved with "Draft" status.
    - **2.4.3. Edit Draft Invoice**
        - **Action:** Select a draft invoice and click "Edit".
        - **Functionality to Test:**
            - Modify invoice details.
            - Save changes.
            - **Expected Outcome:** Changes are saved.
    - **2.4.4. Invoice Workflow Customization (Conceptual Test)**
        - **Action:** Look for settings or options related to invoice workflows (e.g., approval steps before sending, default distribution channels).
        - **Functionality to Test:**
            - Can the SME user define an approval step? (e.g., invoice needs manager approval if over a certain amount).
            - Can the SME user set preferred delivery channels for specific buyers?
            - **Expected Outcome:** (Based on implementation) User can configure aspects of the invoice lifecycle.
    - **2.4.5. Send Invoice (Smart Invoice Distribution)**
        - **Action:** Select a draft or approved invoice and click "Send".
        - **Screen:** May involve a confirmation step or channel selection.
        - **Functionality to Test:**
            - **Email Distribution:** Send invoice via email to the buyer.
                - **Expected Outcome:** Buyer receives an email with the invoice (potentially as PDF and/or a link to a smart invoice). Email content is professional. Invoice status changes to "Sent".
            - **WhatsApp Distribution (if implemented):** Send invoice via WhatsApp.
                - **Expected Outcome:** Buyer receives a WhatsApp message with invoice details/link. Invoice status changes to "Sent".
            - **Smart Invoice Features:** If the invoice sent is a "smart invoice" with embedded agent capabilities:
                - Does the buyer's view of the invoice offer interactive options (e.g., dispute, ask question, confirm payment intent)?
                - **Expected Outcome:** Test these interactive features from a conceptual buyer perspective.
    - **2.4.6. View Sent Invoice Details**
        - **Action:** Click on a sent invoice.
        - **Screen:** Invoice Detail Page (Image: `/home/ubuntu/testing_images/invoice_detail_page.png`)
        - **Functionality to Test:**
            - View all invoice details, status, history/audit trail (when sent, viewed by buyer - if tracked).
            - Option to resend, download PDF, record payment.
            - **Expected Outcome:** Accurate display of invoice information and available actions.
    - **2.4.7. Record Payment**
        - **Action:** For a sent/overdue invoice, select "Record Payment".
        - **Functionality to Test:**
            - Enter payment amount (full/partial), payment date, method, reference.
            - **Expected Outcome:** Payment is recorded. Invoice status updates to "Paid" or "Partially Paid". Outstanding balance reflects the payment.
    - **2.4.8. Handle Overdue Invoices**
        - **Functionality to Test:**
            - Verify that invoices past their due date are marked "Overdue".
            - Test reminder functionalities (manual or automated if implemented).
            - Test communication features for following up on overdue invoices.
    - **2.4.9. Invoice Communication**
        - **Action:** Use communication features related to an invoice (e.g., send a message to the buyer about an invoice).
        - **Functionality to Test:**
            - Send a message.
            - View communication history for an invoice.
            - **Expected Outcome:** Messages are sent and logged correctly.

**2.5. SME User Profile Management**
    - **Action:** Navigate to Profile/Account Settings.
    - **Screen:** Profile Page (Image: `/home/ubuntu/testing_images/profile_page.png`)
    - **Functionality to Test:**
        - View SME user profile details.
        - Update profile information.
        - Change password.
        - **Expected Outcome:** Profile updates are saved. Password change is successful.

**2.6. SME User Logout**
    - **Action:** Click the "Logout" button.
    - **Functionality to Test:**
        - **Expected Outcome:** User is logged out and redirected to the Login Page.

### Phase 3: Advanced Features and Platform-wide Tests

**3.1. Multi-tenancy Verification**
    - **Action:** (Requires at least two separate SME organizations and users created by Admin)
        - Log in as User A from SME A. Perform actions (create buyer, create invoice).
        - Log out.
        - Log in as User B from SME B. Perform actions.
    - **Functionality to Test:**
        - **Expected Outcome:** User A should only see and manage data for SME A. User B should only see and manage data for SME B. There should be no data leakage or crossover between tenants.

**3.2. AI-based Data Pipeline (Invoice OCR/Data Extraction - re-test if specific UI exists)**
    - **Action:** If there's a dedicated section for managing the AI pipeline or reviewing extracted data from uploaded invoices.
    - **Functionality to Test:**
        - Upload various invoice formats (PDF, JPG, PNG) with different layouts.
        - Check accuracy of extracted fields (Invoice #, Dates, Amounts, Buyer Name, Line Items).
        - Test confidence scores if displayed.
        - Test any UI for correcting extracted data.
        - **Expected Outcome:** High accuracy in data extraction. User-friendly interface for corrections if needed.

**3.3. Reporting and Analytics (if implemented)**
    - **Action:** Navigate to the Reports section (for Admin or SME).
    - **Functionality to Test:**
        - Generate available reports (e.g., receivables aging, payment history, cash flow forecast).
        - Check data accuracy in reports.
        - Test export functionalities (e.g., to CSV, PDF).
        - **Expected Outcome:** Reports are generated correctly and provide valuable insights.

**3.4. Notifications (if implemented)**
    - **Action:** Perform actions that should trigger notifications (e.g., invoice overdue, payment received, new message).
    - **Functionality to Test:**
        - Check for in-app notifications.
        - Check for email notifications.
        - **Expected Outcome:** Notifications are timely and accurate.

**3.5. Responsive Design**
    - **Action:** Access the application on different screen sizes (desktop, tablet, mobile - using browser developer tools or actual devices).
    - **Functionality to Test:**
        - **Expected Outcome:** The application layout adjusts gracefully to different screen sizes. All functionalities are usable.

**3.6. Error Handling**
    - **Action:** Try to perform invalid actions (e.g., submitting forms with incorrect data, trying to access unauthorized areas via URL manipulation).
    - **Functionality to Test:**
        - **Expected Outcome:** User-friendly error messages are displayed. Application does not crash. Sensitive information is not exposed in error messages.

This detailed sequence should provide a good foundation for testing. Remember to adapt it based on the exact features implemented in your version of the platform.

Next, I will work on describing the key screens and generating conceptual images for them.




## Key Screens Descriptions and Functionalities to Test

Below are descriptions of the key screens you will encounter during testing. Since image generation is currently unavailable, detailed textual descriptions are provided to help you visualize the expected UI and functionalities.

### 1. Login Page

**(Associated with Test Steps: 1.1 Admin Login, 2.1 SME User Login)**

**Screen Description:**

The Login Page is the entry point to the application. It should have a clean, professional, and uncluttered design, typical of a modern SaaS or financial technology application. The layout is centered on the screen.

*   **Header/Logo Area:** At the top, there might be a placeholder for the application logo or the application name.
*   **Form Title:** A clear title such as "Login" or "Sign In to Your Account".
*   **Email Field:**
    *   Label: "Email" or "Email Address".
    *   Input Type: Text, specifically for email format.
    *   Placeholder Text: e.g., "you@example.com".
*   **Password Field:**
    *   Label: "Password".
    *   Input Type: Password (characters should be masked).
    *   Placeholder Text: e.g., "Enter your password".
*   **Login Button:**
    *   Text: "Login", "Sign In", or similar.
    *   Style: Prominently displayed, likely the primary action button on the page.
*   **Forgot Password Link:**
    *   Text: "Forgot Password?" or "Trouble logging in?".
    *   Functionality: Should link to a password reset workflow (if implemented).
*   **Footer (Optional):** May contain copyright information or links to terms of service/privacy policy.

**Functionalities to Test (as detailed in the sequence earlier):**

*   **Valid Login (Admin & SME):**
    *   Enter correct email and password for an existing admin/SME user.
    *   Click the "Login" button.
    *   **Expected Outcome:** Successful authentication. User is redirected to their respective dashboard (Admin Dashboard for admin, SME Dashboard for SME user). The session should be established.
*   **Invalid Credentials:**
    *   Enter an incorrect email or password.
    *   Click the "Login" button.
    *   **Expected Outcome:** An informative error message is displayed on the page (e.g., "Invalid email or password", "Login failed. Please check your credentials."). The user remains on the login page. Password field might be cleared for security.
*   **Empty Credentials:**
    *   Attempt to log in with one or both fields empty.
    *   **Expected Outcome:** Client-side validation should prevent submission, or server-side validation should return an appropriate error message (e.g., "Email is required", "Password is required").
*   **Input Validation:**
    *   Test email format validation (e.g., entering text without "@" or a domain).
    *   **Expected Outcome:** Error message indicating invalid email format.
*   **Forgot Password Link:**
    *   Click the "Forgot Password?" link.
    *   **Expected Outcome:** User is navigated to a password reset page/flow (if this feature is implemented and in scope for testing).
*   **Accessibility & Usability:**
    *   Can users navigate the form using the Tab key?
    *   Is there a clear visual focus on the active field?
    *   Are labels correctly associated with their input fields?





### 2. Admin Dashboard

**(Associated with Test Step: 1.2 Admin Dashboard)**

**Screen Description:**

The Admin Dashboard is the landing page for an administrator after successful login. It should provide a high-level overview of the platform's status and key metrics, along with easy navigation to various administrative sections.

*   **Header/Navigation Bar:**
    *   **Application Logo/Name:** Typically on the top-left.
    *   **User Profile/Logout:** On the top-right, showing the logged-in admin's name or email, with a dropdown menu for "Profile" and "Logout".
    *   **Main Navigation Links/Sidebar:** A persistent sidebar (usually on the left) or a top navigation bar with links to key admin sections such as:
        *   Dashboard (current page)
        *   Organizations (or separate links for SMEs and Buyers)
        *   Users
        *   Tenants (if explicitly managed by admin)
        *   System Settings (if applicable)
        *   Reports (if admin has access to platform-wide reports)
*   **Main Content Area:**
    *   **Welcome Message:** A brief welcome message, e.g., "Welcome, Admin!"
    *   **Key Metrics / Summary Cards:** A series of prominent cards or widgets displaying important statistics. These might include:
        *   **Total Tenants:** Count of active tenants on the platform.
        *   **Total SMEs:** Count of registered SME organizations.
        *   **Total Buyers:** Count of registered Buyer organizations.
        *   **Total Users:** Count of all users (or active users) across the platform.
        *   **Recent Activity Feed (Optional):** A list of recent important actions on the platform (e.g., new SME registered, critical system alert).
        *   **Quick Links (Optional):** Buttons or links to frequently used actions like "Create New Organization" or "Add New User".
    *   **Charts/Graphs (Optional):** Visual representations of data, such as:
        *   User registration trends.
        *   Organization growth over time.
*   **Footer (Optional):** May contain copyright information, version number.

**Functionalities to Test (as detailed in the sequence earlier):**

*   **Data Accuracy:**
    *   Verify that the numbers displayed in the summary cards (Total Tenants, SMEs, Buyers, Users) are accurate and reflect the current state of the database.
    *   If charts are present, ensure they render correctly and represent real data.
*   **Navigation:**
    *   Click on each navigation link in the sidebar/header (Organizations, Users, etc.).
    *   **Expected Outcome:** User is correctly navigated to the respective sections/pages.
    *   Click on the user profile link.
    *   **Expected Outcome:** User is navigated to the Admin Profile page.
    *   Click on the "Logout" button.
    *   **Expected Outcome:** User is logged out and redirected to the Login Page.
*   **Responsiveness (if applicable for admin interface):**
    *   Check if the dashboard layout adapts to different screen sizes (if testing on various devices or using browser developer tools).
    *   **Expected Outcome:** All elements are visible and usable on smaller screens.
*   **Load Time:**
    *   Assess the time it takes for the dashboard to load with all its data.
    *   **Expected Outcome:** Dashboard loads within an acceptable timeframe.
*   **Error States:**
    *   If any data fails to load for a metric or chart, is there a graceful error message or placeholder?
    *   **Expected Outcome:** The page doesn't crash; user-friendly error indicators are shown.




### 3. SME Dashboard

**(Associated with Test Step: 2.2 SME Dashboard)**

**Screen Description:**

The SME Dashboard is the main landing page for an SME user after logging in. It should provide a tailored overview of their receivables, key financial metrics, and quick access to invoice and buyer management functionalities. The design should be clean and focused on actionable information for the SME.

*   **Header/Navigation Bar:**
    *   **Application Logo/Name:** Typically on the top-left.
    *   **SME Organization Name:** Clearly displayed, indicating the context of the logged-in user.
    *   **User Profile/Logout:** On the top-right, showing the logged-in SME user's name or email, with a dropdown menu for "Profile" and "Logout".
    *   **Main Navigation Links/Sidebar:** A persistent sidebar (usually on the left) or a top navigation bar with links to key SME sections such as:
        *   Dashboard (current page)
        *   Invoices
        *   Buyers (or Customers)
        *   Payments
        *   Reports (SME-specific)
        *   Settings (for SME-specific configurations like invoice templates, workflow preferences)
*   **Main Content Area:**
    *   **Welcome Message:** A brief welcome message, e.g., "Welcome, [SME User Name]!"
    *   **Key Financial Metrics / Summary Cards:** A series of prominent cards or widgets displaying important statistics relevant to the SME. These might include:
        *   **Total Outstanding Receivables:** Sum of all unpaid invoices.
        *   **Total Overdue Amount:** Sum of all overdue invoices.
        *   **Average Collection Period:** (If calculated) Average time to get paid.
        *   **Upcoming Payments:** Summary of payments expected soon.
        *   **Recent Payments Received:** List or count of recent payments.
    *   **Quick Links/Actions:** Buttons or links to frequently used actions:
        *   "Create New Invoice"
        *   "Add New Buyer"
        *   "View Overdue Invoices"
    *   **Charts/Graphs (Optional but Recommended):** Visual representations of SME-specific data:
        *   **Receivables Aging Chart:** A bar chart showing outstanding amounts grouped by age (e.g., 0-30 days, 31-60 days, 60+ days).
        *   **Cash Flow Overview:** A simple chart showing incoming payments over a period.
        *   **Invoice Status Overview:** A pie chart showing the distribution of invoices by status (Draft, Sent, Paid, Overdue).
    *   **Recent Activity/To-Do List (Optional):**
        *   List of recent invoice status changes.
        *   Reminders for follow-ups or pending approvals.
*   **Footer (Optional):** May contain copyright information.

**Functionalities to Test (as detailed in the sequence earlier):**

*   **Data Accuracy & Relevance:**
    *   Verify that all metrics (Outstanding Receivables, Overdue Amount, etc.) are accurate and specific to the logged-in SME user's organization.
    *   Ensure charts correctly represent the SME's data.
    *   **Multi-tenancy Check:** Confirm that no data from other SMEs/tenants is visible.
*   **Navigation:**
    *   Click on each navigation link (Invoices, Buyers, Payments, Reports, Settings).
    *   **Expected Outcome:** User is correctly navigated to the respective sections within their SME context.
    *   Click on quick action buttons (e.g., "Create New Invoice").
    *   **Expected Outcome:** User is taken to the correct form or filtered list.
*   **Responsiveness:**
    *   Check layout and usability on different screen sizes.
    *   **Expected Outcome:** Dashboard remains functional and readable.
*   **Load Time:**
    *   Assess dashboard loading speed.
    *   **Expected Outcome:** Loads within an acceptable timeframe.
*   **Interactive Elements:**
    *   If charts are interactive (e.g., hover for details, click to drill down), test this functionality.
    *   **Expected Outcome:** Interactions work as expected.




### 4. Organization List Page

**(Associated with Test Steps: 1.3.1 View Organizations List (Admin), 2.3.1 View Buyers List (SME))**

**Screen Description:**

This page displays a list of organizations. For an Admin user, this could be a list of all SMEs and Buyers on the platform, or all organizations within a selected tenant. For an SME user, this page would typically list their Buyers (customers).

*   **Header/Navigation Bar:** Consistent with the user's role (Admin or SME), providing access to other sections and profile/logout options.
*   **Page Title:** A clear title, e.g., "Organizations", "SMEs & Buyers", or "My Buyers".
*   **Action Buttons:**
    *   **"Create Organization" / "Add New SME" / "Add New Buyer":** A prominent button to navigate to the organization creation form. The label will depend on the context and user role.
*   **Search and Filter Controls:**
    *   **Search Bar:** A text input field to search for organizations by name, email, or other relevant criteria.
    *   **Filter Dropdowns (Optional):** Filters for:
        *   **Organization Type:** (For Admin) e.g., "All", "SME", "Buyer".
        *   **Status:** e.g., "All", "Active", "Inactive".
        *   Other relevant criteria.
    *   **Apply/Reset Filter Buttons.**
*   **Organizations Table/List:**
    *   **Layout:** Typically a table with sortable columns or a list of cards, each representing an organization.
    *   **Columns (for table view):**
        *   **Name:** Organization's name (clickable to view details).
        *   **Type:** "SME" or "Buyer".
        *   **Email:** Primary contact email.
        *   **Phone:** Primary contact phone.
        *   **Status:** "Active", "Inactive".
        *   **Date Created/Registered.**
        *   **Actions:** A column with action buttons/icons for each organization, such as:
            *   "View" / "Details"
            *   "Edit"
            *   "Deactivate" / "Activate"
            *   "Delete" (use with caution, usually soft delete/deactivate is preferred).
    *   **Card View (Alternative):** Each card would display key information (Name, Type, Contact) and action buttons.
*   **Pagination Controls:** If the list is long, pagination controls (e.g., "Previous", "Next", page numbers) should be present at the bottom of the list.
*   **Empty State:** If no organizations match the criteria or none exist, a user-friendly message should be displayed (e.g., "No organizations found. Click 'Add New Buyer' to get started.").

**Functionalities to Test (as detailed in the sequence earlier):**

*   **List Display (Admin & SME contexts):**
    *   **Admin:** Verify all relevant organizations (SMEs, Buyers, potentially across tenants or for a selected tenant) are displayed.
    *   **SME:** Verify only buyers associated with the logged-in SME are displayed.
    *   Check if key information (Name, Type, Email, Status) is accurate in the list.
*   **Search Functionality:**
    *   Search by organization name (full and partial).
    *   Search by other relevant fields (e.g., email, tax ID if applicable).
    *   **Expected Outcome:** List updates correctly to show only matching organizations.
*   **Filter Functionality:**
    *   Filter by Organization Type (Admin).
    *   Filter by Status (Active/Inactive).
    *   **Expected Outcome:** List updates correctly based on filter criteria.
*   **Sorting:**
    *   Click on sortable column headers (e.g., Name, Date Created).
    *   **Expected Outcome:** List sorts in ascending/descending order correctly.
*   **Pagination:**
    *   If many organizations exist, verify pagination controls appear and function correctly (navigating to next/previous pages).
*   **Action Buttons on List Items:**
    *   **View/Details:** Click to navigate to the Organization Detail Page.
        *   **Expected Outcome:** Correct organization's details are displayed.
    *   **Edit:** Click to navigate to the Edit Organization Page.
        *   **Expected Outcome:** Form is pre-filled with the selected organization's data.
    *   **Deactivate/Activate:** Test changing the status of an organization.
        *   **Expected Outcome:** Status updates in the list and affects organization/user accessibility as per design.
*   **"Create/Add New" Button:**
    *   Click the button.
    *   **Expected Outcome:** User is navigated to the appropriate organization creation form.
*   **Empty State:**
    *   If no organizations exist or match search/filter criteria, verify a clear message is shown.
*   **Responsiveness:**
    *   Check how the list and controls adapt to different screen sizes.
    *   **Expected Outcome:** Table/list remains readable and usable.




### 5. Create/Edit Organization Page

**(Associated with Test Steps: 1.3.2 Create New SME, 1.3.3 Create New Buyer, 1.3.4 Edit Existing Organization, 2.3.2 Add New Buyer (SME), 2.3.3 Edit Existing Buyer (SME))**

**Screen Description:**

This page is a form used for both creating new organizations (SMEs or Buyers) and editing existing ones. The fields displayed might vary slightly based on whether it's an SME or a Buyer, and whether the user is an Admin or an SME user adding their own buyer.

*   **Header/Navigation Bar:** Consistent with the user's role and the rest of the application.
*   **Page Title:** A clear title, e.g., "Create New Organization", "Edit Organization Details", "Add New SME", "Add New Buyer".
*   **Form Layout:** A well-structured form, possibly divided into sections for clarity (e.g., Basic Information, Contact Details, Address).
*   **Key Form Fields (Common for both SME & Buyer, some may be Admin-only or SME-only contextually):**
    *   **Organization Name:** Text input, required.
    *   **Organization Type:** (Primarily for Admin creating) Dropdown or radio buttons: "SME", "Buyer". This might be fixed if an SME user is adding a "Buyer".
    *   **Tenant Association:** (Primarily for Admin) Dropdown to select or assign a tenant if the platform supports explicit tenant management by admins. For new SMEs, a new tenant might be created automatically.
    *   **Primary Contact Email:** Text input, email format validation, required.
    *   **Primary Contact Phone:** Text input, phone number format.
    *   **Tax ID / VAT ID / GSTIN:** Text input (label might vary by region).
    *   **Website (Optional):** Text input, URL format.
    *   **Address Section:**
        *   Street Address Line 1: Text input.
        *   Street Address Line 2 (Optional): Text input.
        *   City: Text input.
        *   State/Province: Text input or dropdown.
        *   Postal/Zip Code: Text input.
        *   Country: Dropdown or text input.
    *   **Status:** (Usually for Admin editing) Dropdown: "Active", "Inactive". Default to "Active" for new organizations.
    *   **Additional Fields for SMEs (if applicable):** Industry, Business Registration Number, etc.
    *   **Additional Fields for Buyers (if applicable):** Credit Limit (if managed by SME), Preferred Communication Channel, etc.
*   **Action Buttons:**
    *   **"Save" / "Create Organization" / "Update Organization":** Primary button to submit the form.
    *   **"Cancel":** Button to discard changes and return to the previous page (e.g., Organization List).
*   **Error Message Area:** A designated area to display form-level validation errors or success/failure messages after submission.

**Functionalities to Test (as detailed in the sequence earlier):**

*   **Form Loading (Edit Mode):**
    *   When editing an existing organization, verify all fields are pre-populated with the correct current data.
*   **Input Validation (Create & Edit):**
    *   **Required Fields:** Attempt to submit the form with required fields (e.g., Name, Email, Type) left empty.
        *   **Expected Outcome:** Validation messages appear next to the fields or in a summary, preventing submission.
    *   **Email Format:** Enter an invalid email format.
        *   **Expected Outcome:** Validation error for email format.
    *   **Phone Format (if specific validation exists):** Test with invalid phone numbers.
    *   **URL Format (for website):** Test with invalid URLs.
    *   **Data Type Integrity:** Ensure numeric fields don't accept text, etc.
*   **Creating a New Organization (SME & Buyer - Admin context):**
    *   Fill in all valid details for a new SME.
    *   Click "Save" or "Create".
    *   **Expected Outcome:** Organization is created successfully. User is redirected to the Organization List page (or detail page), and the new SME appears. A new tenant should be associated correctly.
    *   Repeat for a new Buyer organization.
    *   **Expected Outcome:** Buyer created and listed.
*   **Adding a New Buyer (SME context):**
    *   As an SME user, fill in details for a new Buyer.
    *   Click "Save" or "Add Buyer".
    *   **Expected Outcome:** Buyer is created and associated with the logged-in SME. It appears in the SME's Buyer list.
*   **Editing an Existing Organization:**
    *   Modify several fields of an existing organization.
    *   Click "Save" or "Update".
    *   **Expected Outcome:** Changes are saved successfully. The updated information is reflected in the Organization List and Detail pages.
*   **Cancel Button:**
    *   Make some changes on the form (for an existing organization) or start filling a new one.
    *   Click "Cancel".
    *   **Expected Outcome:** User is returned to the previous page, and no changes are saved (or new organization is not created).
*   **Status Field (Admin):**
    *   When editing, change the status (e.g., Active to Inactive).
    *   **Expected Outcome:** Status is updated correctly.
*   **Unique Constraints:**
    *   If certain fields must be unique (e.g., organization name within a tenant, tax ID), test creating a duplicate.
    *   **Expected Outcome:** Appropriate error message indicating the duplication.
*   **Responsiveness:**
    *   Check form layout and usability on different screen sizes.
    *   **Expected Outcome:** Form remains easy to use.




### 6. User List Page (Admin)

**(Associated with Test Step: 1.4.1 View Users List (for a selected SME/Tenant))**

**Screen Description:**

This page is used by an Administrator to view and manage users within the platform, typically within the context of a specific tenant or SME organization. If the platform has a super-admin concept that can see users across all tenants, the view might be broader, but usually, it's scoped.

*   **Header/Navigation Bar:** Consistent Admin navigation.
*   **Page Title:** Clear title, e.g., "User Management", "Users for [Tenant/SME Name]".
*   **Tenant/SME Selector (If applicable):** If an admin manages multiple tenants/SMEs, there might be a dropdown or search field to select the specific tenant/SME whose users are to be displayed.
*   **Action Buttons:**
    *   **"Create User" / "Add New User":** Button to navigate to the user creation form.
*   **Search and Filter Controls:**
    *   **Search Bar:** Text input to search for users by email, first name, or last name.
    *   **Filter Dropdowns (Optional):**
        *   **Role:** e.g., "All", "SME Admin", "SME Staff", "Buyer User" (if buyers have users).
        *   **Status:** e.g., "All", "Active", "Inactive", "Pending Activation".
    *   **Apply/Reset Filter Buttons.**
*   **Users Table/List:**
    *   **Layout:** Typically a table with sortable columns.
    *   **Columns:**
        *   **Email:** User's email address (often used as username, clickable to view details or edit).
        *   **First Name.**
        *   **Last Name.**
        *   **Role:** User's assigned role within their organization/tenant.
        *   **Organization/Tenant:** The SME or tenant the user belongs to (especially important if admin views users across multiple entities).
        *   **Status:** "Active", "Inactive", "Pending Activation".
        *   **Last Login (Optional):** Date and time of the user's last login.
        *   **Date Created/Registered.**
        *   **Actions:** A column with action buttons/icons for each user:
            *   "View" / "Details" (might lead to profile view or edit page)
            *   "Edit"
            *   "Deactivate" / "Activate"
            *   "Reset Password" (triggers a password reset flow)
            *   "Delete" (use with caution).
*   **Pagination Controls:** For long lists of users.
*   **Empty State:** Message displayed if no users are found or match criteria (e.g., "No users found for this organization.").

**Functionalities to Test (as detailed in the sequence earlier):**

*   **List Display:**
    *   Verify users associated with the selected/default tenant/SME are displayed.
    *   Check accuracy of information (Email, Name, Role, Status).
*   **Tenant/SME Selection (if applicable):**
    *   If a selector exists, change the tenant/SME.
    *   **Expected Outcome:** User list updates to show users only from the newly selected tenant/SME.
*   **Search Functionality:**
    *   Search by email, first name, last name (full and partial).
    *   **Expected Outcome:** List updates correctly.
*   **Filter Functionality:**
    *   Filter by Role.
    *   Filter by Status.
    *   **Expected Outcome:** List updates based on filter criteria.
*   **Sorting:**
    *   Test sorting by clicking on column headers (Email, Name, Role, Date Created).
    *   **Expected Outcome:** List sorts correctly.
*   **Pagination:**
    *   Verify pagination works for large user lists.
*   **Action Buttons on List Items:**
    *   **Edit:** Navigates to the Edit User Page, pre-filled with user data.
    *   **Deactivate/Activate:** Changes user status; deactivated users should not be able to log in.
    *   **Reset Password:** Initiates a password reset flow for the user (e.g., sends a reset link).
*   **"Create User" Button:**
    *   Navigates to the Create User form.
*   **Empty State Message:**
    *   Verify a clear message if no users are found.
*   **Responsiveness:**
    *   Check layout on different screen sizes.




### 7. Create/Edit User Page (Admin)

**(Associated with Test Steps: 1.4.2 Create New SME User, 1.4.3 Edit Existing User)**

**Screen Description:**

This page is an administrative form used to create new users or modify existing user profiles, typically within the context of a specific SME organization or tenant.

*   **Header/Navigation Bar:** Consistent Admin navigation.
*   **Page Title:** Clear title, e.g., "Create New User", "Edit User Profile".
*   **Form Layout:** A well-structured form.
*   **Key Form Fields:**
    *   **Tenant/SME Organization:**
        *   (If creating a new user and admin can select) Dropdown or search to select the SME Organization/Tenant this user will belong to. This might be pre-filled if navigating from a specific organization context.
        *   (If editing) Usually a read-only display of the user's current organization.
    *   **First Name:** Text input, required.
    *   **Last Name:** Text input, required.
    *   **Email Address:** Text input, email format validation, required. This will likely be the username and must be unique across the system or at least within the tenant.
    *   **Password:**
        *   (For Create User) Text input, password type (masked). Should have a confirmation field ("Confirm Password"). Password strength indicators are a plus.
        *   (For Edit User) Usually, this section is for resetting a password. It might have a "Send Password Reset Email" button or fields for an admin to set a temporary password.
    *   **Role:** Dropdown select, required. Roles would be specific to the application, e.g.:
        *   "SME Admin" (full control within their SME organization)
        *   "SME Staff" (limited permissions within their SME organization, e.g., can create invoices but not manage users)
        *   (Potentially other roles like "Buyer User" if buyers can log in).
    *   **Status:** Dropdown select: "Active", "Inactive", "Pending Activation". Defaults to "Active" or "Pending Activation" for new users.
    *   **Phone Number (Optional):** Text input.
    *   **Profile Picture Upload (Optional):** File input.
*   **Action Buttons:**
    *   **"Save User" / "Create User" / "Update User":** Primary button to submit the form.
    *   **"Cancel":** Button to discard changes and return to the User List page.
*   **Error Message Area:** For displaying form validation errors or submission status messages.

**Functionalities to Test (as detailed in the sequence earlier):**

*   **Form Loading (Edit Mode):**
    *   When editing an existing user, verify all fields (except password) are pre-populated with the correct current data.
*   **Input Validation (Create & Edit):**
    *   **Required Fields:** Test submitting with empty First Name, Last Name, Email, Role, Password (for new user).
        *   **Expected Outcome:** Validation errors displayed.
    *   **Email Format & Uniqueness:** Enter invalid email format. Try creating a user with an email that already exists.
        *   **Expected Outcome:** Validation errors.
    *   **Password Policy:** (For new user or password set) Test password strength rules (if any, e.g., min length, uppercase, number, special character). Test if "Password" and "Confirm Password" fields match.
        *   **Expected Outcome:** Validation errors if policy not met or passwords don't match.
*   **Creating a New User:**
    *   Select an SME/Tenant (if applicable).
    *   Fill in all valid details for a new user.
    *   Click "Save" or "Create User".
    *   **Expected Outcome:** User is created successfully. User appears in the User List for the selected SME/Tenant. A welcome/activation email might be sent (if implemented).
*   **Editing an Existing User:**
    *   Modify user details (e.g., name, role, status).
    *   Click "Save" or "Update User".
    *   **Expected Outcome:** Changes are saved. Updated information is reflected in the User List.
*   **Password Reset Functionality (Edit Mode):**
    *   If an admin can set a temporary password or trigger a reset email, test this flow.
    *   **Expected Outcome:** Password reset is successful (user can log in with new password or receives reset link).
*   **Cancel Button:**
    *   Make changes or start filling the form.
    *   Click "Cancel".
    *   **Expected Outcome:** No changes saved; user returned to User List.
*   **Role Assignment:**
    *   Ensure the selected role is correctly assigned and saved.
    *   (Later, verify permissions based on this role when the user logs in).
*   **Status Field:**
    *   Change user status (Active/Inactive).
    *   **Expected Outcome:** Status is updated. Inactive users should not be able to log in.
*   **Responsiveness:**
    *   Check form layout on different screen sizes.




### 8. Invoice List Page (SME User)

**(Associated with Test Step: 2.4.1 View Invoices List)**

**Screen Description:**

This page is central to the SME user, displaying a list of all their invoices. It should offer robust filtering, searching, and quick actions related to invoices.

*   **Header/Navigation Bar:** Consistent SME user navigation.
*   **Page Title:** Clear title, e.g., "Invoices", "My Invoices".
*   **Action Buttons:**
    *   **"Create New Invoice" / "Add Invoice":** Prominent button to navigate to the invoice creation form.
*   **Search and Filter Controls:**
    *   **Search Bar:** Text input to search invoices by Invoice #, Buyer Name, or possibly line item descriptions.
    *   **Filter Dropdowns/Date Pickers:** Essential for managing invoices:
        *   **Status:** e.g., "All", "Draft", "Sent", "Viewed", "Paid", "Partially Paid", "Overdue", "Disputed".
        *   **Buyer:** Dropdown to select a specific buyer.
        *   **Date Range:** Date pickers for "Issue Date From" and "Issue Date To", or "Due Date From" and "Due Date To".
        *   **Amount Range (Optional):** Min and Max amount.
    *   **Apply/Reset Filter Buttons.**
*   **Invoices Table/List:**
    *   **Layout:** Typically a table with sortable columns for detailed information.
    *   **Columns:**
        *   **Invoice #:** Unique invoice identifier (clickable to view invoice details).
        *   **Buyer Name:** Name of the buyer/customer.
        *   **Issue Date:** Date the invoice was issued.
        *   **Due Date:** Date the invoice is due for payment.
        *   **Total Amount:** The total value of the invoice.
        *   **Amount Due/Outstanding:** The remaining amount to be paid.
        *   **Status:** Current status of the invoice (e.g., "Draft", "Sent", "Paid", "Overdue"). This should be visually distinct (e.g., using color-coded badges).
        *   **Last Action (Optional):** Date of last action (e.g., sent, reminder sent, payment recorded).
        *   **Actions:** A column with action buttons/icons for each invoice, which may vary based on invoice status:
            *   For "Draft": "Edit", "Send", "View", "Delete".
            *   For "Sent"/"Overdue": "View", "Resend", "Record Payment", "Download PDF", "Send Reminder", "Mark as Disputed".
            *   For "Paid": "View", "Download PDF".
*   **Summary Metrics (Optional, above the list):**
    *   Total Value of Displayed Invoices.
    *   Total Outstanding of Displayed Invoices.
*   **Pagination Controls:** For long lists of invoices.
*   **Empty State:** Message displayed if no invoices are found or match criteria (e.g., "No invoices found. Click 'Create New Invoice' to start.").

**Functionalities to Test (as detailed in the sequence earlier):**

*   **List Display & Accuracy:**
    *   Verify all invoices for the logged-in SME are displayed (or correctly paginated).
    *   Check accuracy of all data points in the list (Invoice #, Buyer, Dates, Amounts, Status).
*   **Search Functionality:**
    *   Search by Invoice #, Buyer Name.
    *   **Expected Outcome:** List updates correctly.
*   **Filter Functionality:**
    *   Filter by Status (test each status).
    *   Filter by Buyer.
    *   Filter by Issue Date range and Due Date range.
    *   **Expected Outcome:** List updates accurately based on combined filter criteria.
*   **Sorting:**
    *   Test sorting by clicking on column headers (Invoice #, Buyer Name, Issue Date, Due Date, Amount, Status).
    *   **Expected Outcome:** List sorts correctly in ascending/descending order.
*   **Pagination:**
    *   Verify pagination works for large invoice lists.
*   **Action Buttons on List Items (Contextual):**
    *   Test all available actions for invoices in different statuses (Edit, Send, View, Resend, Record Payment, Download PDF, etc.) as outlined in the screen description.
    *   **Expected Outcome:** Each action performs its intended function and navigates to the correct page or triggers the correct process. Invoice status should update accordingly.
*   **"Create New Invoice" Button:**
    *   Navigates to the Create Invoice form.
*   **Empty State Message:**
    *   Verify a clear message if no invoices are found.
*   **Responsiveness:**
    *   Check layout and usability on different screen sizes. Table columns might need to be selectively hidden or re-arranged on smaller screens.




### 9. Create/Edit Invoice Page (SME User)

**(Associated with Test Steps: 2.4.2 Create New Invoice, 2.4.3 Edit Draft Invoice)**

**Screen Description:**

This form allows SME users to create new invoices or edit existing draft invoices. It should be intuitive and allow for detailed entry of invoice information, including line items and AI-assisted data extraction if applicable.

*   **Header/Navigation Bar:** Consistent SME user navigation.
*   **Page Title:** Clear title, e.g., "Create New Invoice", "Edit Invoice [Invoice #]".
*   **Form Layout:** Well-structured, possibly with sections for Buyer Information, Invoice Details, Line Items, and Totals.
*   **Key Form Fields/Sections:**
    *   **Buyer Information:**
        *   **Select Buyer:** Dropdown or searchable select list of existing buyers for the SME. Option to "Add New Buyer" might navigate to the buyer creation form or open a modal.
        *   **Buyer Details (Read-only, auto-filled upon selection):** Buyer Name, Address, Contact Info.
    *   **Invoice Details:**
        *   **Invoice Number:** Can be auto-generated (e.g., INV-YYYYMMDD-XXXX) or manually entered. Should check for uniqueness.
        *   **Issue Date:** Date picker, defaults to today. Required.
        *   **Due Date:** Date picker. Required. Can be calculated based on payment terms.
        *   **Payment Terms:** Dropdown (e.g., "Net 30", "Net 60", "Due on Receipt") or text input.
        *   **Currency:** Dropdown (e.g., INR, USD). Default based on SME settings.
        *   **Purchase Order (PO) Number (Optional):** Text input.
        *   **Notes/Terms & Conditions (Optional):** Text area for additional notes or standard terms.
    *   **AI-Assisted Data Extraction (Optional Section for New Invoice):**
        *   **Upload Invoice Document:** A file input field to upload a PDF or image of an existing invoice.
        *   **"Extract Data" Button:** To trigger the AI (Deepseek R1) data extraction process.
        *   **Expected Behavior:** After upload and extraction, relevant fields (Buyer, Dates, Line Items, Amounts) should be auto-populated or suggested for review.
    *   **Line Items Section:** A dynamic table or list where users can add multiple billable items/services.
        *   **Each Line Item Row:**
            *   **Description:** Text input or dropdown for predefined services/products. Required.
            *   **Quantity (Qty):** Number input. Required.
            *   **Unit Price/Rate:** Number input. Required.
            *   **Tax Rate (Optional):** Percentage input or selection from predefined tax codes.
            *   **Amount (Calculated):** Qty * Unit Price (plus tax if applicable). Read-only.
            *   **Action:** Button to "Remove" line item.
        *   **"Add Line Item" / "Add Row" Button:** To add a new blank line item row.
    *   **Totals Section (Calculated, Read-only):**
        *   **Subtotal:** Sum of all line item amounts (before tax).
        *   **Tax Total (if applicable):** Sum of all taxes.
        *   **Discount (Optional):** Field to enter a discount amount or percentage.
        *   **Grand Total:** Final amount due.
*   **Action Buttons:**
    *   **"Save as Draft":** Saves the invoice with "Draft" status, allowing further edits.
    *   **"Save and Send":** (May appear after initial save or if workflow allows direct send) Saves the invoice and initiates the sending process (e.g., opens a send confirmation modal).
    *   **"Update Invoice":** (If editing) Saves changes to the draft invoice.
    *   **"Preview":** (Optional) Shows a preview of how the invoice will look.
    *   **"Cancel":** Discards changes and returns to the Invoice List page.
*   **Error Message Area:** For form validation errors or submission status.

**Functionalities to Test (as detailed in the sequence earlier):**

*   **Form Loading (Edit Mode):**
    *   When editing a draft invoice, verify all fields and line items are pre-populated correctly.
*   **Buyer Selection:**
    *   Select a buyer from the list. Verify their details auto-populate correctly.
    *   Test adding a new buyer through this form (if the option exists).
*   **Input Validation (Create & Edit):**
    *   **Required Fields:** Test submitting with empty required fields (Buyer, Issue Date, Due Date, Line Item Description/Qty/Price).
    *   **Data Types:** Ensure date pickers work, numeric fields accept only numbers.
    *   **Invoice Number Uniqueness:** If manually entered, test creating an invoice with an existing number.
*   **AI-Assisted Data Extraction (Deepseek R1 Test):**
    *   Upload various sample invoice documents (PDF, image) with different layouts.
    *   Click "Extract Data".
    *   **Expected Outcome:** Buyer, dates, line items, and amounts are auto-populated with high accuracy. Review if the system allows correction of extracted data.
*   **Line Item Management:**
    *   Add multiple line items.
    *   Enter valid data for description, quantity, unit price.
    *   Verify line item amount and invoice totals (Subtotal, Tax, Grand Total) are calculated correctly and update dynamically.
    *   Remove a line item.
    *   **Expected Outcome:** Totals recalculate correctly.
*   **Saving as Draft:**
    *   Fill in partial or complete invoice details.
    *   Click "Save as Draft".
    *   **Expected Outcome:** Invoice is saved with "Draft" status and appears in the Invoice List. It should be editable later.
*   **Updating a Draft Invoice:**
    *   Open a draft invoice, make changes, and save.
    *   **Expected Outcome:** Changes are saved.
*   **Saving and Sending (if direct send is an option here):**
    *   Complete a valid invoice.
    *   Click "Save and Send".
    *   **Expected Outcome:** Invoice is saved, status changes to "Sent" (or an approval workflow is triggered), and the send process (e.g., email modal) begins.
*   **Calculations:**
    *   Thoroughly check all calculations: line item totals, subtotal, tax calculations, grand total, especially after adding/removing/editing line items or applying discounts.
*   **Cancel Button:**
    *   Make changes or start filling the form.
    *   Click "Cancel".
    *   **Expected Outcome:** No changes saved; user returned to Invoice List.
*   **Responsiveness:**
    *   Check form layout and usability on different screen sizes.




### 10. Invoice Detail Page (SME User)

**(Associated with Test Step: 2.4.6 View Sent Invoice Details)**

**Screen Description:**

This page provides a comprehensive view of a single invoice. It should display all invoice information, its current status, payment history, and allow for actions like downloading, resending, or recording payments, depending on the invoice status.

*   **Header/Navigation Bar:** Consistent SME user navigation.
*   **Page Title:** Clear title, typically "Invoice [Invoice #]" or "Invoice Details".
*   **Action Buttons (Contextual, based on invoice status):**
    *   **"Edit"**: If the invoice is still a "Draft".
    *   **"Send" / "Resend"**: If "Draft" or already "Sent"/"Overdue".
    *   **"Record Payment"**: If "Sent" or "Overdue" or "Partially Paid".
    *   **"Download PDF"**: Always available for non-draft invoices.
    *   **"Print"**: (Optional) To print the invoice.
    *   **"Mark as Disputed" / "Resolve Dispute"**: For managing disputed invoices.
    *   **"Send Reminder"**: For "Sent" or "Overdue" invoices.
    *   **"Void Invoice" / "Cancel Invoice"**: (Use with caution, should have clear implications).
*   **Invoice Information Display:**
    *   **Layout:** Clearly presented, resembling a standard invoice layout.
    *   **SME Details:** Your company name, address, contact information, logo.
    *   **Buyer Details:** Buyer's name, billing address, shipping address (if applicable), contact information.
    *   **Invoice Core Details:**
        *   Invoice Number
        *   Issue Date
        *   Due Date
        *   Payment Terms
        *   Purchase Order (PO) Number (if any)
    *   **Line Items Table:**
        *   Columns: Description, Quantity, Unit Price, Tax (if applicable), Amount.
        *   Clearly itemized list of products/services.
    *   **Totals Section:**
        *   Subtotal
        *   Tax Total(s)
        *   Discount (if any)
        *   **Grand Total**
        *   **Amount Paid**
        *   **Amount Due (Outstanding Balance)** - This should be very prominent.
    *   **Invoice Status:** Clearly displayed (e.g., "Draft", "Sent", "Viewed by Buyer", "Paid", "Partially Paid", "Overdue", "Disputed").
    *   **Notes/Terms & Conditions:** Any notes or terms included on the invoice.
*   **Payment History Section (if applicable):**
    *   A list or table of payments made against this invoice.
    *   Columns: Payment Date, Amount Paid, Payment Method, Reference Number.
*   **Activity Log / Audit Trail Section (Optional but Recommended):**
    *   A chronological list of actions related to this invoice.
    *   Examples: Created, Sent (Channel: Email to buyer@example.com), Viewed by Buyer (Date/Time), Reminder Sent, Payment Recorded, Status Changed to Paid.
*   **Communication Section (Optional):**
    *   A place to view or initiate communication with the buyer regarding this specific invoice.

**Functionalities to Test (as detailed in the sequence earlier):**

*   **Data Accuracy:**
    *   Verify all displayed information (SME details, Buyer details, invoice dates, line items, totals, amount paid, amount due, status) is accurate and matches the source data.
*   **Contextual Action Buttons:**
    *   Confirm that the correct action buttons are displayed based on the invoice's current status (e.g., "Edit" only for Draft, "Record Payment" for Unpaid/Partially Paid).
    *   Test each available action button:
        *   **Edit (for Draft):** Navigates to the Edit Invoice page with data pre-filled.
        *   **Send/Resend:** Initiates the invoice sending workflow (e.g., email modal, WhatsApp option).
        *   **Record Payment:** Opens a form/modal to record payment details. Verify invoice status and amount due update correctly after recording.
        *   **Download PDF:** Downloads a well-formatted PDF version of the invoice.
        *   **Mark as Disputed/Resolve Dispute:** Updates invoice status and potentially opens communication channels.
        *   **Send Reminder:** Triggers a reminder to be sent to the buyer.
*   **Payment History Display:**
    *   If payments have been recorded, verify they are listed accurately with correct dates and amounts.
*   **Activity Log/Audit Trail:**
    *   Check if key events related to the invoice are logged correctly with timestamps.
*   **Smart Invoice Features (if applicable and viewable here):**
    *   If this page reflects interactions from a smart invoice (e.g., buyer viewed, buyer made a comment), verify this information is displayed.
*   **Responsiveness:**
    *   Check how the invoice details are presented on different screen sizes. Ensure readability and usability.




### 11. Profile Page (Admin & SME User)

**(Associated with Test Steps: 1.5 Admin Profile Management, 2.5 SME User Profile Management)**

**Screen Description:**

This page allows logged-in users (both Admins and SME Users) to view and manage their personal profile information, including changing their password and potentially other account settings. The specific fields available for editing might differ slightly based on the user's role.

*   **Header/Navigation Bar:** Consistent with the user's role (Admin or SME) and the rest of the application.
*   **Page Title:** Clear title, e.g., "My Profile", "Account Settings", "User Profile".
*   **Form Layout:** Typically divided into sections for clarity, such as "Personal Information", "Change Password", and possibly "Notification Preferences" or "Account Settings" if applicable.

*   **Personal Information Section:**
    *   **First Name:** Text input. May be editable.
    *   **Last Name:** Text input. May be editable.
    *   **Email Address:** Usually displayed as read-only, as it often serves as the username and primary identifier. If changeable, it would require a verification process.
    *   **Phone Number (Optional):** Text input. May be editable.
    *   **Role (Read-only):** Displays the user's current role (e.g., "Admin", "SME Admin", "SME Staff").
    *   **Organization/Tenant (Read-only, for SME users or admins scoped to a tenant):** Displays the organization or tenant the user belongs to.
    *   **Profile Picture (Optional):** Displays current profile picture with an option to upload/change it.
    *   **"Update Profile" / "Save Changes" Button:** For submitting changes made in this section.

*   **Change Password Section:**
    *   **Current Password:** Text input, password type (masked). Required to authorize password change.
    *   **New Password:** Text input, password type (masked). Should have password strength indicators.
    *   **Confirm New Password:** Text input, password type (masked). Must match the "New Password" field.
    *   **"Change Password" Button:** For submitting the password change request.

*   **Notification Preferences Section (Optional):**
    *   Checkboxes or toggles to enable/disable different types of notifications (e.g., email notifications for overdue invoices, in-app notifications for new messages).
    *   **"Save Preferences" Button.**

*   **Account Settings Section (Optional, more common for Admins or SME Admins):**
    *   **Timezone Selection:** Dropdown.
    *   **Language Preference:** Dropdown.
    *   **Two-Factor Authentication (2FA) Setup (if implemented):** Options to enable/disable and configure 2FA.
    *   **API Key Management (if applicable for integrations):** Option to generate/revoke API keys.
    *   **"Save Settings" Button.**

*   **Error/Success Message Area:** To display feedback after submitting changes.

**Functionalities to Test (as detailed in the sequence earlier):**

*   **View Profile Information:**
    *   Verify that all displayed personal information (Name, Email, Role, Organization) is accurate for the logged-in user.
*   **Edit Personal Information:**
    *   Attempt to modify editable fields (e.g., First Name, Last Name, Phone Number).
    *   Click "Update Profile" or "Save Changes".
    *   **Expected Outcome:** Changes are saved successfully. The updated information is reflected on the profile page and potentially in other parts of the UI (e.g., header user display).
    *   Test input validation for editable fields (e.g., phone number format).
*   **Change Password:**
    *   **Correct Current Password:** Enter the correct current password, a new valid password, and confirm the new password.
        *   **Expected Outcome:** Password is changed successfully. The user might be logged out and required to log in with the new password, or the session continues with the new password active.
    *   **Incorrect Current Password:** Attempt to change the password by providing an incorrect current password.
        *   **Expected Outcome:** Error message displayed (e.g., "Incorrect current password"). Password is not changed.
    *   **New Passwords Don't Match:** Enter a new password and a different confirmation password.
        *   **Expected Outcome:** Validation error message (e.g., "New passwords do not match").
    *   **Password Policy:** Test if the new password adheres to any defined strength policies (length, character types).
        *   **Expected Outcome:** Validation error if the policy is not met.
*   **Notification Preferences (if implemented):**
    *   Change notification settings.
    *   Save preferences.
    *   **Expected Outcome:** Settings are saved. (Actual notification delivery would be tested as part of notification system testing).
*   **Account Settings (if implemented):**
    *   Change settings like timezone or language.
    *   Save settings.
    *   **Expected Outcome:** Settings are saved and reflected in the application behavior/display where applicable.
*   **Responsiveness:**
    *   Check the layout and usability of the profile page on different screen sizes.

This completes the description of the key screens. The next step will be to detail the specific functionalities to test on each screen, incorporating best practices for invoice distribution and workflow customization, and considering the AI capabilities of the platform.




### Testing Core Platform Capabilities and Best Practices

This section highlights specific areas to focus on during testing, ensuring that core platform capabilities and best practices, as outlined in the requirements and knowledge base, are thoroughly validated.

**1. Smart Invoice Distribution (Email & WhatsApp)**

*   **Reference Test Steps:** 2.4.5 Send Invoice (Smart Invoice Distribution)
*   **Key Aspects to Verify:**
    *   **Channel Functionality:** Invoices can be successfully dispatched via both email and WhatsApp (if implemented).
    *   **Content Accuracy:** The content of the email/WhatsApp message is professional, accurate, and contains the necessary invoice information or a secure link to the smart invoice.
    *   **Smart Invoice Interaction:** If the distributed invoice is a "smart invoice" with embedded agent capabilities, test its interactive features from the recipient's perspective (e.g., ability to ask questions, dispute, indicate payment intent directly from the invoice interface).
    *   **Status Tracking:** The platform accurately updates the invoice status after successful distribution (e.g., to "Sent", "Delivered", or "Viewed" if tracking is implemented).
    *   **Error Handling:** Test scenarios where distribution might fail (e.g., invalid email address, WhatsApp number not registered) and ensure appropriate error messages or notifications are provided to the SME user.

**2. Invoice Workflow Customization**

*   **Reference Test Steps:** 2.4.4 Invoice Workflow Customization (Conceptual Test)
*   **Key Aspects to Verify:**
    *   **Approval Processes:** Can SME users define or utilize pre-set approval workflows before an invoice is sent? (e.g., an invoice over a certain amount requires manager approval).
        *   Test the submission for approval, the approval/rejection process by the designated approver, and the subsequent status changes of the invoice.
    *   **Customizable Distribution Preferences:** Can SME users set preferred distribution channels (email, WhatsApp) for specific buyers or as a default?
    *   **Visual Definition (if implemented):** If the platform offers a visual workflow builder, test its usability and effectiveness in defining custom invoice lifecycle steps.
    *   **Flexibility:** The system should allow for variations in workflows to accommodate different SME needs.

**3. AI-based Data Pipeline (Invoice OCR with Deepseek R1)**

*   **Reference Test Steps:** 2.4.2 Create New Invoice (AI-based Data Pipeline Test), 3.2 AI-based Data Pipeline (Invoice OCR/Data Extraction - re-test if specific UI exists)
*   **Key Aspects to Verify:**
    *   **Accuracy of Extraction:** Upload various invoice documents (PDFs, images with different layouts, fonts, and quality).
        *   Verify the accuracy of extracted data for key fields: Buyer Name, Invoice Number, Invoice Date, Due Date, Line Item Descriptions, Quantities, Unit Prices, and Total Amounts.
        *   The Deepseek R1 model (or the AI pipeline it powers) should demonstrate high precision.
    *   **Confidence Scores (if displayed):** If the system provides confidence scores for extracted data, check if they reasonably reflect the accuracy.
    *   **User Review and Correction:** Is there an intuitive interface for users to review the extracted data and make corrections if necessary? Test the correction process and ensure changes are saved.
    *   **Performance:** Assess the time taken for data extraction.
    *   **Handling of Poor Quality Inputs:** Test with skewed, blurry, or handwritten (if claimed to be supported) invoices to understand the system's limitations and error handling.

**4. Multi-Tenancy**

*   **Reference Test Steps:** 1.3.2 Create New SME Organization (Admin), 1.4.2 Create New SME User (Admin), 2.1 SME User Login, 3.1 Multi-tenancy Verification
*   **Key Aspects to Verify:**
    *   **Data Isolation:** This is critical. Ensure that data belonging to one SME (tenant) is completely inaccessible to users from another SME (tenant). This includes:
        *   Invoices
        *   Buyers
        *   Payments
        *   User profiles within the SME
        *   SME-specific settings and configurations
    *   **Admin Segregation (if applicable):** If admins are scoped to specific tenants, ensure they can only manage their assigned tenants.
    *   **User Roles within Tenant:** Verify that user roles (e.g., SME Admin, SME Staff) are respected within the context of their own tenant and do not grant cross-tenant access.
    *   **Shared Resources:** If any resources are shared (e.g., a global buyer directory that SMEs can link to), ensure the sharing mechanism respects privacy and permissions.

By focusing on these core capabilities during testing, you can ensure the platform is robust, secure, and delivers on its key value propositions.

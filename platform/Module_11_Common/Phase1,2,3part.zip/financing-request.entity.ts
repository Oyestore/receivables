import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { Organization } from '../../../organizations/entities/organization.entity';
import { Invoice } from '../../../invoices/entities/invoice.entity';
import { PaymentTransaction } from '../../entities/payment-transaction.entity';

export enum FinancingStatus {
  DRAFT = 'draft',
  PENDING_APPROVAL = 'pending_approval',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  FUNDED = 'funded',
  REPAID = 'repaid',
  DEFAULTED = 'defaulted',
  CANCELLED = 'cancelled',
}

export enum FinancingType {
  INVOICE_FINANCING = 'invoice_financing',
  SUPPLY_CHAIN_FINANCE = 'supply_chain_finance',
  WORKING_CAPITAL = 'working_capital',
  PURCHASE_ORDER_FINANCING = 'purchase_order_financing',
}

@Entity()
export class FinancingRequest {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({
    type: 'enum',
    enum: FinancingType,
    default: FinancingType.INVOICE_FINANCING,
  })
  financingType: FinancingType;

  @Column({
    type: 'enum',
    enum: FinancingStatus,
    default: FinancingStatus.DRAFT,
  })
  status: FinancingStatus;

  @ManyToOne(() => Organization)
  organization: Organization;

  @Column()
  organizationId: string;

  @ManyToOne(() => Invoice, { nullable: true })
  invoice: Invoice;

  @Column({ nullable: true })
  invoiceId: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  requestedAmount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  approvedAmount: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, nullable: true })
  interestRate: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, nullable: true })
  processingFeePercentage: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  processingFeeFixed: number;

  @Column({ nullable: true })
  currencyCode: string;

  @Column({ nullable: true })
  tenorDays: number;

  @Column({ nullable: true })
  requestDate: Date;

  @Column({ nullable: true })
  approvalDate: Date;

  @Column({ nullable: true })
  fundingDate: Date;

  @Column({ nullable: true })
  repaymentDueDate: Date;

  @Column({ nullable: true })
  repaymentDate: Date;

  @Column({ nullable: true })
  nbfcPartnerId: string;

  @Column({ nullable: true })
  nbfcPartnerName: string;

  @Column({ nullable: true })
  nbfcReferenceId: string;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  totalRepaymentAmount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  repaidAmount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  outstandingAmount: number;

  @Column({ type: 'decimal', precision: 3, scale: 2, default: 0 })
  advancePercentage: number;

  @Column({ nullable: true })
  rejectionReason: string;

  @Column({ type: 'decimal', precision: 3, scale: 2, nullable: true })
  riskScore: number;

  @Column({ type: 'json', nullable: true })
  eligibilityFactors: Record<string, any>;

  @Column({ type: 'json', nullable: true })
  metadata: Record<string, any>;

  @OneToMany(() => FinancingTransaction, transaction => transaction.financingRequest)
  transactions: FinancingTransaction[];

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  updatedAt: Date;
}

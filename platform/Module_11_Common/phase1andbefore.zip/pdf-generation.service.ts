import { Injectable, InternalServerErrorException, Logger } from "@nestjs/common";
import * as playwright from "playwright-aws-lambda"; // Using playwright-aws-lambda for potentially better compatibility in restricted environments, or use 'playwright' directly
import * as fs from "fs/promises";
import * as path from "path";
import { Invoice } from "../../invoices/entities/invoice.entity"; // Assuming Invoice entity path
import { InvoiceTemplate } from "../../templates/entities/invoice-template.entity"; // Assuming InvoiceTemplate entity path

@Injectable()
export class PdfGenerationService {
  private readonly logger = new Logger(PdfGenerationService.name);

  // A simple templating function (replace with a more robust one like Handlebars if needed)
  private populateHtmlTemplate(htmlTemplate: string, data: any): string {
    let populatedHtml = htmlTemplate;
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        // Handle simple replacements, for arrays/objects, more complex logic is needed
        if (typeof data[key] === "string" || typeof data[key] === "number" || typeof data[key] === "boolean") {
          const regex = new RegExp(`{{\s*${key}\s*}}`, "g");
          populatedHtml = populatedHtml.replace(regex, String(data[key]));
        } else if (key === "line_items" && Array.isArray(data[key])) {
          // Basic line item handling - assumes a specific HTML structure in the template
          let itemsHtml = "";
          data[key].forEach((item: any) => {
            itemsHtml += `<tr>
                            <td>${item.description || ""}</td>
                            <td>${item.quantity || 0}</td>
                            <td>${item.unit_price || 0}</td>
                            <td>${item.total_amount || 0}</td>
                         </tr>`; // Example structure
          });
          populatedHtml = populatedHtml.replace(/{{\s*line_items_rows\s*}}/, itemsHtml);
        }
        // Add more complex data handling (nested objects, dates, currency formatting) as needed
      }
    }
    // Remove any unreplaced placeholders (optional)
    populatedHtml = populatedHtml.replace(/{{\s*[^}]+\s*}}/g, "");
    return populatedHtml;
  }

  async generatePdfFromHtml(htmlContent: string, outputPath?: string): Promise<Buffer> {
    let browser = null;
    try {
      this.logger.log("Launching browser for PDF generation...");
      // For local development, playwright.chromium.launch() is fine.
      // For serverless/restricted environments, playwright-aws-lambda or similar might be needed.
      // browser = await playwright.chromium.launch(); // Use this if playwright-aws-lambda is not appropriate
      browser = await playwright.launchChromium(); // playwright-aws-lambda specific
      
      const context = await browser.newContext();
      const page = await context.newPage();
      
      this.logger.log("Setting HTML content for PDF generation...");
      await page.setContent(htmlContent, { waitUntil: "networkidle" });
      
      this.logger.log("Generating PDF buffer...");
      const pdfBuffer = await page.pdf({ 
        format: "A4",
        printBackground: true,
        margin: {
            top: "20mm",
            bottom: "20mm",
            left: "20mm",
            right: "20mm"
        }
      });

      if (outputPath) {
        this.logger.log(`Saving PDF to: ${outputPath}`);
        await fs.writeFile(outputPath, pdfBuffer);
        this.logger.log("PDF saved successfully.");
      }
      
      return pdfBuffer;
    } catch (error) {
      this.logger.error("Error generating PDF:", error);
      throw new InternalServerErrorException(`Failed to generate PDF: ${error.message}`);
    } finally {
      if (browser) {
        this.logger.log("Closing browser...");
        await browser.close();
      }
    }
  }

  async generateInvoicePdf(invoiceData: Invoice, template: InvoiceTemplate): Promise<Buffer> {
    this.logger.log(`Generating PDF for invoice ID: ${invoiceData.id} using template: ${template.template_name}`);
    
    // Assuming template.template_definition is an HTML string with placeholders like {{ field_name }}
    // Or it could be a JSON structure that this service knows how to convert to HTML.
    // For this example, let's assume template_definition.html is the HTML content.
    const htmlTemplate = (template.template_definition as any)?.html;
    if (!htmlTemplate || typeof htmlTemplate !== "string") {
        throw new InternalServerErrorException("Invalid HTML template definition in the selected template.");
    }

    // Prepare data for templating - flatten or structure as needed by the HTML template
    const templateData = {
        ...invoiceData,
        // You might need to format dates, numbers, currency etc.
        // Example: invoice_date_formatted: new Date(invoiceData.invoice_date).toLocaleDateString('en-IN'),
        // line_items: invoiceData.line_items.map(item => ({ ...item, total_amount: item.quantity * item.unit_price }))
    };

    const populatedHtml = this.populateHtmlTemplate(htmlTemplate, templateData);
    
    // For debugging, you might want to save the populated HTML
    // await fs.writeFile(path.join(__dirname, `_debug_invoice_${invoiceData.id}.html`), populatedHtml);

    return this.generatePdfFromHtml(populatedHtml);
  }
}


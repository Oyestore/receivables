#!/usr/bin/env python3
from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import Users
from diagrams.onprem.database import PostgreSQL
from diagrams.onprem.queue import Kafka
from diagrams.onprem.analytics import Spark
from diagrams.onprem.compute import Server
from diagrams.onprem.network import Nginx
from diagrams.programming.framework import React
from diagrams.programming.language import Python
from diagrams.generic.storage import Storage
from diagrams.generic.compute import Rack

# Create high-level system data flow diagram
with Diagram("AI Platform for SME Receivables Management - High Level Data Flow", show=False, filename="high_level_data_flow", outformat="png"):
    
    # External entities
    with Cluster("External Systems"):
        accounting = Rack("Accounting Systems")
        banking = Rack("Banking Systems")
        payment = Rack("Payment Gateways")
        govt = Rack("Government Systems")
        erp = Rack("ERP Systems")
    
    # Users
    with Cluster("Users"):
        sme_users = Users("SME Users")
        buyer_users = Users("Buyer Users")
        admin_users = Users("Admin Users")
    
    # Frontend
    with Cluster("Frontend"):
        web_ui = React("Web UI")
        mobile_ui = React("Mobile UI")
    
    # API Gateway
    api_gateway = Nginx("API Gateway")
    
    # Core Services
    with Cluster("Core Services"):
        auth_service = Server("Auth Service")
        invoice_service = Server("Invoice Service")
        payment_service = Server("Payment Service")
        notification_service = Server("Notification Service")
        analytics_service = Server("Analytics Service")
        integration_service = Server("Integration Service")
    
    # AI Agent Framework
    with Cluster("AI Agent Framework"):
        orchestrator = Python("Master Orchestration Agent")
        invoice_agent = Python("Invoice Generation Agent")
        rating_agent = Python("Rating Agent")
        terms_agent = Python("Terms Recommendation Agent")
        milestone_agent = Python("Milestone Tracking Agent")
        comm_agent = Python("Communication Agent")
        financing_agent = Python("Financing Agent")
        legal_agent = Python("Legal Agent")
        analytics_agent = Python("Analytics Agent")
        integration_agent = Python("Integration Agent")
        payment_agent = Python("Payment Agent")
    
    # Message Broker
    message_broker = Kafka("Message Broker")
    
    # Databases
    with Cluster("Data Storage"):
        main_db = PostgreSQL("Main Database")
        analytics_db = PostgreSQL("Analytics Database")
        document_store = Storage("Document Store")
    
    # Data Processing
    data_processing = Spark("Data Processing")
    
    # Flow connections
    
    # User interactions
    sme_users >> web_ui
    sme_users >> mobile_ui
    buyer_users >> web_ui
    buyer_users >> mobile_ui
    admin_users >> web_ui
    
    # Frontend to API
    web_ui >> api_gateway
    mobile_ui >> api_gateway
    
    # API to Services
    api_gateway >> auth_service
    api_gateway >> invoice_service
    api_gateway >> payment_service
    api_gateway >> notification_service
    api_gateway >> analytics_service
    
    # Services to Agents
    invoice_service >> orchestrator
    payment_service >> orchestrator
    notification_service >> orchestrator
    analytics_service >> orchestrator
    integration_service >> orchestrator
    
    # Orchestrator to Agents
    orchestrator >> invoice_agent
    orchestrator >> rating_agent
    orchestrator >> terms_agent
    orchestrator >> milestone_agent
    orchestrator >> comm_agent
    orchestrator >> financing_agent
    orchestrator >> legal_agent
    orchestrator >> analytics_agent
    orchestrator >> integration_agent
    orchestrator >> payment_agent
    
    # Agents to Message Broker
    invoice_agent >> message_broker
    rating_agent >> message_broker
    terms_agent >> message_broker
    milestone_agent >> message_broker
    comm_agent >> message_broker
    financing_agent >> message_broker
    legal_agent >> message_broker
    analytics_agent >> message_broker
    integration_agent >> message_broker
    payment_agent >> message_broker
    
    # Message Broker to Services
    message_broker >> invoice_service
    message_broker >> payment_service
    message_broker >> notification_service
    message_broker >> analytics_service
    message_broker >> integration_service
    
    # Services to Databases
    invoice_service >> main_db
    payment_service >> main_db
    notification_service >> main_db
    analytics_service >> analytics_db
    invoice_service >> document_store
    
    # Integration connections
    integration_service >> accounting
    integration_service >> banking
    integration_service >> payment
    integration_service >> govt
    integration_service >> erp
    
    # Data processing
    main_db >> data_processing
    data_processing >> analytics_db

# RabbitMQ Queue Management Implementation Guide

## Overview

This document provides comprehensive documentation for the RabbitMQ-based queue management system implemented for the Intelligent Invoice Distribution and Follow-up Agent. The system enhances reliability, scalability, and monitoring capabilities for multi-channel invoice distribution.

## Architecture

The queue management system follows a producer-consumer architecture using RabbitMQ as the message broker:

1. **Producers**: Services that send distribution requests to RabbitMQ queues
2. **Consumers**: Services that process distribution requests from RabbitMQ queues
3. **Queues**: Separate queues for each distribution channel (email, WhatsApp, SMS)
4. **Monitoring**: Health metrics and monitoring for all queues and operations

## Setup Instructions

### Prerequisites

- Docker and Docker Compose
- Node.js 16+ and npm
- NestJS application

### Installation

1. **Add RabbitMQ Docker Compose file**:
   - Place `docker-compose.rabbitmq.yml` in your project root
   - Run: `docker-compose -f docker-compose.rabbitmq.yml up -d`

2. **Install required dependencies**:
   ```bash
   npm install @nestjs/microservices amqp-connection-manager amqplib
   ```

3. **Add environment variables**:
   ```
   RABBITMQ_HOST=localhost
   RABBITMQ_PORT=5672
   RABBITMQ_USER=invoice_user
   RABBITMQ_PASSWORD=invoice_password
   ```

4. **Import QueueModule in your AppModule**:
   ```typescript
   import { QueueModule } from './queue/queue.module';

   @Module({
     imports: [
       // ... other modules
       QueueModule,
     ],
   })
   export class AppModule {}
   ```

## Usage Guide

### Sending Messages to Queues

To send distribution messages to queues, inject the `RabbitMQService` and use its methods:

```typescript
import { RabbitMQService } from './queue/services/rabbitmq.service';

@Injectable()
export class YourService {
  constructor(private readonly rabbitMQService: RabbitMQService) {}

  async distributeInvoice(invoiceData: any, channel: string) {
    // Send to appropriate queue based on channel
    return this.rabbitMQService.sendDistribution(invoiceData, channel);
  }

  async sendFollowUp(followUpData: any, channel: string) {
    // Send follow-up message
    return this.rabbitMQService.sendFollowUp(followUpData, channel);
  }
}
```

### Consuming Messages from Queues

The system automatically consumes messages using the channel-specific consumers:

- `EmailDistributionConsumer`
- `WhatsAppDistributionConsumer`
- `SmsDistributionConsumer`

These consumers are registered in the `DistributionConsumerModule` and will process messages as they arrive in the queues.

### Monitoring Queue Health

To monitor queue health, use the `QueueController` endpoints:

- `GET /queue/health` - Get health metrics for all queues
- `GET /queue/health/:queueName` - Get metrics for a specific queue
- `GET /queue/available/:channel` - Check if a specific channel queue is available
- `POST /queue/reset-metrics` - Reset all queue metrics
- `POST /queue/test/:channel` - Send a test message to a specific channel queue

## Error Handling

The queue management system includes comprehensive error handling:

1. **Connection Errors**: Automatically logged and tracked in health metrics
2. **Message Processing Errors**: Captured, logged, and tracked in queue metrics
3. **Timeout Handling**: Messages that exceed processing timeout are properly handled
4. **Retry Mechanism**: Failed messages can be retried based on configuration

## Testing

Unit and integration tests are provided for all queue management components:

- `rabbitmq.service.spec.ts` - Tests for the RabbitMQ service
- Integration tests for consumers and queue operations

Run tests with:
```bash
npm test -- src/queue/services/tests/rabbitmq.service.spec.ts
```

## Monitoring Dashboard

A monitoring dashboard is available through the RabbitMQ Management UI:

- URL: http://localhost:15672
- Username: invoice_user
- Password: invoice_password

This dashboard provides real-time visibility into queue status, message rates, and consumer activity.

## Best Practices

1. **Message Structure**: Include all necessary data in the message to avoid database lookups
2. **Message Size**: Keep messages small for optimal performance
3. **Acknowledgments**: Always acknowledge messages after successful processing
4. **Monitoring**: Regularly check queue health metrics
5. **Error Handling**: Implement proper error handling in all consumers

## Troubleshooting

Common issues and solutions:

1. **Connection Refused**: Ensure RabbitMQ container is running
2. **Authentication Failed**: Verify credentials in environment variables
3. **Queue Not Found**: Check queue names in configuration
4. **Message Processing Errors**: Check consumer logs for details

## Performance Considerations

- **Queue Persistence**: Durable queues ensure messages survive broker restarts
- **Prefetch Count**: Adjust based on consumer processing capacity
- **Message TTL**: Set appropriate time-to-live for messages
- **Queue Length Limits**: Monitor and set limits to prevent memory issues

## Security Considerations

- **Authentication**: Use strong credentials for RabbitMQ access
- **Network Security**: Restrict access to RabbitMQ ports
- **Message Encryption**: Consider encrypting sensitive data in messages
- **Access Control**: Use RabbitMQ's built-in access control features

## Future Enhancements

Potential improvements for the queue management system:

1. **Dead Letter Exchanges**: For handling failed messages
2. **Priority Queues**: For high-priority distributions
3. **Message Scheduling**: For delayed distributions
4. **Cluster Support**: For high availability
5. **Advanced Monitoring**: Integration with external monitoring systems

import { Test, TestingModule } from '@nestjs/testing';
import { RabbitMQService } from '../services/rabbitmq.service';
import { QueueHealthService } from '../services/queue-health.service';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { ConfigModule } from '@nestjs/config';
import { of, throwError } from 'rxjs';

describe('RabbitMQService', () => {
  let service: RabbitMQService;
  let queueHealthService: QueueHealthService;
  let clientProxyMock: any;

  beforeEach(async () => {
    // Create mock for ClientProxy
    clientProxyMock = {
      connect: jest.fn().mockResolvedValue(undefined),
      emit: jest.fn().mockReturnValue(of({ success: true })),
    };

    const module: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot(),
        ClientsModule.register([
          {
            name: 'DISTRIBUTION_SERVICE',
            transport: Transport.RMQ,
          },
        ]),
      ],
      providers: [RabbitMQService, QueueHealthService],
    })
      .overrideProvider('DISTRIBUTION_SERVICE')
      .useValue(clientProxyMock)
      .compile();

    service = module.get<RabbitMQService>(RabbitMQService);
    queueHealthService = module.get<QueueHealthService>(QueueHealthService);

    // Spy on queueHealthService methods
    jest.spyOn(queueHealthService, 'setStatus');
    jest.spyOn(queueHealthService, 'incrementMessagesSent');
    jest.spyOn(queueHealthService, 'incrementErrors');
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('onModuleInit', () => {
    it('should connect to RabbitMQ and set status to connected', async () => {
      await service.onModuleInit();
      
      expect(clientProxyMock.connect).toHaveBeenCalled();
      expect(queueHealthService.setStatus).toHaveBeenCalledWith('connected');
    });

    it('should handle connection errors and set status to disconnected', async () => {
      const error = new Error('Connection failed');
      clientProxyMock.connect.mockRejectedValue(error);
      
      await service.onModuleInit();
      
      expect(clientProxyMock.connect).toHaveBeenCalled();
      expect(queueHealthService.setStatus).toHaveBeenCalledWith('disconnected', error.message);
    });
  });

  describe('sendDistribution', () => {
    it('should send distribution to the correct queue and track metrics', () => {
      const data = { invoiceId: '123', recipientId: '456' };
      const channel = 'EMAIL';
      
      service.sendDistribution(data, channel);
      
      expect(clientProxyMock.emit).toHaveBeenCalledWith('email_distribution', data);
      expect(queueHealthService.incrementMessagesSent).toHaveBeenCalledWith('email_distribution');
    });

    it('should handle errors and track them', () => {
      const data = { invoiceId: '123', recipientId: '456' };
      const channel = 'EMAIL';
      const error = new Error('Send failed');
      
      clientProxyMock.emit.mockReturnValue(throwError(error));
      
      expect(() => service.sendDistribution(data, channel).subscribe()).toThrow();
      expect(queueHealthService.incrementErrors).toHaveBeenCalledWith('email_distribution');
    });
  });

  describe('sendFollowUp', () => {
    it('should send follow-up to the correct queue with isFollowUp flag', () => {
      const data = { invoiceId: '123', recipientId: '456' };
      const channel = 'WHATSAPP';
      
      service.sendFollowUp(data, channel);
      
      expect(clientProxyMock.emit).toHaveBeenCalledWith('whatsapp_distribution', {
        ...data,
        isFollowUp: true,
      });
      expect(queueHealthService.incrementMessagesSent).toHaveBeenCalledWith('whatsapp_distribution');
    });
  });

  describe('isQueueAvailable', () => {
    it('should check queue availability by sending a ping message', async () => {
      clientProxyMock.emit.mockReturnValue(of({ pong: true }));
      
      const result = await service.isQueueAvailable('SMS');
      
      expect(clientProxyMock.emit).toHaveBeenCalledWith('sms_distribution.ping', expect.any(Object));
      expect(result).toBe(true);
    });

    it('should return false if queue is not available', async () => {
      clientProxyMock.emit.mockReturnValue(throwError(new Error('Queue not available')));
      
      const result = await service.isQueueAvailable('SMS');
      
      expect(result).toBe(false);
    });
  });
});

import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InvoiceModule } from './invoices/invoice.module';
import { ProductServiceCatalogModule } from './product-service-catalog/product-service-catalog.module';
import { RecurringInvoiceProfileModule } from './recurring-invoices/recurring-invoice-profile.module';
import { ClientPreferenceModule } from './client-preferences/client-preference.module';
import { OcrIntegrationModule } from './ocr-integration/ocr-integration.module';
import { TemplateModule } from './templates/template.module'; // Added import for TemplateModule

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || "5432", 10),
      username: process.env.DB_USERNAME || 'postgres',
      password: process.env.DB_PASSWORD || 'password',
      database: process.env.DB_NAME || 'invoice_management',
      entities: [__dirname + '/../**/*.entity{.ts,.js}'],
      synchronize: process.env.NODE_ENV !== 'production', // Set to false in production
      autoLoadEntities: true,
    }),
    InvoiceModule,
    ProductServiceCatalogModule,
    RecurringInvoiceProfileModule,
    ClientPreferenceModule,
    OcrIntegrationModule,
    TemplateModule, // Added TemplateModule to imports
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}


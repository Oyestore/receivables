import { Injectable, NotFoundException, ConflictException, InternalServerErrorException } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { InvoiceTemplate } from "../entities/invoice-template.entity";
import { CreateInvoiceTemplateDto } from "../dto/create-invoice-template.dto";
import { UpdateInvoiceTemplateDto } from "../dto/update-invoice-template.dto";

@Injectable()
export class TemplateService {
  constructor(
    @InjectRepository(InvoiceTemplate)
    private readonly templateRepository: Repository<InvoiceTemplate>,
  ) {}

  async create(createInvoiceTemplateDto: CreateInvoiceTemplateDto): Promise<InvoiceTemplate> {
    try {
      const newTemplate = this.templateRepository.create(createInvoiceTemplateDto);
      return await this.templateRepository.save(newTemplate);
    } catch (error) {
      if (error.code === '23505') { // Unique constraint violation
        throw new ConflictException(`Template with name "${createInvoiceTemplateDto.template_name}" already exists for this organization.`);
      }
      throw new InternalServerErrorException("Error creating template: " + error.message);
    }
  }

  async findAll(organization_id: string): Promise<InvoiceTemplate[]> {
    return this.templateRepository.find({ where: { organization_id } });
  }

  async findOne(id: string, organization_id: string): Promise<InvoiceTemplate> {
    const template = await this.templateRepository.findOne({ where: { id, organization_id } });
    if (!template) {
      throw new NotFoundException(`Template with ID "${id}" not found for this organization.`);
    }
    return template;
  }

  async update(id: string, updateInvoiceTemplateDto: UpdateInvoiceTemplateDto, organization_id: string): Promise<InvoiceTemplate> {
    const template = await this.findOne(id, organization_id); // Ensures template exists and belongs to org
    
    // Prevent updating system templates directly if that's a rule
    if (template.is_system_template) {
        // Potentially allow duplicating a system template to a custom one, then updating that.
        // For now, let's assume direct update of system templates is disallowed or handled differently.
        // throw new ConflictException("System templates cannot be directly modified. Please duplicate it first.");
    }

    try {
        const updatedTemplate = await this.templateRepository.save({
            ...template, // existing values
            ...updateInvoiceTemplateDto, // new values
            id, // ensure id is not changed
          });
        return updatedTemplate;
    } catch (error) {
        if (error.code === '23505') { // Unique constraint violation on name if it's being updated
            throw new ConflictException(`Another template with name "${updateInvoiceTemplateDto.template_name}" may already exist for this organization.`);
          }
        throw new InternalServerErrorException("Error updating template: " + error.message);
    }
  }

  async remove(id: string, organization_id: string): Promise<void> {
    const template = await this.findOne(id, organization_id); // Ensures template exists and belongs to org
    if (template.is_system_template) {
      throw new ConflictException("System templates cannot be deleted.");
    }
    const result = await this.templateRepository.delete({ id, organization_id });
    if (result.affected === 0) {
      throw new NotFoundException(`Template with ID "${id}" not found for this organization.`);
    }
  }

  async setAsDefault(id: string, organization_id: string): Promise<InvoiceTemplate> {
    // First, unset any existing default for this organization
    await this.templateRepository.update(
      { organization_id, is_default_for_org: true },
      { is_default_for_org: false },
    );

    // Then, set the new default
    const templateToSet = await this.findOne(id, organization_id);
    templateToSet.is_default_for_org = true;
    return this.templateRepository.save(templateToSet);
  }

  async findDefault(organization_id: string): Promise<InvoiceTemplate | null> {
    return this.templateRepository.findOne({ where: { organization_id, is_default_for_org: true } });
  }

  // Placeholder for preview generation logic - this would be more complex
  async generatePreview(templateId: string, organization_id: string, sampleInvoiceData: any): Promise<string> {
    const template = await this.findOne(templateId, organization_id);
    // This is where the rendering engine would be called
    // For now, returning a placeholder
    return `Preview for template: ${template.template_name} with data. PDF generation logic to be implemented here.`;
    // In a real scenario, this would return a PDF stream or a URL to a temporary PDF.
  }
}


import { Module } from '@nestjs/common';
import { QueueModule } from '../queue/queue.module';
import { DistributionConsumerService } from './services/distribution-consumer.service';
import { EmailDistributionConsumer } from './consumers/email-distribution.consumer';
import { WhatsAppDistributionConsumer } from './consumers/whatsapp-distribution.consumer';
import { SmsDistributionConsumer } from './consumers/sms-distribution.consumer';

@Module({
  imports: [QueueModule],
  providers: [
    DistributionConsumerService,
    EmailDistributionConsumer,
    WhatsAppDistributionConsumer,
    SmsDistributionConsumer,
  ],
  exports: [DistributionConsumerService],
})
export class DistributionConsumerModule {}

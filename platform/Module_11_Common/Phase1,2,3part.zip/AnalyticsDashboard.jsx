import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Box, 
  Tabs, 
  Tab, 
  CircularProgress,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Alert
} from '@mui/material';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import RefreshIcon from '@mui/icons-material/Refresh';
import DownloadIcon from '@mui/icons-material/Download';
import WarningIcon from '@mui/icons-material/Warning';

/**
 * Advanced Analytics Dashboard Component
 * Provides comprehensive visualization of distribution metrics, follow-up performance,
 * system health, and template effectiveness
 */
const AnalyticsDashboard = () => {
  // State for dashboard data
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [timeRange, setTimeRange] = useState('week');
  const [refreshing, setRefreshing] = useState(false);
  const [alertOpen, setAlertOpen] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSeverity, setAlertSeverity] = useState('info');

  // Colors for charts
  const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088FE', '#00C49F'];
  const channelColors = {
    email: '#8884d8',
    whatsapp: '#82ca9d',
    sms: '#ffc658'
  };

  // Load dashboard data on component mount and when time range changes
  useEffect(() => {
    fetchDashboardData();
    // Set up interval for real-time updates (every 30 seconds)
    const interval = setInterval(() => {
      fetchDashboardData(false); // Silent refresh
    }, 30000);
    
    return () => clearInterval(interval);
  }, [timeRange]);

  // Fetch dashboard data from API
  const fetchDashboardData = async (showLoading = true) => {
    if (showLoading) {
      setLoading(true);
    } else {
      setRefreshing(true);
    }
    
    try {
      // In a real implementation, this would be an API call
      // const response = await fetch('/api/analytics/dashboard');
      // const data = await response.json();
      
      // For demonstration, we'll simulate API response with mock data
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay
      const data = getMockDashboardData();
      
      setDashboardData(data);
      setError(null);
      
      if (!showLoading) {
        setAlertMessage('Dashboard data refreshed successfully');
        setAlertSeverity('success');
        setAlertOpen(true);
      }
    } catch (err) {
      setError('Failed to load dashboard data. Please try again.');
      setAlertMessage('Error loading dashboard data');
      setAlertSeverity('error');
      setAlertOpen(true);
    } finally {
      if (showLoading) {
        setLoading(false);
      } else {
        setRefreshing(false);
      }
    }
  };

  // Handle tab change
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  // Handle time range change
  const handleTimeRangeChange = (event) => {
    setTimeRange(event.target.value);
  };

  // Handle manual refresh
  const handleRefresh = () => {
    fetchDashboardData(false);
  };

  // Handle alert close
  const handleAlertClose = () => {
    setAlertOpen(false);
  };

  // Handle report generation
  const handleGenerateReport = (format) => {
    setAlertMessage(`Generating ${format} report...`);
    setAlertSeverity('info');
    setAlertOpen(true);
    
    // In a real implementation, this would call an API to generate the report
    setTimeout(() => {
      setAlertMessage(`${format.toUpperCase()} report generated successfully`);
      setAlertSeverity('success');
      setAlertOpen(true);
    }, 2000);
  };

  // Render loading state
  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
        <Typography variant="h6" sx={{ ml: 2 }}>
          Loading Analytics Dashboard...
        </Typography>
      </Box>
    );
  }

  // Render error state
  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <Alert severity="error" sx={{ width: '80%' }}>
          {error}
          <Button color="inherit" size="small" onClick={() => fetchDashboardData()}>
            Retry
          </Button>
        </Alert>
      </Box>
    );
  }

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      {/* Dashboard Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Analytics Dashboard
        </Typography>
        
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <FormControl variant="outlined" size="small" sx={{ minWidth: 120, mr: 2 }}>
            <InputLabel>Time Range</InputLabel>
            <Select
              value={timeRange}
              onChange={handleTimeRangeChange}
              label="Time Range"
            >
              <MenuItem value="day">Today</MenuItem>
              <MenuItem value="week">This Week</MenuItem>
              <MenuItem value="month">This Month</MenuItem>
              <MenuItem value="quarter">This Quarter</MenuItem>
            </Select>
          </FormControl>
          
          <Button 
            variant="outlined" 
            startIcon={<RefreshIcon />} 
            onClick={handleRefresh}
            disabled={refreshing}
            sx={{ mr: 2 }}
          >
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </Button>
          
          <Button 
            variant="outlined" 
            startIcon={<DownloadIcon />}
            onClick={() => handleGenerateReport('pdf')}
            sx={{ mr: 2 }}
          >
            Export PDF
          </Button>
          
          <Button 
            variant="outlined" 
            startIcon={<DownloadIcon />}
            onClick={() => handleGenerateReport('csv')}
          >
            Export CSV
          </Button>
        </Box>
      </Box>

      {/* Dashboard Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="fullWidth"
        >
          <Tab label="Overview" />
          <Tab label="Distribution Metrics" />
          <Tab label="Follow-up Performance" />
          <Tab label="Template Analysis" />
          <Tab label="System Health" />
        </Tabs>
      </Paper>

      {/* Dashboard Content */}
      <Box sx={{ display: activeTab === 0 ? 'block' : 'none' }}>
        <OverviewDashboard data={dashboardData} colors={colors} channelColors={channelColors} />
      </Box>
      
      <Box sx={{ display: activeTab === 1 ? 'block' : 'none' }}>
        <DistributionDashboard data={dashboardData?.distributionMetrics} colors={colors} channelColors={channelColors} />
      </Box>
      
      <Box sx={{ display: activeTab === 2 ? 'block' : 'none' }}>
        <FollowUpDashboard data={dashboardData?.followUpMetrics} colors={colors} />
      </Box>
      
      <Box sx={{ display: activeTab === 3 ? 'block' : 'none' }}>
        <TemplateDashboard data={dashboardData?.templatePerformance} colors={colors} />
      </Box>
      
      <Box sx={{ display: activeTab === 4 ? 'block' : 'none' }}>
        <SystemHealthDashboard data={dashboardData?.systemPerformance} queueHealth={dashboardData?.queueHealth} colors={colors} />
      </Box>

      {/* Alerts */}
      <Snackbar open={alertOpen} autoHideDuration={6000} onClose={handleAlertClose}>
        <Alert onClose={handleAlertClose} severity={alertSeverity} sx={{ width: '100%' }}>
          {alertMessage}
        </Alert>
      </Snackbar>
    </Container>
  );
};

// Overview Dashboard Component
const OverviewDashboard = ({ data, colors, channelColors }) => {
  if (!data) return null;
  
  // Prepare data for channel distribution chart
  const channelDistributionData = [
    { name: 'Email', value: data.distributionMetrics.volumeByChannel.email.total },
    { name: 'WhatsApp', value: data.distributionMetrics.volumeByChannel.whatsapp.total },
    { name: 'SMS', value: data.distributionMetrics.volumeByChannel.sms.total },
  ];
  
  // Prepare data for success rates chart
  const successRatesData = [
    { name: 'Email', rate: data.distributionMetrics.deliveryRates.email * 100 },
    { name: 'WhatsApp', rate: data.distributionMetrics.deliveryRates.whatsapp * 100 },
    { name: 'SMS', rate: data.distributionMetrics.deliveryRates.sms * 100 },
  ];
  
  // Prepare data for follow-up effectiveness chart
  const followUpData = [
    { name: '1st Follow-up', conversion: data.followUpMetrics.paymentConversion.afterFirstFollowUp * 100 },
    { name: '2nd Follow-up', conversion: data.followUpMetrics.paymentConversion.afterSecondFollowUp * 100 },
    { name: '3rd Follow-up', conversion: data.followUpMetrics.paymentConversion.afterThirdFollowUp * 100 },
  ];
  
  // Prepare data for template performance chart
  const templateData = Object.entries(data.templatePerformance.openRates.byTemplate).map(([key, value]) => ({
    name: key,
    openRate: value * 100,
    conversionRate: data.templatePerformance.conversionRates.byTemplate[key] * 100,
  }));

  return (
    <Grid container spacing={3}>
      {/* Key Metrics */}
      <Grid item xs={12}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6" gutterBottom>
            Key Performance Indicators
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
                <Typography variant="h3" color="primary">
                  {(data.distributionMetrics.volumeByChannel.email.total + 
                    data.distributionMetrics.volumeByChannel.whatsapp.total + 
                    data.distributionMetrics.volumeByChannel.sms.total).toLocaleString()}
                </Typography>
                <Typography variant="body1">Total Distributions</Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
                <Typography variant="h3" color="primary">
                  {(data.distributionMetrics.deliveryRates.overall * 100).toFixed(1)}%
                </Typography>
                <Typography variant="body1">Delivery Success Rate</Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
                <Typography variant="h3" color="primary">
                  {(data.followUpMetrics.paymentConversion.overall * 100).toFixed(1)}%
                </Typography>
                <Typography variant="body1">Payment Conversion</Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
                <Typography variant="h3" color="primary">
                  {data.followUpMetrics.timeToPayment.average.toFixed(1)}
                </Typography>
                <Typography variant="body1">Avg. Days to Payment</Typography>
              </Box>
            </Grid>
          </Grid>
        </Paper>
      </Grid>

      {/* Distribution by Channel */}
      <Grid item xs={12} md={6}>
        <Paper sx={{ p: 2, height: 300 }}>
          <Typography variant="h6" gutterBottom>
            Distribution by Channel
          </Typography>
          <ResponsiveContainer width="100%" height="90%">
            <PieChart>
              <Pie
                data={channelDistributionData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {channelDistributionData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={Object.values(channelColors)[index % Object.values(channelColors).length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => value.toLocaleString()} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>

      {/* Delivery Success Rates */}
      <Grid item xs={12} md={6}>
        <Paper sx={{ p: 2, height: 300 }}>
          <Typography variant="h6" gutterBottom>
            Delivery Success Rates
          </Typography>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={successRatesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip formatter={(value) => `${value.toFixed(1)}%`} />
              <Legend />
              <Bar dataKey="rate" name="Success Rate (%)" fill="#8884d8">
                {successRatesData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={Object.values(channelColors)[index % Object.values(channelColors).length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>

      {/* Follow-up Effectiveness */}
      <Grid item xs={12} md={6}>
        <Paper sx={{ p: 2, height: 300 }}>
          <Typography variant="h6" gutterBottom>
            Follow-up Effectiveness
          </Typography>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={followUpData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip formatter={(value) => `${value.toFixed(1)}%`} />
              <Legend />
              <Bar dataKey="conversion" name="Payment Conversion (%)" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>

      {/* Template Performance */}
      <Grid item xs={12} md={6}>
        <Paper sx={{ p: 2, height: 300 }}>
          <Typography variant="h6" gutterBottom>
            Template Performance
          </Typography>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={templateData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip formatter={(value) => `${value.toFixed(1)}%`} />
              <Legend />
              <Bar dataKey="openRate" name="Open Rate (%)" fill="#8884d8" />
              <Bar dataKey="conversionRate" name="Conversion Rate (%)" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>

      {/* System Health Summary */}
      <Grid item xs={12}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6" gutterBottom>
            System Health Summary
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
                <Typography variant="h3" color={data.systemPerformance.errorRates.overall < 0.05 ? "success.main" : "error.main"}>
                  {(data.systemPerformance.errorRates.overall * 100).toFixed(2)}%
                </Typography>
                <Typography variant="body1">Error Rate</Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ textAlign: 'center', p: 2 }}>
  
(Content truncated due to size limit. Use line ranges to read in chunks)
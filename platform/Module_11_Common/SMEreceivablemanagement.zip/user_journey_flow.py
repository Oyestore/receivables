#!/usr/bin/env python3
from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import Users
from diagrams.onprem.database import PostgreSQL
from diagrams.onprem.queue import Kafka
from diagrams.programming.framework import React
from diagrams.programming.language import Python
from diagrams.generic.storage import Storage
from diagrams.generic.compute import Rack
from diagrams.generic.place import Datacenter

# Create user journey flow diagram for invoice creation and payment
with Diagram("AI Platform for SME Receivables Management - User Journey Flow", show=False, filename="user_journey_flow", outformat="png"):
    
    # SME User
    sme_user = Users("SME User")
    
    # Buyer User
    buyer_user = Users("Buyer User")
    
    # Frontend
    with Cluster("Frontend"):
        web_ui = React("Web UI")
    
    # Core Services
    with Cluster("Core Services"):
        invoice_service = Python("Invoice Service")
        payment_service = Python("Payment Service")
        notification_service = Python("Notification Service")
    
    # AI Agents
    with Cluster("AI Agents"):
        invoice_agent = Python("Invoice Generation Agent")
        terms_agent = Python("Terms Recommendation Agent")
        rating_agent = Python("Rating Agent")
        comm_agent = Python("Communication Agent")
        payment_agent = Python("Payment Agent")
    
    # Data Stores
    with Cluster("Data Stores"):
        main_db = PostgreSQL("Main Database")
        document_store = Storage("Document Store")
        message_broker = Kafka("Message Broker")
    
    # External Systems
    with Cluster("External Systems"):
        accounting = Rack("Accounting Systems")
        banking = Rack("Banking Systems")
        payment_gateways = Rack("Payment Gateways")
    
    # User Journey Flow - SME User Creates Invoice
    sme_user >> Edge(label="1. Login") >> web_ui
    web_ui >> Edge(label="2. Create Invoice") >> invoice_service
    invoice_service >> Edge(label="3. Generate Invoice") >> invoice_agent
    invoice_agent >> Edge(label="4. Get Terms") >> terms_agent
    terms_agent >> Edge(label="5. Recommend Terms") >> invoice_agent
    invoice_agent >> Edge(label="6. Get Buyer Rating") >> rating_agent
    rating_agent >> Edge(label="7. Provide Rating") >> invoice_agent
    invoice_agent >> Edge(label="8. Create Invoice") >> invoice_service
    invoice_service >> Edge(label="9. Store Invoice") >> document_store
    invoice_service >> Edge(label="10. Notify") >> notification_service
    notification_service >> Edge(label="11. Send Invoice") >> comm_agent
    comm_agent >> Edge(label="12. Deliver Invoice") >> buyer_user
    
    # User Journey Flow - Buyer Pays Invoice
    buyer_user >> Edge(label="13. Login") >> web_ui
    web_ui >> Edge(label="14. View Invoice") >> invoice_service
    web_ui >> Edge(label="15. Make Payment") >> payment_service
    payment_service >> Edge(label="16. Process Payment") >> payment_agent
    payment_agent >> Edge(label="17. Verify Payment") >> banking
    banking >> Edge(label="18. Confirm Payment") >> payment_agent
    payment_agent >> Edge(label="19. Update Status") >> payment_service
    payment_service >> Edge(label="20. Store Payment") >> main_db
    payment_service >> Edge(label="21. Notify") >> notification_service
    notification_service >> Edge(label="22. Send Confirmation") >> comm_agent
    comm_agent >> Edge(label="23. Notify Payment") >> sme_user
    
    # Accounting Integration
    payment_service >> Edge(label="24. Sync Data") >> accounting

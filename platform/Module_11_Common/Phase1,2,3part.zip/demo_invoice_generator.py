import json
import re
from playwright.sync_api import sync_playwright
import os

def format_currency(value):
    return f"{value:,.2f}"

def format_percentage(value):
    return f"{value * 100:.0f}%"

def generate_invoice_pdf(data_path, template_path, output_path):
    # 1. Load Invoice Data
    with open(data_path, 'r') as f:
        invoice_data = json.load(f)

    # 2. Mock External Data
    external_data = {
        "customer_loyalty_status": "Gold",
        "loyalty_points_earned": 125
    }
    # Add to main data context for easier templating
    invoice_data['external_data'] = external_data

    # 3. Perform Calculations
    calculated_subtotal = 0
    calculated_total_tax = 0
    calculated_total_amount = 0

    for item in invoice_data['invoice']['items']:
        item['taxable_amount'] = item['quantity'] * item['unit_price']
        item['tax_amount'] = item['taxable_amount'] * item['tax_rate']
        item['total_item_amount'] = item['taxable_amount'] + item['tax_amount']
        
        calculated_subtotal += item['taxable_amount']
        calculated_total_tax += item['tax_amount']
        calculated_total_amount += item['total_item_amount']

    invoice_data['invoice']['calculated_subtotal'] = calculated_subtotal
    invoice_data['invoice']['calculated_total_tax'] = calculated_total_tax
    invoice_data['invoice']['calculated_total_amount'] = calculated_total_amount

    # 4. Load HTML Template
    with open(template_path, 'r') as f:
        html_content = f.read()

    # 5. Conditional Logic Evaluation and HTML manipulation
    # Condition 1: High Value Order
    condition1_met = invoice_data['invoice']['calculated_total_amount'] > 80000
    if condition1_met:
        # If condition met, ensure the block is present (it is by default)
        # If we needed to *add* it, that would be more complex here.
        # For removal if not met:
        pass # Block is kept
    else:
        # Remove the block. This is a simplified regex removal.
        # It assumes the block is clearly delimited by comments or unique attributes.
        # The current template uses class="conditional-section" and the data-gjs-conditions attribute.
        html_content = re.sub(r'<div class="conditional-section" data-gjs-conditions=\"\[\{\&quot;groupLogic\&quot;:\&quot;AND\&quot;,.+?\}\]\">.*?</div>',
                              '', html_content, flags=re.DOTALL)

    # Condition 2: Loyalty Program
    condition2_met = 'external_data' in invoice_data and invoice_data['external_data'].get('customer_loyalty_status') == "Gold"
    if condition2_met:
        pass # Block is kept
    else:
        html_content = re.sub(r'<div class="external-data-section" data-gjs-conditions=\"\[\{\&quot;groupLogic\&quot;:\&quot;AND\&quot;,.+?\}\]\">.*?</div>',
                              '', html_content, flags=re.DOTALL)

    # 6. Templating (Simplified)
    # Replace simple placeholders
    for key_path, value in [
        ('company.logo_url', invoice_data['company']['logo_url']),
        ('company.name', invoice_data['company']['name']),
        ('company.address', invoice_data['company']['address']),
        ('company.gstin', invoice_data['company']['gstin']),
        ('invoice.number', invoice_data['invoice']['number']),
        ('invoice.date', invoice_data['invoice']['date']),
        ('invoice.due_date', invoice_data['invoice']['due_date']),
        ('recipient.name', invoice_data['recipient']['name']),
        ('recipient.address', invoice_data['recipient']['address']),
        ('recipient.gstin', invoice_data['recipient']['gstin']),
        ('invoice.currency', invoice_data['invoice']['currency']),
        ('invoice.calculated_subtotal', format_currency(invoice_data['invoice']['calculated_subtotal'])),
        ('invoice.calculated_total_tax', format_currency(invoice_data['invoice']['calculated_total_tax'])),
        ('invoice.calculated_total_amount', format_currency(invoice_data['invoice']['calculated_total_amount'])),
        ('invoice.notes', invoice_data['invoice']['notes']),
        ('invoice.terms_conditions', invoice_data['invoice']['terms_conditions']),
        ('external_data.customer_loyalty_status', invoice_data.get('external_data',{}).get('customer_loyalty_status','')),
        ('external_data.loyalty_points_earned', str(invoice_data.get('external_data',{}).get('loyalty_points_earned',''))),
    ]:
        html_content = html_content.replace(f'{{{{{key_path}}}}}', str(value))

    # Item templating (very basic loop)
    item_rows_html = ""
    for i, item in enumerate(invoice_data['invoice']['items']):
        item_rows_html += f"""
        <tr>
            <td>{i+1}</td>
            <td>{item['description']}</td>
            <td>{item['hsn_sac']}</td>
            <td class=\"text-right\">{item['quantity']}</td>
            <td class=\"text-right\">{format_currency(item['unit_price'])}</td>
            <td class=\"text-right\">{format_currency(item['taxable_amount'])}</td>
            <td class=\"text-right\">{format_percentage(item['tax_rate'])}</td>
            <td class=\"text-right\">{format_currency(item['tax_amount'])}</td>
            <td class=\"text-right\">{format_currency(item['total_item_amount'])}</td>
        </tr>
        """
    # This regex is specific to the template's loop structure.
    html_content = re.sub(r'{{#each invoice.items}}.*?{{/each}}',
                          item_rows_html, html_content, flags=re.DOTALL)
    
    # Replace @index_1 if it was missed by the above simple loop (it was)
    # This is a hack because the simple loop doesn't handle @index_1 well.
    # A proper templating engine would be better.
    # For now, we'll assume the loop above correctly generates the item numbers.

    # Replace formatCurrency and formatPercentage calls if any remain as placeholders
    # This is also a simplification; a real templating engine would handle helpers.
    # The current loop directly applies formatting.

    # 7. Generate PDF using Playwright
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.set_content(html_content)
        page.pdf(path=output_path, format='A4', print_background=True)
        browser.close()
    print(f"Invoice generated at {output_path}")

if __name__ == '__main__':
    data_file = '/home/ubuntu/invoice_data.json'
    template_file = '/home/ubuntu/invoice_template.html'
    output_pdf = '/home/ubuntu/generated_invoice_demo.pdf'
    generate_invoice_pdf(data_file, template_file, output_pdf)


# Invoice Generation Agent: Module Specifications

## 1. Overview

This document outlines the specifications for the Invoice Generation Agent module, a core component of the SME Receivables Management Platform. This agent is responsible for smart invoice creation, management, template handling, and tax calculations.

## 2. Core Responsibilities (based on original requirements and user input)

### 2.1. Phase 1.1: Core Invoice Data & AI-Assisted Creation
    - Robust invoice data structure (supporting multi-tenancy).
    - Manual invoice creation with comprehensive validation.
    - AI-assisted data extraction from uploaded **existing invoice documents (PDFs/images)** using OCR and basic parsing to pre-fill invoice fields.
        - Target fields: Invoice Number, Dates, Vendor/Client details, Line Items (Description, Quantity, Unit Price, Total), Subtotal, Taxes, Grand Total, Payment Terms.

### 2.2. Phase 1.2: Advanced Invoice Template Management
    - System for creating, customizing, storing, and managing multiple invoice templates per tenant.
    - Ability for users to select a template during invoice creation.
    - Templates should support dynamic fields for invoice data.

### 2.3. Phase 1.3: Customizable Tax Engine (Indian Taxation System Focus)
    - Sub-module for calculating taxes, with initial focus on Indian GST compliance.
    - Support for defining and customizing tax rates, rules, and logic (e.g., CGST, SGST, IGST).
    - Ability to apply different tax rules based on product/service, client location, etc.
    - Tax details should be clearly itemized on invoices.

## 3. Key Features & Enhancements (To be detailed further with suggestions)

### 3.1. Recurring Invoices
    *   **Functionality:** Allow users to define invoices that are automatically generated and (optionally) flagged for sending on a predefined schedule (e.g., weekly, monthly, quarterly, annually). Users should be able to set start dates, end dates (or ongoing), and the frequency.
    *   **Value:** Automates billing for retainers, subscriptions, or regular services, saving significant time and reducing the risk of missed invoices.
    *   **Implementation Notes:** Leverages the existing invoice data structure and template system. Requires a scheduling mechanism (e.g., a cron job or a scheduled task runner within the backend) and a way to manage the status of recurring profiles.

### 3.2. Duplicate/Copy Invoice Feature
    *   **Functionality:** Provide a simple one-click option to duplicate an existing invoice. The new invoice would be a draft, pre-filled with all details from the original, which the user can then modify (e.g., change dates, line items, or amounts) before saving or sending.
    *   **Value:** Extremely useful for businesses that send similar invoices frequently. Speeds up the creation process significantly.
    *   **Implementation Notes:** Relatively straightforward CRUD operation.

### 3.3. Product/Service Catalog Management
    *   **Functionality:** Allow users (at the tenant level) to create and manage a catalog of their standard products or services. Each item could include a name/ID, description, default unit price, and default tax applicability (linking to the tax engine).
    *   **Value:** When creating an invoice, users can quickly search and select items from this catalog to add as line items, auto-populating description, price, and tax. This ensures consistency, reduces manual entry errors, and speeds up invoice creation.
    *   **Implementation Notes:** Requires new database tables for products/services per tenant and UI for managing the catalog and selecting items during invoice creation.

### 3.4. Client-Specific Defaults
    *   **Functionality:** Allow users to set default values at the client/customer level. These could include default payment terms, standard notes (e.g., "Thank you for your business!"), a preferred invoice template, or even default discount percentages.
    *   **Value:** When a new invoice is created for a specific client, these defaults are automatically applied, further reducing manual input and ensuring consistency in client communication.
    *   **Implementation Notes:** Requires extending the client/customer data model to store these preferences.

### 3.5. Enhanced Real-time Invoice Preview & Robust Validation
    *   **Functionality:** As the user is creating or editing an invoice, provide a clear, accurate, real-time preview of how the final invoice will look based on the selected template and data entered. Implement more comprehensive client-side and server-side validation for all fields (e.g., date formats, numeric inputs, required fields, valid tax codes) before allowing save or send operations.
    *   **Value:** Improves user confidence, reduces errors, and provides immediate feedback, leading to a better user experience.
    *   **Implementation Notes:** Frontend development for the preview component, potentially using a library to render HTML/CSS based on the template. Enhanced validation logic on both frontend and backend.

### 3.6. Simple Invoice Import from Structured Data (e.g., CSV/Excel)
    *   **Functionality:** Allow users to upload a simple CSV or Excel file containing invoice data (e.g., client name, item descriptions, quantities, prices) to create multiple invoices or multiple line items for a single invoice in bulk. Provide a clear template/format for the upload.
    *   **Value:** Useful for users who manage billing data in spreadsheets or export it from other systems. Can be a significant time-saver for bulk operations.
    *   **Implementation Notes:** Requires a parser for CSV/Excel files and mapping logic to create invoice records. Clear error handling for malformed files or data is essential.

These suggestions focus on improving workflow efficiency, data management, and user experience around the invoice creation process. They leverage the core structures already planned for the Invoice Generation Agent (like template management and the tax engine) and do not necessitate advanced NLP or complex AI for parsing unstructured documents like contracts or POs within the current module's defined scope. They represent achievable enhancements that can deliver substantial value to users.

## 4. Non-Functional Requirements
    - **Modularity:** The agent must be a self-contained module.
    - **Multi-tenancy:** Full data isolation and tenant-specific configurations for templates, taxes, etc.
    - **Extensibility:** Designed for future enhancements.
    - **Usability:**
        - Intuitive interface for all invoice management tasks.
        - Visual Cues and Guided Workflows:
            - Implement step-by-step visual guidance for complex processes, particularly for smart invoice generation and initial setup tasks.
            - Clearly highlight stages within a workflow (e.g., using progress bars, step indicators, or visual checklists).
            - Visually distinguish and clearly indicate points where user input is required.
            - Differentiate between one-time setup inputs (e.g., initial customer configuration, template setup) and inputs needed for each transaction (e.g., specific invoice details).
            - Ensure visual aids are intuitive, non-intrusive, and genuinely assist the user in completing tasks efficiently and accurately.
            - This principle of guided workflows with visual cues should be considered for all user-facing processes within this module.

## 5. API Endpoints (Initial Draft - To be refined)
    - `POST /api/invoices` (Create new invoice, supports AI-assist from upload)
    - `GET /api/invoices` (List invoices with filtering/pagination)
    - `GET /api/invoices/{invoice_id}` (Retrieve specific invoice)
    - `PUT /api/invoices/{invoice_id}` (Update invoice)
    - `DELETE /api/invoices/{invoice_id}` (Delete invoice)
    - `POST /api/invoice-templates` (Create template)
    - `GET /api/invoice-templates` (List templates for tenant)
    - `GET /api/invoice-templates/{template_id}` (Retrieve template)
    - `PUT /api/invoice-templates/{template_id}` (Update template)
    - `POST /api/tax-configurations` (Define/update tax rules for tenant)
    - `GET /api/tax-configurations` (Retrieve tax rules for tenant)

## 6. Data Models (Initial Draft - To be refined)
    - Invoice (tenant_id, client_id, invoice_number, issue_date, due_date, status, currency, line_items, sub_total, tax_details, total_amount, notes, template_id, etc.)
    - InvoiceLineItem (description, quantity, unit_price, amount, tax_rate_id)
    - InvoiceTemplate (tenant_id, name, content_structure, default_template_flag)
    - TaxConfiguration (tenant_id, tax_name, tax_rate, applicability_rules)
    - ProductServiceCatalog (tenant_id, item_name, description, default_price, default_tax_id) (Placeholder for enhancement)
    - RecurringInvoiceProfile (tenant_id, client_id, template_id, frequency, start_date, end_date, next_run_date) (Placeholder for enhancement)




## 7. Architectural Design

This section outlines the architectural blueprint for the Invoice Generation Agent module, focusing on its structure, components, interactions, and non-functional requirements like modularity, multi-tenancy, and scalability.

### 7.1. Module Overview and Placement

The Invoice Generation Agent is a core, self-contained backend module within the SME Receivables Management Platform. Its primary responsibility encompasses the entire lifecycle of invoice creation, management, and processing, including AI-assisted data extraction, template application, and tax calculations.

*   **Responsibilities:** Smart invoice creation (manual, AI-assisted, recurring, duplication), template management, tax computation, product/service catalog integration, and client-specific defaults application.
*   **Interactions:**
    *   Exposes a set of RESTful APIs for consumption by the frontend client application.
    *   May interact with other future backend agents or services (e.g., a dedicated Notifications Agent, Analytics Agent) via internal APIs or message queues.
    *   Interacts with the shared PostgreSQL database, strictly enforcing tenant data isolation for all operations.
    *   Communicates with an AI service (internal or external) for OCR and data extraction from uploaded documents.

### 7.2. High-Level Components

The agent will be structured with a layered architecture:

1.  **API Layer (Controller Layer):**
    *   Built using Node.js with a framework like Express.js or NestJS (recommended for structure and scalability).
    *   Handles incoming HTTP requests, routing them to appropriate service layer methods.
    *   Manages request validation (data types, required fields, formats).
    *   Handles authentication and authorization (e.g., validating JWTs, ensuring user has permissions for the tenant and action). This might leverage a shared authentication module/middleware if available platform-wide.
    *   Formats API responses (success data, error messages).

2.  **Service Layer (Business Logic Layer):**
    *   Contains the core business logic and orchestrates operations for all features of the Invoice Generation Agent.
    *   Implements the functionalities defined in Sections 2 and 3 of this document.
    *   Coordinates interactions between internal sub-modules (Core Invoice Engine, Template Management, Tax Engine) and the Data Access Layer.
    *   Manages transactions and ensures data consistency.
    *   Interfaces with the AI Integration Service Client for OCR tasks.

3.  **Data Access Layer (DAL):**
    *   Abstracts all database interactions, providing a clear API for the Service Layer to perform CRUD (Create, Read, Update, Delete) operations.
    *   Will use an ORM (e.g., Sequelize for PostgreSQL) or a robust query builder to interact with the PostgreSQL database.
    *   Critically, all database queries performed by the DAL must enforce multi-tenancy by including `tenant_id` filters to ensure strict data isolation.
    *   Manages database connections and pooling.

4.  **AI Integration Service Client:**
    *   A dedicated component (e.g., a class or service) responsible for all communication with the external/internal AI OCR service.
    *   Handles formatting requests to the AI service (e.g., sending document data/streams) and parsing its responses (e.g., structured JSON output).
    *   Manages API keys, authentication, and error handling related to the AI service.

### 7.3. Internal Sub-modules (Logical Grouping within Service Layer)

These are not necessarily separate microservices initially but represent distinct areas of responsibility within the Invoice Generation Agent's service layer. They can be developed as well-defined classes or sets of functions.

1.  **Core Invoice Processing Engine:**
    *   Manages the lifecycle of invoices: creation (manual, AI-assisted from OCR data, duplication, recurring), validation, storage, retrieval, updates, and status changes (e.g., draft, sent, paid, void).
    *   Handles the logic for generating invoice numbers (tenant-specific sequences).
    *   Orchestrates the application of client defaults, product catalog items, and tax calculations during invoice creation/update.
    *   Manages bulk import of invoices from structured data (e.g., CSV).

2.  **Template Management Sub-module:**
    *   Manages CRUD operations for invoice templates, ensuring they are tenant-specific.
    *   Provides functionality to select and apply a template to an invoice.
    *   Handles the rendering of invoice data into a final presentable format (e.g., HTML for preview, PDF for download/sending). This may involve using a templating engine (e.g., Handlebars, EJS) and a PDF generation library (e.g., Puppeteer, pdf-lib).

3.  **Tax Engine Sub-module:**
    *   Manages tax configurations, rules, and rates, specific to each tenant, with a primary focus on the Indian GST system.
    *   Provides an interface to calculate applicable taxes for each line item and the overall invoice based on product/service type, client location, and tenant-specific tax rules.
    *   Ensures tax details are correctly structured for display on the invoice and for reporting.

### 7.4. Technology Stack (Confirmation)

*   **Backend Framework:** Node.js with NestJS (preferred for its modular architecture, TypeScript support, and scalability features) or Express.js.
*   **Database:** PostgreSQL.
*   **AI Service Communication:** HTTP/S API calls to the designated AI OCR service.
*   **PDF Generation:** A suitable Node.js library (e.g., Puppeteer for HTML-to-PDF, or a direct PDF manipulation library).
*   **Caching (Optional but Recommended for Scale):** Redis for caching frequently accessed, rarely changing data (e.g., tenant configurations, compiled templates).
*   **Job Queue (Optional but Recommended for Scale):** For handling asynchronous tasks like bulk imports or complex report generation (e.g., BullMQ with Redis).
*   **Deployment:** Dockerized containers orchestrated by Docker Compose (for initial setup) and designed for future deployment on platforms like Kubernetes for scalability.

### 7.5. Data Flow Examples

*(Detailed data flow diagrams would be part of a more in-depth design phase, but high-level flows are described here.)*

1.  **AI-Assisted Invoice Creation:**
    *   User uploads a document (PDF/image) via the frontend.
    *   Frontend sends the file to the Invoice Agent's API Layer (`POST /api/invoices/upload-for-ocr`).
    *   API Layer authenticates, validates, and passes the file to the Service Layer.
    *   Service Layer invokes the AI Integration Service Client.
    *   AI Client sends the document to the AI OCR Service.
    *   AI OCR Service processes the document and returns structured data (JSON).
    *   AI Client parses the response and returns it to the Service Layer.
    *   Service Layer uses the structured data to pre-fill a new invoice object (draft status) and returns this to the API Layer, then to the front
(Content truncated due to size limit. Use line ranges to read in chunks)
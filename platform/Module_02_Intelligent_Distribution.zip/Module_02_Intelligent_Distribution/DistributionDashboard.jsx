import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Chip,
  Snackbar,
  Alert,
  Grid
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import VisibilityIcon from '@mui/icons-material/Visibility';
import SendIcon from '@mui/icons-material/Send';
import { CommunicationChannel } from '../../distribution/entities/recipient-contact.entity';
import { DistributionStatus } from '../../distribution/entities/distribution-record.entity';

function DistributionDashboard({ organizationId }) {
  const [distributions, setDistributions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [currentDistribution, setCurrentDistribution] = useState(null);
  const [recipients, setRecipients] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [formData, setFormData] = useState({
    invoiceId: '',
    recipientId: '',
    channel: 'EMAIL',
    organizationId: organizationId
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    sent: 0,
    delivered: 0,
    opened: 0,
    failed: 0
  });

  useEffect(() => {
    fetchDistributions();
    fetchRecipients();
    fetchInvoices();
  }, [organizationId]);

  const fetchDistributions = async () => {
    setLoading(true);
    try {
      // In a real implementation, this would be an API call
      // For now, we'll use mock data
      const mockDistributions = [
        {
          id: 'dist-1',
          invoiceId: 'inv-1',
          recipientId: 'rec-1',
          channel: 'EMAIL',
          status: 'SENT',
          sentAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          deliveredAt: new Date(Date.now() - 23.9 * 60 * 60 * 1000).toISOString(),
          openedAt: null,
          organizationId: organizationId,
          recipient: {
            id: 'rec-1',
            recipientName: 'John Doe',
            email: 'john.doe@example.com'
          },
          invoice: {
            id: 'inv-1',
            invoiceNumber: 'INV-2025-001',
            amount: 1250.00
          }
        },
        {
          id: 'dist-2',
          invoiceId: 'inv-2',
          recipientId: 'rec-2',
          channel: 'WHATSAPP',
          status: 'DELIVERED',
          sentAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
          deliveredAt: new Date(Date.now() - 11.8 * 60 * 60 * 1000).toISOString(),
          openedAt: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString(),
          organizationId: organizationId,
          recipient: {
            id: 'rec-2',
            recipientName: 'Jane Smith',
            email: 'jane.smith@example.com'
          },
          invoice: {
            id: 'inv-2',
            invoiceNumber: 'INV-2025-002',
            amount: 750.50
          }
        },
        {
          id: 'dist-3',
          invoiceId: 'inv-3',
          recipientId: 'rec-1',
          channel: 'SMS',
          status: 'PENDING',
          sentAt: null,
          deliveredAt: null,
          openedAt: null,
          organizationId: organizationId,
          recipient: {
            id: 'rec-1',
            recipientName: 'John Doe',
            email: 'john.doe@example.com'
          },
          invoice: {
            id: 'inv-3',
            invoiceNumber: 'INV-2025-003',
            amount: 2100.75
          }
        }
      ];
      
      setDistributions(mockDistributions);
      
      // Calculate stats
      const total = mockDistributions.length;
      const pending = mockDistributions.filter(d => d.status === 'PENDING').length;
      const sent = mockDistributions.filter(d => d.status === 'SENT').length;
      const delivered = mockDistributions.filter(d => d.status === 'DELIVERED').length;
      const opened = mockDistributions.filter(d => d.status === 'OPENED').length;
      const failed = mockDistributions.filter(d => d.status === 'FAILED').length;
      
      setStats({
        total,
        pending,
        sent,
        delivered,
        opened,
        failed
      });
      
      setError(null);
    } catch (err) {
      setError('Failed to fetch distributions: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecipients = async () => {
    try {
      // In a real implementation, this would be an API call
      const mockRecipients = [
        {
          id: 'rec-1',
          recipientName: 'John Doe',
          email: 'john.doe@example.com'
        },
        {
          id: 'rec-2',
          recipientName: 'Jane Smith',
          email: 'jane.smith@example.com'
        }
      ];
      
      setRecipients(mockRecipients);
    } catch (err) {
      console.error('Failed to fetch recipients:', err);
    }
  };

  const fetchInvoices = async () => {
    try {
      // In a real implementation, this would be an API call
      const mockInvoices = [
        {
          id: 'inv-1',
          invoiceNumber: 'INV-2025-001',
          amount: 1250.00
        },
        {
          id: 'inv-2',
          invoiceNumber: 'INV-2025-002',
          amount: 750.50
        },
        {
          id: 'inv-3',
          invoiceNumber: 'INV-2025-003',
          amount: 2100.75
        }
      ];
      
      setInvoices(mockInvoices);
    } catch (err) {
      console.error('Failed to fetch invoices:', err);
    }
  };

  const handleOpenDialog = (distribution = null) => {
    if (distribution) {
      setCurrentDistribution(distribution);
      setFormData({
        invoiceId: distribution.invoiceId,
        recipientId: distribution.recipientId,
        channel: distribution.channel,
        organizationId: organizationId
      });
    } else {
      setCurrentDistribution(null);
      setFormData({
        invoiceId: '',
        recipientId: '',
        channel: 'EMAIL',
        organizationId: organizationId
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async () => {
    try {
      // In a real implementation, this would be an API call
      const newDistribution = {
        id: `dist-${Date.now()}`,
        ...formData,
        status: 'PENDING',
        sentAt: null,
        deliveredAt: null,
        openedAt: null,
        recipient: recipients.find(r => r.id === formData.recipientId),
        invoice: invoices.find(i => i.id === formData.invoiceId)
      };
      
      setDistributions([...distributions, newDistribution]);
      
      // Update stats
      setStats({
        ...stats,
        total: stats.total + 1,
        pending: stats.pending + 1
      });
      
      setSnackbar({
        open: true,
        message: 'Distribution created successfully',
        severity: 'success'
      });
      
      handleCloseDialog();
    } catch (err) {
      setSnackbar({
        open: true,
        message: 'Error: ' + err.message,
        severity: 'error'
      });
    }
  };

  const handleSendNow = async (id) => {
    try {
      // In a real implementation, this would be an API call
      const updatedDistributions = distributions.map(d => {
        if (d.id === id) {
          return {
            ...d,
            status: 'SENT',
            sentAt: new Date().toISOString()
          };
        }
        return d;
      });
      
      setDistributions(updatedDistributions);
      
      // Update stats
      setStats({
        ...stats,
        pending: stats.pending - 1,
        sent: stats.sent + 1
      });
      
      setSnackbar({
        open: true,
        message: 'Distribution sent successfully',
        severity: 'success'
      });
    } catch (err) {
      setSnackbar({
        open: true,
        message: 'Error: ' + err.message,
        severity: 'error'
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  const getStatusChipColor = (status) => {
    switch (status) {
      case 'PENDING':
        return 'default';
      case 'SENT':
        return 'primary';
      case 'DELIVERED':
        return 'info';
      case 'OPENED':
        return 'success';
      case 'FAILED':
        return 'error';
      default:
        return 'default';
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6">Distribution Dashboard</Typography>
        <Box>
          <Button 
            variant="outlined" 
            startIcon={<RefreshIcon />}
            onClick={fetchDistributions}
            sx={{ mr: 1 }}
          >
            Refresh
          </Button>
          <Button 
            variant="contained" 
            startIcon={<SendIcon />}
            onClick={() => handleOpenDialog()}
          >
            New Distribution
          </Button>
        </Box>
      </Box>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={2}>
          <Paper sx={{ p: 2, textAlign: 'center' }}>
            <Typography variant="h6">{stats.total}</Typography>
            <Typography variant="body2">Total</Typography>
          </Paper>
        </Grid>
        <Grid item xs={2}>
          <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'grey.100' }}>
            <Typography variant="h6">{stats.pending}</Typography>
            <Typography variant="body2">Pending</Typography>
          </Paper>
        </Grid>
        <Grid item xs={2}>
          <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'primary.light' }}>
            <Typography variant="h6">{stats.sent}</Typography>
            <Typography variant="body2">Sent</Typography>
          </Paper>
        </Grid>
        <Grid item xs={2}>
          <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'info.light' }}>
            <Typography variant="h6">{stats.delivered}</Typography>
            <Typography variant="body2">Delivered</Typography>
          </Paper>
        </Grid>
        <Grid item xs={2}>
          <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'success.light' }}>
            <Typography variant="h6">{stats.opened}</Typography>
            <Typography variant="body2">Opened</Typography>
          </Paper>
        </Grid>
        <Grid item xs={2}>
          <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'error.light' }}>
            <Typography variant="h6">{stats.failed}</Typography>
            <Typography variant="body2">Failed</Typography>
          </Paper>
        </Grid>
      </Grid>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Invoice</TableCell>
              <TableCell>Recipient</TableCell>
              <TableCell>Channel</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Sent At</TableCell>
              <TableCell>Delivered At</TableCell>
              <TableCell>Opened At</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {distributions.map((distribution) => (
              <TableRow key={distribution.id}>
                <TableCell>
                  {distribution.invoice?.invoiceNumber || distribution.invoiceId}
                </TableCell>
                <TableCell>
                  {distribution.recipient?.recipientName || distribution.recipientId}
                </TableCell>
                <TableCell>{distribution.channel}</TableCell>
                <TableCell>
                  <Chip 
                    label={distribution.status} 
                    color={getStatusChipColor(distribution.status)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  {distribution.sentAt ? new Date(distribution.sentAt).toLocaleString() : 'N/A'}
                </TableCell>
                <TableCell>
                  {distribution.deliveredAt ? new Date(distribution.deliveredAt).toLocaleString() : 'N/A'}
                </TableCell>
                <TableCell>
                  {distribution.openedAt ? new Date(distribution.openedAt).toLocaleString() : 'N/A'}
                </TableCell>
                <TableCell>
                  <IconButton>
                    <VisibilityIcon />
                  </IconButton>
                  {distribution.status === 'PENDING' && (
                    <IconButton onClick={() => handleSendNow(distribution.id)}>
                      <SendIcon />
                    </IconButton>
                  )}
                </TableCell>
              </TableRow>
            ))}
            {distributions.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  No distributions found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>
          New Distribution
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2, minWidth: '400px' }}>
            <FormControl fullWidth>
              <InputLabel>Invoice</InputLabel>
              <Select
                name="invoiceId"
                value={formData.invoiceId}
                onChange={handleInputChange}
                required
              >
                {invoices.map(invoice => (
                  <MenuItem key={invoice.id} value={invoice.id}>
                    {invoice.invoiceNumber} (${invoice.amount.toFixed(2)})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            <FormControl fullWidth>
              <InputLabel>Recipient</InputLabel>
              <Select
                name="recipientId"
                value={formData.recipientId}
                onChange={handleInputChange}
                required
              >
                {recipients.map(recipient => (
                  <MenuItem key={recipient.id} value={recipient.id}>
                    {recipient.recipientName} ({recipient.email})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            <FormControl fullWidth>
              <InputLabel>Channel</InputLabel>
              <Select
                name="channel"
                value={formData.channel}
                onChange={handleInputChange}
                required
              >
                <MenuItem value="EMAIL">Email</MenuItem>
                <MenuItem value="WHATSAPP">WhatsApp</MenuItem>
                <MenuItem value="SMS">SMS</MenuItem>
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button 
            onClick={handleSubmit} 
            variant="contained"
            disabled={!formData.invoiceId || !formData.recipientId}
          >
            Create
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default DistributionDashboard;

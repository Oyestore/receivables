#!/bin/bash

# Test script for SME Receivables Management Platform
echo "Starting system tests for SME Receivables Management Platform..."

# Create test directory
mkdir -p /home/ubuntu/sme-receivables-platform/tests
cd /home/ubuntu/sme-receivables-platform

# Check if Docker is installed
echo "Checking Docker installation..."
if ! command -v docker &> /dev/null; then
    echo "Docker is not installed. Please install Docker to run the system."
    exit 1
fi

# Check if Docker Compose is installed
echo "Checking Docker Compose installation..."
if ! command -v docker-compose &> /dev/null; then
    echo "Docker Compose is not installed. Please install Docker Compose to run the system."
    exit 1
fi

# Validate docker-compose.yml file
echo "Validating Docker Compose configuration..."
docker-compose config > /dev/null
if [ $? -ne 0 ]; then
    echo "Docker Compose configuration is invalid. Please check docker-compose.yml file."
    exit 1
else
    echo "Docker Compose configuration is valid."
fi

# Check if required directories and files exist
echo "Checking required files and directories..."
required_dirs=("backend" "frontend" "docker" "docs")
required_files=("docker-compose.yml" "backend/Dockerfile" "frontend/Dockerfile")

for dir in "${required_dirs[@]}"; do
    if [ ! -d "$dir" ]; then
        echo "Required directory '$dir' is missing."
        exit 1
    fi
done

for file in "${required_files[@]}"; do
    if [ ! -f "$file" ]; then
        echo "Required file '$file' is missing."
        exit 1
    fi
done

echo "All required files and directories are present."

# Create .env file for testing
echo "Creating test environment variables..."
cat > .env << EOL
# Database Configuration
DATABASE_URL=postgres://postgres:postgres@postgres:5432/sme_receivables
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres
POSTGRES_DB=sme_receivables

# JWT Configuration
JWT_SECRET=test_jwt_secret_key_for_development_only

# Redis Configuration
REDIS_URL=redis://redis:6379

# MinIO Configuration
MINIO_ROOT_USER=minioadmin
MINIO_ROOT_PASSWORD=minioadmin
MINIO_ENDPOINT=minio
MINIO_PORT=9000
MINIO_USE_SSL=false
MINIO_BUCKET=sme-receivables

# API Configuration
PORT=3000
NODE_ENV=development
EOL

echo "Test environment variables created."

# Build and start the containers in detached mode
echo "Building and starting containers for testing..."
docker-compose build
if [ $? -ne 0 ]; then
    echo "Failed to build Docker containers. Please check the Dockerfiles and dependencies."
    exit 1
fi

docker-compose up -d
if [ $? -ne 0 ]; then
    echo "Failed to start Docker containers. Please check the Docker Compose configuration."
    exit 1
fi

# Wait for services to be ready
echo "Waiting for services to be ready..."
sleep 10

# Check if all containers are running
echo "Checking container status..."
container_count=$(docker-compose ps -q | wc -l)
running_count=$(docker-compose ps | grep "Up" | wc -l)

if [ "$container_count" != "$running_count" ]; then
    echo "Not all containers are running. Please check the logs with 'docker-compose logs'."
    docker-compose ps
    docker-compose logs
    docker-compose down
    exit 1
fi

echo "All containers are running."

# Test API health endpoint
echo "Testing API health endpoint..."
health_response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/api/health)
if [ "$health_response" != "200" ]; then
    echo "API health check failed with status code: $health_response"
    docker-compose logs api
    docker-compose down
    exit 1
fi

echo "API health check passed."

# Test login endpoint with demo credentials
echo "Testing login endpoint with demo credentials..."
login_response=$(curl -s -X POST -H "Content-Type: application/json" -d '{"email":"admin@demo.com","password":"admin123"}' http://localhost:8080/api/auth/login)
if [[ "$login_response" != *"token"* ]]; then
    echo "Login test failed. Response: $login_response"
    docker-compose logs api
    docker-compose down
    exit 1
fi

echo "Login test passed."

# Extract token for further tests
token=$(echo $login_response | grep -o '"token":"[^"]*' | sed 's/"token":"//')

# Test protected endpoint
echo "Testing protected endpoint (users)..."
users_response=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer $token" http://localhost:8080/api/users)
if [ "$users_response" != "200" ]; then
    echo "Protected endpoint test failed with status code: $users_response"
    docker-compose logs api
    docker-compose down
    exit 1
fi

echo "Protected endpoint test passed."

# Test frontend static files
echo "Testing frontend static files..."
frontend_response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/)
if [ "$frontend_response" != "200" ]; then
    echo "Frontend static files test failed with status code: $frontend_response"
    docker-compose logs frontend
    docker-compose down
    exit 1
fi

echo "Frontend static files test passed."

# Create test summary
echo "Creating test summary..."
cat > tests/test_summary.md << EOL
# Test Summary for SME Receivables Management Platform

## Test Date: $(date)

## Environment
- Docker Compose: $(docker-compose --version)
- Docker: $(docker --version)

## Test Results
- Docker Compose Configuration: ✅ PASSED
- Required Files and Directories: ✅ PASSED
- Container Startup: ✅ PASSED
- API Health Check: ✅ PASSED
- Authentication Test: ✅ PASSED
- Protected Endpoint Test: ✅ PASSED
- Frontend Static Files Test: ✅ PASSED

## Summary
All tests have passed. The system is functioning as expected.

## Next Steps
1. Deploy to production environment
2. Perform user acceptance testing
3. Monitor system performance
EOL

echo "Test summary created at tests/test_summary.md"

# Stop containers
echo "Stopping containers..."
docker-compose down

echo "All tests completed successfully!"
exit 0

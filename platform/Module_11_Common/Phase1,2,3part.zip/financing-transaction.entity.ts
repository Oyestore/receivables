import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { FinancingRequest } from './financing-request.entity';
import { PaymentTransaction } from '../../entities/payment-transaction.entity';

export enum FinancingTransactionType {
  DISBURSEMENT = 'disbursement',
  REPAYMENT = 'repayment',
  FEE = 'fee',
  INTEREST = 'interest',
  PENALTY = 'penalty',
  REFUND = 'refund',
}

@Entity()
export class FinancingTransaction {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => FinancingRequest, request => request.transactions)
  financingRequest: FinancingRequest;

  @Column()
  financingRequestId: string;

  @Column({
    type: 'enum',
    enum: FinancingTransactionType,
  })
  transactionType: FinancingTransactionType;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount: number;

  @Column()
  transactionDate: Date;

  @Column({ nullable: true })
  description: string;

  @Column({ nullable: true })
  currencyCode: string;

  @ManyToOne(() => PaymentTransaction, { nullable: true })
  paymentTransaction: PaymentTransaction;

  @Column({ nullable: true })
  paymentTransactionId: string;

  @Column({ nullable: true })
  externalReferenceId: string;

  @Column({ nullable: true })
  externalSystemName: string;

  @Column({ type: 'json', nullable: true })
  metadata: Record<string, any>;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  updatedAt: Date;
}
